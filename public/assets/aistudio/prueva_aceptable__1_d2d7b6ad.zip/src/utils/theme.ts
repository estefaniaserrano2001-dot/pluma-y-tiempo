import { PaletteTheme, CustomPaletteConfig } from '../types';

export interface ThemeColors {
  bgApp: string;
  bgWorkspace: string;
  bgCard: string;
  bgSidebar: string;
  borderCard: string;
  borderSidebar: string;
  textPrimary: string;
  textSecondary: string;
  textMuted: string;
  primaryBtn: string;
  primaryBtnHover: string;
  accentBadge: string;
  accentBadgeText: string;
  accentText: string;
  activeTab: string;
  activeBorder: string;
  activeRing: string;
  accentHex: string;
  secondaryHex: string;
  timelineCanvasBg: string;
  timelineGridColor: string;
}

export interface ThemeConfig {
  id: PaletteTheme;
  name: string;
  description: string;
  preview: [string, string, string]; // 3 representative swatches
  light: ThemeColors;
  dark: ThemeColors;
}

export const PALETTES: Record<PaletteTheme, ThemeConfig> = {
  bosque: {
    id: 'bosque',
    name: 'Bosque',
    description: 'Verdes profundos, verde salvia y crema orgánico.',
    preview: ['#1E3A2B', '#7FA084', '#F4F0E8'],
    light: {
      bgApp: 'bg-[#F7F5F0]',
      bgWorkspace: 'bg-[#FAF8F4]',
      bgCard: 'bg-white',
      bgSidebar: 'bg-[#F1EDE4]',
      borderCard: 'border-[#D9E1D7]',
      borderSidebar: 'border-[#CBD5C8]',
      textPrimary: 'text-[#1B3224]',
      textSecondary: 'text-[#3E5C49]',
      textMuted: 'text-[#678271]',
      primaryBtn: 'bg-[#234934] hover:bg-[#1A3828] text-white',
      primaryBtnHover: 'hover:bg-[#1A3828]',
      accentBadge: 'bg-[#E2EDE3]',
      accentBadgeText: 'text-[#234934]',
      accentText: 'text-[#234934]',
      activeTab: 'bg-[#234934] text-white',
      activeBorder: 'border-[#234934]',
      activeRing: 'ring-[#234934]/30',
      accentHex: '#234934',
      secondaryHex: '#7FA084',
      timelineCanvasBg: '#F8F6F1',
      timelineGridColor: '#D8E2D6',
    },
    dark: {
      bgApp: 'bg-[#0E1712]',
      bgWorkspace: 'bg-[#121E18]',
      bgCard: 'bg-[#17261F]',
      bgSidebar: 'bg-[#0F1914]',
      borderCard: 'border-[#263D31]',
      borderSidebar: 'border-[#203329]',
      textPrimary: 'text-[#E6EFE9]',
      textSecondary: 'text-[#AEC7B6]',
      textMuted: 'text-[#6F8F79]',
      primaryBtn: 'bg-[#316347] hover:bg-[#3D7A58] text-white',
      primaryBtnHover: 'hover:bg-[#3D7A58]',
      accentBadge: 'bg-[#1D3327]',
      accentBadgeText: 'text-[#97C5A4]',
      accentText: 'text-[#97C5A4]',
      activeTab: 'bg-[#316347] text-white',
      activeBorder: 'border-[#3D7A58]',
      activeRing: 'ring-[#3D7A58]/40',
      accentHex: '#3D7A58',
      secondaryHex: '#7FA084',
      timelineCanvasBg: '#101B15',
      timelineGridColor: '#1E3227',
    },
  },
  oceano: {
    id: 'oceano',
    name: 'Océano',
    description: 'Azul marino profundo, azul grisáceo y blanco cálido.',
    preview: ['#142C44', '#557C99', '#F4F7FA'],
    light: {
      bgApp: 'bg-[#F2F6F9]',
      bgWorkspace: 'bg-[#F8FAFC]',
      bgCard: 'bg-white',
      bgSidebar: 'bg-[#EBF1F6]',
      borderCard: 'border-[#D3DFE9]',
      borderSidebar: 'border-[#C4D5E2]',
      textPrimary: 'text-[#12283D]',
      textSecondary: 'text-[#32526F]',
      textMuted: 'text-[#5E7D99]',
      primaryBtn: 'bg-[#1B3B5C] hover:bg-[#132C47] text-white',
      primaryBtnHover: 'hover:bg-[#132C47]',
      accentBadge: 'bg-[#E3EDF6]',
      accentBadgeText: 'text-[#1A3F66]',
      accentText: 'text-[#1B3B5C]',
      activeTab: 'bg-[#1B3B5C] text-white',
      activeBorder: 'border-[#1B3B5C]',
      activeRing: 'ring-[#1B3B5C]/30',
      accentHex: '#1B3B5C',
      secondaryHex: '#557C99',
      timelineCanvasBg: '#F4F7FB',
      timelineGridColor: '#D1E0EC',
    },
    dark: {
      bgApp: 'bg-[#0C1520]',
      bgWorkspace: 'bg-[#101C2B]',
      bgCard: 'bg-[#152538]',
      bgSidebar: 'bg-[#0E1824]',
      borderCard: 'border-[#203852]',
      borderSidebar: 'border-[#1C3147]',
      textPrimary: 'text-[#E3EEF9]',
      textSecondary: 'text-[#96B8D6]',
      textMuted: 'text-[#5C7F9F]',
      primaryBtn: 'bg-[#2A5682] hover:bg-[#33689C] text-white',
      primaryBtnHover: 'hover:bg-[#33689C]',
      accentBadge: 'bg-[#19324C]',
      accentBadgeText: 'text-[#8EC2ED]',
      accentText: 'text-[#8EC2ED]',
      activeTab: 'bg-[#2A5682] text-white',
      activeBorder: 'border-[#33689C]',
      activeRing: 'ring-[#33689C]/40',
      accentHex: '#33689C',
      secondaryHex: '#557C99',
      timelineCanvasBg: '#0F1A26',
      timelineGridColor: '#1B2E42',
    },
  },
  atardecer: {
    id: 'atardecer',
    name: 'Atardecer',
    description: 'Terracota artesanal, naranja suave y beige cálido.',
    preview: ['#873426', '#D47754', '#F7EFE8'],
    light: {
      bgApp: 'bg-[#FAF4EF]',
      bgWorkspace: 'bg-[#FCF8F5]',
      bgCard: 'bg-white',
      bgSidebar: 'bg-[#F4ECE3]',
      borderCard: 'border-[#EAD7C9]',
      borderSidebar: 'border-[#DEC7B5]',
      textPrimary: 'text-[#361B14]',
      textSecondary: 'text-[#683C30]',
      textMuted: 'text-[#8E6356]',
      primaryBtn: 'bg-[#933D2D] hover:bg-[#7D3022] text-white',
      primaryBtnHover: 'hover:bg-[#7D3022]',
      accentBadge: 'bg-[#F9E8DE]',
      accentBadgeText: 'text-[#963C2A]',
      accentText: 'text-[#933D2D]',
      activeTab: 'bg-[#933D2D] text-white',
      activeBorder: 'border-[#933D2D]',
      activeRing: 'ring-[#933D2D]/30',
      accentHex: '#933D2D',
      secondaryHex: '#D47754',
      timelineCanvasBg: '#FAF4EF',
      timelineGridColor: '#EAD5C5',
    },
    dark: {
      bgApp: 'bg-[#17100E]',
      bgWorkspace: 'bg-[#201614]',
      bgCard: 'bg-[#291C19]',
      bgSidebar: 'bg-[#1B1210]',
      borderCard: 'border-[#422C27]',
      borderSidebar: 'border-[#382420]',
      textPrimary: 'text-[#FAECE8]',
      textSecondary: 'text-[#DBB1A6]',
      textMuted: 'text-[#A07B71]',
      primaryBtn: 'bg-[#A84B3A] hover:bg-[#BD5743] text-white',
      primaryBtnHover: 'hover:bg-[#BD5743]',
      accentBadge: 'bg-[#3A221C]',
      accentBadgeText: 'text-[#F29F8D]',
      accentText: 'text-[#F29F8D]',
      activeTab: 'bg-[#A84B3A] text-white',
      activeBorder: 'border-[#BD5743]',
      activeRing: 'ring-[#BD5743]/40',
      accentHex: '#A84B3A',
      secondaryHex: '#D47754',
      timelineCanvasBg: '#1C1311',
      timelineGridColor: '#36231F',
    },
  },
  lavanda: {
    id: 'lavanda',
    name: 'Lavanda',
    description: 'Violeta noble, lila suave y tonos neutros sosegados.',
    preview: ['#4E2F6B', '#9B7BBC', '#F6F3F9'],
    light: {
      bgApp: 'bg-[#F6F4F9]',
      bgWorkspace: 'bg-[#FBF9FC]',
      bgCard: 'bg-white',
      bgSidebar: 'bg-[#EFEBF4]',
      borderCard: 'border-[#DED5E7]',
      borderSidebar: 'border-[#D0C4DC]',
      textPrimary: 'text-[#28183B]',
      textSecondary: 'text-[#533973]',
      textMuted: 'text-[#7B629B]',
      primaryBtn: 'bg-[#583778] hover:bg-[#462963] text-white',
      primaryBtnHover: 'hover:bg-[#462963]',
      accentBadge: 'bg-[#EFE8F6]',
      accentBadgeText: 'text-[#583778]',
      accentText: 'text-[#583778]',
      activeTab: 'bg-[#583778] text-white',
      activeBorder: 'border-[#583778]',
      activeRing: 'ring-[#583778]/30',
      accentHex: '#583778',
      secondaryHex: '#9B7BBC',
      timelineCanvasBg: '#F7F4FA',
      timelineGridColor: '#DFD5EB',
    },
    dark: {
      bgApp: 'bg-[#130E1A]',
      bgWorkspace: 'bg-[#1B1424]',
      bgCard: 'bg-[#241A30]',
      bgSidebar: 'bg-[#16101E]',
      borderCard: 'border-[#3D2C50]',
      borderSidebar: 'border-[#332444]',
      textPrimary: 'text-[#F3EDF9]',
      textSecondary: 'text-[#C5B0DC]',
      textMuted: 'text-[#8E79A6]',
      primaryBtn: 'bg-[#734A9C] hover:bg-[#8657B6] text-white',
      primaryBtnHover: 'hover:bg-[#8657B6]',
      accentBadge: 'bg-[#312044]',
      accentBadgeText: 'text-[#CFAEE8]',
      accentText: 'text-[#CFAEE8]',
      activeTab: 'bg-[#734A9C] text-white',
      activeBorder: 'border-[#8657B6]',
      activeRing: 'ring-[#8657B6]/40',
      accentHex: '#734A9C',
      secondaryHex: '#9B7BBC',
      timelineCanvasBg: '#181220',
      timelineGridColor: '#302240',
    },
  },
  nocturna: {
    id: 'nocturna',
    name: 'Nocturna',
    description: 'Negro suave, gris carbón y detalles azulados.',
    preview: ['#161E28', '#4F6C8D', '#E9EEF4'],
    light: {
      bgApp: 'bg-[#F1F3F6]',
      bgWorkspace: 'bg-[#F7F9FB]',
      bgCard: 'bg-white',
      bgSidebar: 'bg-[#E7EBF0]',
      borderCard: 'border-[#D1D7E0]',
      borderSidebar: 'border-[#C2C9D3]',
      textPrimary: 'text-[#121922]',
      textSecondary: 'text-[#354354]',
      textMuted: 'text-[#5F7185]',
      primaryBtn: 'bg-[#1E2938] hover:bg-[#141C26] text-white',
      primaryBtnHover: 'hover:bg-[#141C26]',
      accentBadge: 'bg-[#E2E8F0]',
      accentBadgeText: 'text-[#1E2938]',
      accentText: 'text-[#1E2938]',
      activeTab: 'bg-[#1E2938] text-white',
      activeBorder: 'border-[#1E2938]',
      activeRing: 'ring-[#1E2938]/30',
      accentHex: '#1E2938',
      secondaryHex: '#4F6C8D',
      timelineCanvasBg: '#F2F5F8',
      timelineGridColor: '#CED6E0',
    },
    dark: {
      bgApp: 'bg-[#0D1117]',
      bgWorkspace: 'bg-[#131922]',
      bgCard: 'bg-[#1A222E]',
      bgSidebar: 'bg-[#0F141C]',
      borderCard: 'border-[#283547]',
      borderSidebar: 'border-[#222D3D]',
      textPrimary: 'text-[#E6EDF5]',
      textSecondary: 'text-[#9AB1CA]',
      textMuted: 'text-[#657C96]',
      primaryBtn: 'bg-[#314863] hover:bg-[#3D5A7D] text-white',
      primaryBtnHover: 'hover:bg-[#3D5A7D]',
      accentBadge: 'bg-[#1E2B3B]',
      accentBadgeText: 'text-[#8FBAE5]',
      accentText: 'text-[#8FBAE5]',
      activeTab: 'bg-[#314863] text-white',
      activeBorder: 'border-[#3D5A7D]',
      activeRing: 'ring-[#3D5A7D]/40',
      accentHex: '#3D5A7D',
      secondaryHex: '#4F6C8D',
      timelineCanvasBg: '#101620',
      timelineGridColor: '#222E3F',
    },
  },
};

export function hexToRgb(hex: string): { r: number; g: number; b: number } {
  let c = hex.replace('#', '');
  if (c.length === 3) {
    c = c.split('').map((char) => char + char).join('');
  }
  const num = parseInt(c, 16);
  return {
    r: (num >> 16) & 255,
    g: (num >> 8) & 255,
    b: num & 255,
  };
}

export function getLuminance(hex: string): number {
  try {
    const { r, g, b } = hexToRgb(hex);
    const a = [r, g, b].map((v) => {
      v /= 255;
      return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4);
    });
    return a[0] * 0.2126 + a[1] * 0.7152 + a[2] * 0.0722;
  } catch (e) {
    return 0.5;
  }
}

export function getContrastRatio(hex1: string, hex2: string): number {
  const lum1 = getLuminance(hex1);
  const lum2 = getLuminance(hex2);
  const brightest = Math.max(lum1, lum2);
  const darkest = Math.min(lum1, lum2);
  return (brightest + 0.05) / (darkest + 0.05);
}

export function hexToRgba(hex: string, alpha: number): string {
  try {
    const { r, g, b } = hexToRgb(hex);
    return `rgba(${r}, ${g}, ${b}, ${alpha})`;
  } catch {
    return hex;
  }
}

let registeredCustomPalettes: CustomPaletteConfig[] = [];

export function registerCustomPalettes(palettes: CustomPaletteConfig[] = []) {
  registeredCustomPalettes = palettes;
}

export function getRegisteredCustomPalettes(): CustomPaletteConfig[] {
  return registeredCustomPalettes;
}

export function generateCustomThemeConfig(custom: CustomPaletteConfig): ThemeConfig {
  const p = custom.primary || '#243B35';
  const s = custom.secondary || '#87A878';
  const a = custom.accent || '#D4AF37';

  // Light tints
  const lightBgApp = hexToRgba(s, 0.08);
  const lightBgWorkspace = hexToRgba(s, 0.04);
  const lightBgSidebar = hexToRgba(s, 0.12);
  const lightBorder = hexToRgba(p, 0.2);
  const lightAccentBadge = hexToRgba(s, 0.2);

  // Dark tints
  const darkBgApp = '#0f1412';
  const darkBgWorkspace = '#141a18';
  const darkBgCard = '#19221f';
  const darkBgSidebar = '#111715';
  const darkBorder = hexToRgba(s, 0.25);
  const darkAccentBadge = hexToRgba(p, 0.4);

  return {
    id: custom.id as any,
    name: custom.name,
    description: `Paleta personalizada (${custom.name})`,
    preview: [p, s, a],
    light: {
      bgApp: 'bg-[var(--theme-bg-app)]',
      bgWorkspace: 'bg-[var(--theme-bg-workspace)]',
      bgCard: 'bg-white',
      bgSidebar: 'bg-[var(--theme-bg-sidebar)]',
      borderCard: 'border-[var(--theme-border-card)]',
      borderSidebar: 'border-[var(--theme-border-sidebar)]',
      textPrimary: 'text-stone-900',
      textSecondary: 'text-stone-700',
      textMuted: 'text-stone-500',
      primaryBtn: 'bg-[var(--theme-primary)] hover:opacity-90 text-white shadow-sm',
      primaryBtnHover: 'hover:opacity-90',
      accentBadge: 'bg-[var(--theme-accent-badge)]',
      accentBadgeText: 'text-[var(--theme-primary)] font-semibold',
      accentText: 'text-[var(--theme-primary)]',
      activeTab: 'bg-[var(--theme-primary)] text-white shadow-sm',
      activeBorder: 'border-[var(--theme-primary)]',
      activeRing: 'ring-[var(--theme-primary)]/30',
      accentHex: p,
      secondaryHex: s,
      timelineCanvasBg: '#fbfaf8',
      timelineGridColor: hexToRgba(p, 0.12),
    },
    dark: {
      bgApp: 'bg-[var(--theme-bg-app)]',
      bgWorkspace: 'bg-[var(--theme-bg-workspace)]',
      bgCard: 'bg-[var(--theme-bg-card)]',
      bgSidebar: 'bg-[var(--theme-bg-sidebar)]',
      borderCard: 'border-[var(--theme-border-card)]',
      borderSidebar: 'border-[var(--theme-border-sidebar)]',
      textPrimary: 'text-stone-100',
      textSecondary: 'text-stone-300',
      textMuted: 'text-stone-400',
      primaryBtn: 'bg-[var(--theme-primary)] hover:opacity-90 text-white shadow-sm',
      primaryBtnHover: 'hover:opacity-90',
      accentBadge: 'bg-[var(--theme-accent-badge)]',
      accentBadgeText: 'text-[var(--theme-secondary)] font-semibold',
      accentText: 'text-[var(--theme-secondary)]',
      activeTab: 'bg-[var(--theme-primary)] text-white shadow-sm',
      activeBorder: 'border-[var(--theme-secondary)]',
      activeRing: 'ring-[var(--theme-secondary)]/40',
      accentHex: p,
      secondaryHex: s,
      timelineCanvasBg: '#121715',
      timelineGridColor: hexToRgba(s, 0.2),
    },
  };
}

export function applyDynamicPaletteVariables(
  paletteKey: string,
  darkMode: boolean,
  customPalettes?: CustomPaletteConfig[]
) {
  if (typeof document === 'undefined') return;
  const root = document.documentElement;

  const allCustom = customPalettes || registeredCustomPalettes;
  const custom = allCustom?.find((cp) => cp.id === paletteKey);

  if (custom) {
    const p = custom.primary || '#243B35';
    const s = custom.secondary || '#87A878';
    const a = custom.accent || '#D4AF37';

    if (darkMode) {
      root.style.setProperty('--theme-primary', p);
      root.style.setProperty('--theme-secondary', s);
      root.style.setProperty('--theme-accent', a);
      root.style.setProperty('--theme-bg-app', '#0e1411');
      root.style.setProperty('--theme-bg-workspace', '#121916');
      root.style.setProperty('--theme-bg-card', '#18221e');
      root.style.setProperty('--theme-bg-sidebar', '#101714');
      root.style.setProperty('--theme-border-card', hexToRgba(s, 0.22));
      root.style.setProperty('--theme-border-sidebar', hexToRgba(s, 0.28));
      root.style.setProperty('--theme-accent-badge', hexToRgba(s, 0.2));
      root.style.setProperty('--theme-text-primary', '#F1F5F3');
      root.style.setProperty('--theme-text-secondary', '#CAD8D1');
      root.style.setProperty('--theme-text-muted', '#7E978C');
    } else {
      root.style.setProperty('--theme-primary', p);
      root.style.setProperty('--theme-secondary', s);
      root.style.setProperty('--theme-accent', a);
      root.style.setProperty('--theme-bg-app', hexToRgba(s, 0.08));
      root.style.setProperty('--theme-bg-workspace', hexToRgba(s, 0.04));
      root.style.setProperty('--theme-bg-card', '#FFFFFF');
      root.style.setProperty('--theme-bg-sidebar', hexToRgba(s, 0.12));
      root.style.setProperty('--theme-border-card', hexToRgba(p, 0.18));
      root.style.setProperty('--theme-border-sidebar', hexToRgba(p, 0.25));
      root.style.setProperty('--theme-accent-badge', hexToRgba(s, 0.18));
      root.style.setProperty('--theme-text-primary', '#15221B');
      root.style.setProperty('--theme-text-secondary', '#2E4739');
      root.style.setProperty('--theme-text-muted', '#5E796B');
    }
    return;
  }

  // Predefined theme variables fallback
  const preset = (PALETTES as any)[paletteKey] || PALETTES.bosque;
  const current = darkMode ? preset.dark : preset.light;
  root.style.setProperty('--theme-primary', current.accentHex);
  root.style.setProperty('--theme-secondary', current.secondaryHex);
  root.style.setProperty('--theme-accent', current.accentHex);
}

export function getTheme(
  palette: PaletteTheme | string = 'bosque',
  darkMode: boolean = false,
  customPalettes?: CustomPaletteConfig[]
): ThemeColors {
  const allCustom = customPalettes || registeredCustomPalettes;
  if (allCustom && allCustom.length > 0) {
    const custom = allCustom.find((cp) => cp.id === palette);
    if (custom) {
      const generated = generateCustomThemeConfig(custom);
      return darkMode ? generated.dark : generated.light;
    }
  }
  const current = (PALETTES as any)[palette] || PALETTES.bosque;
  return darkMode ? current.dark : current.light;
}

