import React, { useState, useEffect, useMemo } from 'react';
import {
  Plus,
  Search,
  Lightbulb,
  LayoutGrid,
  List,
  Sparkles,
  ArrowRight,
  Edit2,
  Trash2,
  BookOpen,
  User,
  Compass,
  Clock,
  X,
  Check,
  Tag,
  CheckCircle2,
  Sliders,
  RotateCcw,
  Archive,
  Inbox,
  CheckSquare,
  Square,
  PanelLeftClose,
  PanelLeftOpen,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { dbService } from '../../services/db';
import { Idea, IdeaTray, IdeaCategory, Chapter, Character, WorldDetail, TimelineEvent } from '../../types';
import { getTheme } from '../../utils/theme';

export const IdeasModule: React.FC = () => {
  const {
    activeBook,
    currentPalette,
    darkMode,
    toast,
    setIsSaving,
    setActiveSection,
    setActiveChapterId,
  } = useApp();

  const theme = getTheme(currentPalette, darkMode);

  const [ideas, setIdeas] = useState<Idea[]>([]);
  const [categories, setCategories] = useState<IdeaCategory[]>([]);
  const [activeTray, setActiveTray] = useState<IdeaTray>('en_espera');
  const [categoryFilter, setCategoryFilter] = useState<string>('todos');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [searchQuery, setSearchQuery] = useState('');

  // Collapsible sidebar
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);

  // Modal State for Idea create/edit
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingIdea, setEditingIdea] = useState<Idea | null>(null);
  const [deleteConfirmIdea, setDeleteConfirmIdea] = useState<Idea | null>(null);

  // Category Manager Modal
  const [isCatManagerOpen, setIsCatManagerOpen] = useState(false);
  const [catNameInput, setCatNameInput] = useState('');
  const [catColorInput, setCatColorInput] = useState('#2D5A43');
  const [editingCat, setEditingCat] = useState<IdeaCategory | null>(null);
  const [deletingCat, setDeletingCat] = useState<IdeaCategory | null>(null);
  const [reassignTargetCatId, setReassignTargetCatId] = useState<string>('sin_categoria');

  // Conversion Menu State
  const [convertIdea, setConvertIdea] = useState<Idea | null>(null);

  // Form Fields
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [tray, setTray] = useState<IdeaTray>('en_espera');
  const [categoryId, setCategoryId] = useState<string>('general');
  const [priority, setPriority] = useState<Idea['priority']>('media');
  const [tagInput, setTagInput] = useState('');
  const [tags, setTags] = useState<string[]>([]);

  const loadData = async () => {
    if (!activeBook) return;
    const cats = await dbService.getIdeaCategories(activeBook.id);
    setCategories(cats);
    const list = await dbService.getIdeasByBook(activeBook.id);
    setIdeas(list);
  };

  useEffect(() => {
    loadData();
  }, [activeBook]);

  const openEditModal = (idea?: Idea) => {
    if (idea) {
      setEditingIdea(idea);
      setTitle(idea.title);
      setContent(idea.content);
      setTray(idea.tray || (idea.status === 'utilizada' ? 'realizadas' : idea.status === 'descartada' ? 'descartadas' : 'en_espera'));
      setCategoryId(idea.categoryId || 'general');
      setPriority(idea.priority);
      setTags(idea.tags || []);
    } else {
      setEditingIdea(null);
      setTitle('');
      setContent('');
      setTray(activeTray);
      setCategoryId(categories[0]?.id || 'general');
      setPriority('media');
      setTags([]);
    }
    setTagInput('');
    setIsModalOpen(true);
  };

  const handleAddTag = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' || e.key === ',') {
      e.preventDefault();
      const trimmed = tagInput.trim().replace(/^,|,$/g, '');
      if (trimmed && !tags.includes(trimmed)) {
        setTags([...tags, trimmed]);
        setTagInput('');
      }
    }
  };

  const handleRemoveTag = (tagToRemove: string) => {
    setTags(tags.filter((t) => t !== tagToRemove));
  };

  const handleSaveIdea = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() && !content.trim()) return;
    if (!activeBook) return;

    setIsSaving(true);
    try {
      const ideaId =
        editingIdea?.id ||
        'idea_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6);

      const statusMap: Record<IdeaTray, Idea['status']> = {
        en_espera: 'nueva',
        realizadas: 'utilizada',
        descartadas: 'descartada',
      };

      const ideaRecord: Idea = {
        id: ideaId,
        bookId: activeBook.id,
        title: title.trim() || 'Idea sin título',
        content: content.trim(),
        tags,
        status: statusMap[tray],
        tray,
        categoryId,
        isCompleted: tray === 'realizadas',
        priority,
        relatedCharacterIds: editingIdea?.relatedCharacterIds || [],
        relatedChapterIds: editingIdea?.relatedChapterIds || [],
        relatedDetailIds: editingIdea?.relatedDetailIds || [],
        createdAt: editingIdea?.createdAt || new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };

      await dbService.saveIdea(ideaRecord);
      await loadData();
      setIsModalOpen(false);
      toast(editingIdea ? 'Idea actualizada' : 'Idea registrada con éxito', 'success');
    } finally {
      setIsSaving(false);
    }
  };

  // Quick move between trays
  const handleMoveIdeaTray = async (idea: Idea, newTray: IdeaTray) => {
    setIsSaving(true);
    try {
      const isComp = newTray === 'realizadas';
      const statusMap: Record<IdeaTray, Idea['status']> = {
        en_espera: 'nueva',
        realizadas: 'utilizada',
        descartadas: 'descartada',
      };
      const updated: Idea = {
        ...idea,
        tray: newTray,
        status: statusMap[newTray],
        isCompleted: isComp,
        updatedAt: new Date().toISOString(),
      };
      await dbService.saveIdea(updated);
      await loadData();
      const trayNames: Record<IdeaTray, string> = {
        en_espera: 'En Espera',
        realizadas: 'Realizadas',
        descartadas: 'Descartadas',
      };
      toast(`Idea movida a "${trayNames[newTray]}"`, 'info');
    } finally {
      setIsSaving(false);
    }
  };

  // Toggle completion checkbox in "Realizadas" tray
  const handleToggleCompleted = async (idea: Idea) => {
    const nextState = !idea.isCompleted;
    const targetTray: IdeaTray = nextState ? 'realizadas' : 'en_espera';
    await handleMoveIdeaTray(idea, targetTray);
  };

  const handleDeleteConfirm = async () => {
    if (!deleteConfirmIdea) return;
    setIsSaving(true);
    try {
      await dbService.deleteIdea(deleteConfirmIdea.id);
      await loadData();
      toast('Idea eliminada', 'info');
      setDeleteConfirmIdea(null);
    } finally {
      setIsSaving(false);
    }
  };

  // Convert Idea into another narrative entity!
  const handleConvertIdea = async (
    targetType: 'chapter' | 'character' | 'detail' | 'timeline'
  ) => {
    if (!convertIdea || !activeBook) return;
    setIsSaving(true);

    try {
      if (targetType === 'chapter') {
        const existingChapters = await dbService.getChaptersByBook(activeBook.id);
        const nextNum = existingChapters.length + 1;
        const newChap: Chapter = {
          id: 'chap_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
          bookId: activeBook.id,
          order: nextNum,
          number: nextNum,
          title: convertIdea.title,
          synopsis: convertIdea.content.slice(0, 300),
          content: `<p>${convertIdea.content.replace(/\n\n/g, '</p><p>')}</p>`,
          status: 'borrador',
          wordCount: convertIdea.content.split(/\s+/).length,
          characterCount: convertIdea.content.length,
          privateNotes: `Convertido desde la idea: ${convertIdea.title}`,
          relatedCharacterIds: [],
          relatedTimelineEventIds: [],
          audioIds: [],
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        };
        await dbService.saveChapter(newChap);

        // Move idea to Realizadas
        await dbService.saveIdea({
          ...convertIdea,
          tray: 'realizadas',
          status: 'utilizada',
          isCompleted: true,
        });
        await loadData();
        toast(`Idea convertida en Capítulo ${nextNum}`, 'success');
        setConvertIdea(null);
        setActiveChapterId(newChap.id);
        setActiveSection('capitulos');
      } else if (targetType === 'character') {
        const newChar: Character = {
          id: 'char_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
          bookId: activeBook.id,
          name: convertIdea.title,
          aliases: '',
          age: '',
          birthDate: '',
          role: 'secundario',
          appearance: '',
          personality: '',
          backstory: convertIdea.content,
          motivations: '',
          goals: '',
          fears: '',
          strengths: '',
          weaknesses: '',
          secrets: '',
          evolution: '',
          firstAppearance: '',
          additionalNotes: `Convertido desde la idea: ${convertIdea.title}`,
          avatarColor: '#2D5A43',
          relationships: [],
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        };
        await dbService.saveCharacter(newChar);
        await dbService.saveIdea({
          ...convertIdea,
          tray: 'realizadas',
          status: 'utilizada',
          isCompleted: true,
        });
        await loadData();
        toast(`Idea convertida en ficha de personaje`, 'success');
        setConvertIdea(null);
        setActiveSection('personajes');
      } else if (targetType === 'detail') {
        const newDet: WorldDetail = {
          id: 'det_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
          bookId: activeBook.id,
          name: convertIdea.title,
          category: 'conceptos',
          description: convertIdea.content,
          historicalPeriod: '',
          tags: convertIdea.tags || [],
          immutableInfo: '',
          provisionalInfo: convertIdea.content,
          relatedCharacterIds: [],
          relatedChapterIds: [],
          relatedIdeaIds: [convertIdea.id],
          relatedTimelineEventIds: [],
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        };
        await dbService.saveDetail(newDet);
        await dbService.saveIdea({
          ...convertIdea,
          tray: 'realizadas',
          status: 'utilizada',
          isCompleted: true,
        });
        await loadData();
        toast(`Idea convertida en ficha de lore`, 'success');
        setConvertIdea(null);
        setActiveSection('detalles');
      } else if (targetType === 'timeline') {
        const newEv: TimelineEvent = {
          id: 'ev_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
          bookId: activeBook.id,
          title: convertIdea.title,
          description: convertIdea.content,
          dateType: 'aproximada',
          dateDisplay: 'Momento clave',
          numericSortValue: 50,
          category: 'trama_principal',
          color: '#3B82F6',
          status: 'confirmado',
          importance: 'media',
          characterIds: convertIdea.relatedCharacterIds || [],
          chapterIds: convertIdea.relatedChapterIds || [],
          detailIds: convertIdea.relatedDetailIds || [],
          connectedEventIds: [],
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        };
        await dbService.saveTimelineEvent(newEv);
        await dbService.saveIdea({
          ...convertIdea,
          tray: 'realizadas',
          status: 'utilizada',
          isCompleted: true,
        });
        await loadData();
        toast(`Idea convertida en acontecimiento de la línea temporal`, 'success');
        setConvertIdea(null);
        setActiveSection('timeline');
      }
    } finally {
      setIsSaving(false);
    }
  };

  // Category CRUD
  const handleSaveCategory = async () => {
    if (!catNameInput.trim() || !activeBook) return;
    setIsSaving(true);
    try {
      const catId =
        editingCat?.id ||
        'icat_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6);

      const catRecord: IdeaCategory = {
        id: catId,
        bookId: activeBook.id,
        name: catNameInput.trim(),
        color: catColorInput,
        order: editingCat?.order || categories.length,
      };

      await dbService.saveIdeaCategory(catRecord);
      const updated = await dbService.getIdeaCategories(activeBook.id);
      setCategories(updated);
      setEditingCat(null);
      setCatNameInput('');
      toast('Categoría de ideas guardada', 'success');
    } finally {
      setIsSaving(false);
    }
  };

  const handleDeleteCategory = async () => {
    if (!deletingCat || !activeBook) return;
    setIsSaving(true);
    try {
      await dbService.deleteIdeaCategoryAndReassign(
        deletingCat.id,
        reassignTargetCatId,
        activeBook.id
      );
      await loadData();
      setDeletingCat(null);
      toast('Categoría eliminada con reasignación segura', 'success');
    } finally {
      setIsSaving(false);
    }
  };

  const handleResetCategories = async () => {
    if (!activeBook) return;
    setIsSaving(true);
    try {
      const defaults = await dbService.resetIdeaCategoriesToDefault(activeBook.id);
      setCategories(defaults);
      await loadData();
      toast('Categorías de ideas restablecidas', 'info');
    } finally {
      setIsSaving(false);
    }
  };

  // Resolve an idea's tray (fallback to status if tray field is unset)
  const getIdeaTray = (i: Idea): IdeaTray => {
    if (i.tray) return i.tray;
    if (i.isCompleted || i.status === 'utilizada') return 'realizadas';
    if (i.status === 'descartada') return 'descartadas';
    return 'en_espera';
  };

  // Filtered ideas based on current active tray, category filter, and search
  const filteredIdeas = useMemo(() => {
    return ideas.filter((item) => {
      const itemTray = getIdeaTray(item);
      if (itemTray !== activeTray) return false;

      if (categoryFilter !== 'todos' && item.categoryId !== categoryFilter) return false;

      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const mTitle = item.title.toLowerCase().includes(q);
        const mContent = item.content.toLowerCase().includes(q);
        const mTag = (item.tags || []).some((t) => t.toLowerCase().includes(q));
        return mTitle || mContent || mTag;
      }
      return true;
    });
  }, [ideas, activeTray, categoryFilter, searchQuery]);

  // Counts per tray
  const trayCounts = useMemo(() => {
    const counts: Record<IdeaTray, number> = {
      en_espera: 0,
      realizadas: 0,
      descartadas: 0,
    };
    ideas.forEach((i) => {
      const t = getIdeaTray(i);
      counts[t] = (counts[t] || 0) + 1;
    });
    return counts;
  }, [ideas]);

  return (
    <div className="flex flex-col lg:flex-row gap-6 min-h-[calc(100vh-10rem)] relative">
      {/* Collapsed toggle */}
      {!isSidebarOpen && (
        <button
          onClick={() => setIsSidebarOpen(true)}
          className={`fixed left-2 bottom-6 z-40 p-2.5 rounded-xl border shadow-lg flex items-center gap-2 text-xs font-semibold backdrop-blur-md transition-all ${theme.bgCard} ${theme.borderCard} ${theme.textPrimary}`}
          title="Mostrar bandejas y categorías"
        >
          <PanelLeftOpen className="w-4 h-4" />
          <span className="hidden sm:inline">Bandejas ({ideas.length})</span>
        </button>
      )}

      {/* Left Sidebar: 3 Distinct Trays & Categories */}
      {isSidebarOpen && (
        <div
          className={`w-full lg:w-72 shrink-0 rounded-2xl border p-4 flex flex-col justify-between shadow-xs transition-all duration-300 ${theme.bgCard} ${theme.borderCard}`}
        >
          <div className="space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-stone-200 dark:border-stone-800">
              <div>
                <h3 className={`font-serif font-bold text-base ${theme.textPrimary}`}>
                  Bandejas de Ideas
                </h3>
                <p className="text-[11px] text-stone-500">{ideas.length} notas al aire</p>
              </div>
              <div className="flex items-center gap-1">
                <button
                  onClick={() => setIsCatManagerOpen(true)}
                  className="p-2 rounded-xl text-stone-400 hover:text-stone-700 dark:hover:text-stone-200 hover:bg-black/5"
                  title="Gestionar categorías de ideas"
                >
                  <Sliders className="w-4 h-4" />
                </button>
                <button
                  onClick={() => openEditModal()}
                  className={`p-2 rounded-xl text-xs font-semibold shadow-sm ${theme.primaryBtn}`}
                  title="Nueva idea"
                >
                  <Plus className="w-4 h-4" />
                </button>
                <button
                  onClick={() => setIsSidebarOpen(false)}
                  className="p-2 rounded-xl text-stone-400 hover:text-stone-700 dark:hover:text-stone-200 hover:bg-black/5"
                  title="Plegar panel lateral"
                >
                  <PanelLeftClose className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* 3 DISTINCT TRAYS */}
            <div className="space-y-1.5">
              {/* 1. En espera */}
              <button
                onClick={() => setActiveTray('en_espera')}
                className={`w-full p-3 rounded-xl border text-left flex items-center justify-between transition-all ${
                  activeTray === 'en_espera'
                    ? `${theme.activeBorder} ${theme.accentBadge} shadow-xs font-semibold`
                    : 'border-stone-200 dark:border-stone-800 hover:bg-black/5 dark:hover:bg-white/5 text-stone-700 dark:text-stone-300'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <div className={`p-1.5 rounded-lg ${theme.accentBadge} ${theme.accentText}`}>
                    <Inbox className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="text-xs font-bold block">1. En Espera</span>
                    <span className="text-[10px] text-stone-500">Pendientes de desarrollo</span>
                  </div>
                </div>
                <span className={`text-xs font-mono font-bold px-2 py-0.5 rounded-full ${theme.accentBadge} ${theme.accentText}`}>
                  {trayCounts.en_espera}
                </span>
              </button>

              {/* 2. Realizadas */}
              <button
                onClick={() => setActiveTray('realizadas')}
                className={`w-full p-3 rounded-xl border text-left flex items-center justify-between transition-all ${
                  activeTray === 'realizadas'
                    ? `${theme.activeBorder} ${theme.accentBadge} shadow-xs font-semibold`
                    : 'border-stone-200 dark:border-stone-800 hover:bg-black/5 dark:hover:bg-white/5 text-stone-700 dark:text-stone-300'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <div className="p-1.5 rounded-lg bg-emerald-500/10 text-emerald-600">
                    <CheckSquare className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="text-xs font-bold block">2. Realizadas</span>
                    <span className="text-[10px] text-stone-500">Incorporadas o completas</span>
                  </div>
                </div>
                <span className="text-xs font-mono font-bold px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-700 dark:text-emerald-400">
                  {trayCounts.realizadas}
                </span>
              </button>

              {/* 3. Descartadas */}
              <button
                onClick={() => setActiveTray('descartadas')}
                className={`w-full p-3 rounded-xl border text-left flex items-center justify-between transition-all ${
                  activeTray === 'descartadas'
                    ? `${theme.activeBorder} ${theme.accentBadge} shadow-xs font-semibold`
                    : 'border-stone-200 dark:border-stone-800 hover:bg-black/5 dark:hover:bg-white/5 text-stone-700 dark:text-stone-300'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <div className="p-1.5 rounded-lg bg-stone-200 dark:bg-stone-800 text-stone-500">
                    <Archive className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="text-xs font-bold block">3. Descartadas</span>
                    <span className="text-[10px] text-stone-500">Archivadas como referencia</span>
                  </div>
                </div>
                <span className="text-xs font-mono font-bold px-2 py-0.5 rounded-full bg-stone-100 dark:bg-stone-800 text-stone-500">
                  {trayCounts.descartadas}
                </span>
              </button>
            </div>

            {/* Categories filter */}
            <div className="pt-3 border-t border-stone-200 dark:border-stone-800 space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="font-semibold text-stone-600 dark:text-stone-400">
                  Filtrar por Categoría
                </span>
                <button
                  onClick={() => setIsCatManagerOpen(true)}
                  className="text-[10px] text-stone-400 hover:underline"
                >
                  Gestionar
                </button>
              </div>

              <div className="space-y-1 max-h-44 overflow-y-auto pr-1">
                <button
                  onClick={() => setCategoryFilter('todos')}
                  className={`w-full text-left px-2.5 py-1.5 rounded-lg text-xs transition-all flex items-center justify-between ${
                    categoryFilter === 'todos'
                      ? `${theme.activeTab} font-semibold shadow-xs`
                      : 'text-stone-500 hover:bg-black/5 dark:hover:bg-white/5'
                  }`}
                >
                  <span>Todas las categorías</span>
                </button>
                {categories.map((c) => (
                  <button
                    key={c.id}
                    onClick={() => setCategoryFilter(c.id)}
                    className={`w-full text-left px-2.5 py-1.5 rounded-lg text-xs transition-all flex items-center justify-between ${
                      categoryFilter === c.id
                        ? `${theme.activeTab} font-semibold shadow-xs`
                        : 'text-stone-500 hover:bg-black/5 dark:hover:bg-white/5'
                    }`}
                  >
                    <div className="flex items-center gap-2 truncate">
                      <span
                        className="w-2.5 h-2.5 rounded-full shrink-0"
                        style={{ backgroundColor: c.color || theme.accentHex }}
                      />
                      <span className="truncate">{c.name}</span>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          </div>

          <div className="pt-3 border-t border-stone-200 dark:border-stone-800 text-[11px] text-stone-500 flex items-center justify-between">
            <span>Arrastra o mueve de bandeja</span>
            <Lightbulb className="w-3.5 h-3.5 text-stone-400" />
          </div>
        </div>
      )}

      {/* Main Content: Ideas Canvas & Toolbar */}
      <div className="flex-1 space-y-5 min-w-0">
        {/* Top Controls Bar */}
        <div
          className={`p-4 rounded-2xl border shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4 ${theme.bgCard} ${theme.borderCard}`}
        >
          <div className="flex items-center gap-3 flex-1 max-w-md">
            <div className="relative w-full">
              <Search className="w-3.5 h-3.5 text-stone-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Buscar ideas por título, apunte o etiqueta..."
                className={`w-full pl-9 pr-3 py-1.5 rounded-xl border text-xs ${theme.borderCard} ${theme.bgCard} ${theme.textPrimary} focus:outline-none`}
              />
            </div>
          </div>

          <div className="flex items-center gap-2">
            <div
              className={`p-1 rounded-xl border flex items-center gap-1 ${theme.borderCard} ${theme.bgCard}`}
            >
              <button
                onClick={() => setViewMode('grid')}
                className={`p-1.5 rounded-lg ${
                  viewMode === 'grid'
                    ? `${theme.activeTab} shadow-xs`
                    : 'text-stone-400 hover:text-stone-700'
                }`}
                title="Vista en cuadrícula"
              >
                <LayoutGrid className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={() => setViewMode('list')}
                className={`p-1.5 rounded-lg ${
                  viewMode === 'list'
                    ? `${theme.activeTab} shadow-xs`
                    : 'text-stone-400 hover:text-stone-700'
                }`}
                title="Vista en lista"
              >
                <List className="w-3.5 h-3.5" />
              </button>
            </div>

            <button
              onClick={() => openEditModal()}
              className={`flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-semibold shadow-xs ${theme.primaryBtn}`}
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Registrar Idea</span>
            </button>
          </div>
        </div>

        {/* Ideas Grid or List */}
        {filteredIdeas.length === 0 ? (
          <div
            className={`p-16 rounded-3xl border text-center shadow-xs ${theme.bgCard} ${theme.borderCard}`}
          >
            <Lightbulb className="w-12 h-12 mx-auto mb-3 text-stone-400 opacity-60" />
            <h3 className={`font-serif text-lg font-bold ${theme.textPrimary}`}>
              No hay ideas en la bandeja "{activeTray.replace('_', ' ')}"
            </h3>
            <p className="text-xs text-stone-500 max-w-sm mx-auto mt-1 mb-4">
              Anota destellos de inspiración, diálogos o giros antes de que escapen.
            </p>
            <button
              onClick={() => openEditModal()}
              className={`px-5 py-2.5 rounded-xl text-xs font-semibold shadow-md ${theme.primaryBtn}`}
            >
              Añadir Idea
            </button>
          </div>
        ) : viewMode === 'grid' ? (
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
            {filteredIdeas.map((idea) => {
              const cat = categories.find((c) => c.id === idea.categoryId);
              const isRealizada = activeTray === 'realizadas' || idea.isCompleted;

              return (
                <div
                  key={idea.id}
                  className={`p-5 rounded-2xl border shadow-xs flex flex-col justify-between transition-all duration-200 group relative ${theme.bgCard} ${theme.borderCard} ${
                    isRealizada ? 'opacity-85' : ''
                  }`}
                >
                  <div>
                    {/* Top category & tray controls */}
                    <div className="flex items-center justify-between gap-2 mb-3">
                      <div className="flex items-center gap-1.5">
                        {/* Checkbox for Realizada completion */}
                        <button
                          type="button"
                          onClick={() => handleToggleCompleted(idea)}
                          className="text-stone-400 hover:text-emerald-600 transition-colors"
                          title={isRealizada ? 'Marcar como pendiente' : 'Marcar como realizada'}
                        >
                          {isRealizada ? (
                            <CheckSquare className="w-4 h-4 text-emerald-600" />
                          ) : (
                            <Square className="w-4 h-4" />
                          )}
                        </button>

                        {cat && (
                          <span
                            className="text-[10px] px-2 py-0.5 rounded-full font-bold uppercase tracking-wider text-white"
                            style={{ backgroundColor: cat.color || theme.accentHex }}
                          >
                            {cat.name}
                          </span>
                        )}
                      </div>

                      <div className="flex items-center gap-1 opacity-60 group-hover:opacity-100">
                        <button
                          onClick={() => openEditModal(idea)}
                          className="p-1 rounded text-stone-400 hover:text-stone-700 dark:hover:text-stone-200"
                          title="Editar"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => setDeleteConfirmIdea(idea)}
                          className="p-1 rounded text-stone-400 hover:text-rose-600"
                          title="Eliminar"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>

                    <h4
                      className={`text-sm font-bold font-serif mb-2 ${theme.textPrimary} ${
                        isRealizada ? 'line-through text-stone-400 dark:text-stone-500' : ''
                      }`}
                    >
                      {idea.title}
                    </h4>

                    <p
                      className={`text-xs leading-relaxed font-serif whitespace-pre-line line-clamp-4 text-stone-600 dark:text-stone-300 ${
                        isRealizada ? 'line-through opacity-70' : ''
                      }`}
                    >
                      {idea.content}
                    </p>
                  </div>

                  {/* Bottom Tray & Conversion Buttons */}
                  <div className="pt-3 mt-4 border-t border-stone-200 dark:border-stone-800 space-y-2">
                    {/* Quick Move Between Trays */}
                    <div className="flex items-center justify-between text-[11px] text-stone-400">
                      <span>Mover bandeja:</span>
                      <div className="flex items-center gap-1">
                        {activeTray !== 'en_espera' && (
                          <button
                            onClick={() => handleMoveIdeaTray(idea, 'en_espera')}
                            className="px-2 py-0.5 rounded bg-stone-100 dark:bg-stone-800 hover:bg-stone-200 text-stone-700 dark:text-stone-300"
                          >
                            En Espera
                          </button>
                        )}
                        {activeTray !== 'realizadas' && (
                          <button
                            onClick={() => handleMoveIdeaTray(idea, 'realizadas')}
                            className="px-2 py-0.5 rounded bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-700 dark:text-emerald-400"
                          >
                            Realizada
                          </button>
                        )}
                        {activeTray !== 'descartadas' && (
                          <button
                            onClick={() => handleMoveIdeaTray(idea, 'descartadas')}
                            className="px-2 py-0.5 rounded bg-stone-200 dark:bg-stone-800 hover:bg-stone-300 text-stone-600 dark:text-stone-400"
                          >
                            Descartar
                          </button>
                        )}
                      </div>
                    </div>

                    {/* Convert Button */}
                    <button
                      onClick={() => setConvertIdea(idea)}
                      className={`w-full py-1.5 px-3 rounded-xl text-xs font-semibold border flex items-center justify-center gap-1.5 transition-all shadow-xs ${theme.accentBadge} ${theme.accentText} border-transparent hover:opacity-90`}
                    >
                      <Sparkles className="w-3.5 h-3.5" />
                      <span>Convertir en elemento de la obra</span>
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <div className={`rounded-2xl border divide-y shadow-xs ${theme.bgCard} ${theme.borderCard}`}>
            {filteredIdeas.map((idea) => {
              const cat = categories.find((c) => c.id === idea.categoryId);
              const isRealizada = activeTray === 'realizadas' || idea.isCompleted;

              return (
                <div
                  key={idea.id}
                  className="p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 group"
                >
                  <div className="flex items-start gap-3 min-w-0 flex-1">
                    <button
                      type="button"
                      onClick={() => handleToggleCompleted(idea)}
                      className="mt-0.5 text-stone-400 hover:text-emerald-600"
                    >
                      {isRealizada ? (
                        <CheckSquare className="w-4 h-4 text-emerald-600" />
                      ) : (
                        <Square className="w-4 h-4" />
                      )}
                    </button>

                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2">
                        <h4
                          className={`text-sm font-bold truncate ${theme.textPrimary} ${
                            isRealizada ? 'line-through text-stone-400' : ''
                          }`}
                        >
                          {idea.title}
                        </h4>
                        {cat && (
                          <span
                            className="text-[9px] px-2 py-0.5 rounded-full font-bold uppercase tracking-wider text-white shrink-0"
                            style={{ backgroundColor: cat.color || theme.accentHex }}
                          >
                            {cat.name}
                          </span>
                        )}
                      </div>
                      <p
                        className={`text-xs text-stone-500 line-clamp-1 mt-0.5 ${
                          isRealizada ? 'line-through opacity-70' : ''
                        }`}
                      >
                        {idea.content}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 self-end sm:self-auto shrink-0">
                    <button
                      onClick={() => setConvertIdea(idea)}
                      className={`px-2.5 py-1 rounded-lg text-xs font-semibold flex items-center gap-1 ${theme.accentBadge} ${theme.accentText}`}
                    >
                      <Sparkles className="w-3 h-3" /> Convertir
                    </button>
                    <button
                      onClick={() => openEditModal(idea)}
                      className="p-1.5 rounded-lg text-stone-400 hover:bg-black/5"
                    >
                      <Edit2 className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => setDeleteConfirmIdea(idea)}
                      className="p-1.5 rounded-lg text-stone-400 hover:text-rose-600 hover:bg-rose-500/10"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* CONVERT IDEA MODAL */}
      {convertIdea && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-150">
          <div
            className={`w-full max-w-md rounded-3xl border shadow-2xl p-6 ${theme.bgCard} ${theme.borderCard}`}
          >
            <div className="flex items-center justify-between pb-3 border-b border-stone-200 dark:border-stone-800">
              <div className="flex items-center gap-2">
                <div className={`p-2 rounded-xl ${theme.accentBadge} ${theme.accentText}`}>
                  <Sparkles className="w-5 h-5" />
                </div>
                <div>
                  <h3 className={`font-serif font-bold text-base ${theme.textPrimary}`}>
                    Convertir Idea en Elemento
                  </h3>
                  <p className="text-xs text-stone-500">
                    Crea una entidad formal conservando el texto original
                  </p>
                </div>
              </div>
              <button
                onClick={() => setConvertIdea(null)}
                className="p-1.5 rounded-lg text-stone-400 hover:bg-black/5"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="py-4 space-y-2">
              <button
                onClick={() => handleConvertIdea('chapter')}
                className="w-full p-3 rounded-xl border border-stone-200 dark:border-stone-800 hover:bg-black/5 dark:hover:bg-white/5 text-left flex items-center justify-between"
              >
                <div className="flex items-center gap-3">
                  <div className="p-2 rounded-lg bg-blue-500/10 text-blue-600">
                    <BookOpen className="w-4 h-4" />
                  </div>
                  <div>
                    <h5 className={`text-xs font-bold ${theme.textPrimary}`}>Nuevo Capítulo</h5>
                    <p className="text-[11px] text-stone-500">
                      Crear capítulo con el contenido de la idea
                    </p>
                  </div>
                </div>
                <ArrowRight className="w-4 h-4 text-stone-400" />
              </button>

              <button
                onClick={() => handleConvertIdea('character')}
                className="w-full p-3 rounded-xl border border-stone-200 dark:border-stone-800 hover:bg-black/5 dark:hover:bg-white/5 text-left flex items-center justify-between"
              >
                <div className="flex items-center gap-3">
                  <div className="p-2 rounded-lg bg-purple-500/10 text-purple-600">
                    <User className="w-4 h-4" />
                  </div>
                  <div>
                    <h5 className={`text-xs font-bold ${theme.textPrimary}`}>Ficha de Personaje</h5>
                    <p className="text-[11px] text-stone-500">
                      Convertir en personaje con biografía inicial
                    </p>
                  </div>
                </div>
                <ArrowRight className="w-4 h-4 text-stone-400" />
              </button>

              <button
                onClick={() => handleConvertIdea('detail')}
                className="w-full p-3 rounded-xl border border-stone-200 dark:border-stone-800 hover:bg-black/5 dark:hover:bg-white/5 text-left flex items-center justify-between"
              >
                <div className="flex items-center gap-3">
                  <div className="p-2 rounded-lg bg-emerald-500/10 text-emerald-600">
                    <Compass className="w-4 h-4" />
                  </div>
                  <div>
                    <h5 className={`text-xs font-bold ${theme.textPrimary}`}>Detalle del Mundo</h5>
                    <p className="text-[11px] text-stone-500">
                      Convertir en concepto, lugar o reliquia
                    </p>
                  </div>
                </div>
                <ArrowRight className="w-4 h-4 text-stone-400" />
              </button>

              <button
                onClick={() => handleConvertIdea('timeline')}
                className="w-full p-3 rounded-xl border border-stone-200 dark:border-stone-800 hover:bg-black/5 dark:hover:bg-white/5 text-left flex items-center justify-between"
              >
                <div className="flex items-center gap-3">
                  <div className="p-2 rounded-lg bg-rose-500/10 text-rose-600">
                    <Clock className="w-4 h-4" />
                  </div>
                  <div>
                    <h5 className={`text-xs font-bold ${theme.textPrimary}`}>Acontecimiento Temporal</h5>
                    <p className="text-[11px] text-stone-500">
                      Insertar en la línea de tiempo interactiva
                    </p>
                  </div>
                </div>
                <ArrowRight className="w-4 h-4 text-stone-400" />
              </button>
            </div>
          </div>
        </div>
      )}

      {/* CATEGORY MANAGER MODAL */}
      {isCatManagerOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-150">
          <div
            className={`w-full max-w-xl rounded-3xl border shadow-2xl p-6 ${theme.bgCard} ${theme.borderCard}`}
          >
            <div className="flex items-center justify-between pb-4 border-b border-stone-200 dark:border-stone-800">
              <div className="flex items-center gap-2.5">
                <div className={`p-2 rounded-xl ${theme.accentBadge} ${theme.accentText}`}>
                  <Sliders className="w-5 h-5" />
                </div>
                <div>
                  <h3 className={`font-serif font-bold text-lg ${theme.textPrimary}`}>
                    Categorías de Ideas
                  </h3>
                  <p className="text-xs text-stone-500">
                    Organiza tus apuntes por temas sin alterar su bandeja
                  </p>
                </div>
              </div>
              <button
                onClick={() => setIsCatManagerOpen(false)}
                className="p-1.5 rounded-lg text-stone-400 hover:bg-black/5"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="py-4 space-y-3">
              <div className="flex flex-col sm:flex-row gap-2">
                <input
                  type="text"
                  value={catNameInput}
                  onChange={(e) => setCatNameInput(e.target.value)}
                  placeholder="Nombre de categoría (ej: Diálogos, Giros)..."
                  className={`flex-1 px-3 py-2 rounded-xl border text-xs ${theme.borderCard} ${theme.bgCard} ${theme.textPrimary} focus:outline-none`}
                />
                <input
                  type="color"
                  value={catColorInput}
                  onChange={(e) => setCatColorInput(e.target.value)}
                  className="w-10 h-9 rounded-xl border p-0.5 cursor-pointer"
                  title="Color distintivo"
                />
                <button
                  type="button"
                  onClick={handleSaveCategory}
                  disabled={!catNameInput.trim()}
                  className={`px-4 py-2 rounded-xl text-xs font-semibold disabled:opacity-40 shadow-xs ${theme.primaryBtn}`}
                >
                  {editingCat ? 'Guardar' : 'Añadir'}
                </button>
              </div>

              <div className="space-y-1.5 max-h-56 overflow-y-auto pr-1 pt-2">
                {categories.map((c) => (
                  <div
                    key={c.id}
                    className="flex items-center justify-between p-2.5 rounded-xl border border-stone-200 dark:border-stone-800 bg-stone-50/50 dark:bg-stone-900/50 text-xs"
                  >
                    <div className="flex items-center gap-2">
                      <span
                        className="w-3.5 h-3.5 rounded-full inline-block shrink-0"
                        style={{ backgroundColor: c.color || '#2D5A43' }}
                      />
                      <span className={`font-medium ${theme.textPrimary}`}>{c.name}</span>
                    </div>

                    <div className="flex items-center gap-1">
                      <button
                        onClick={() => {
                          setEditingCat(c);
                          setCatNameInput(c.name);
                          setCatColorInput(c.color || '#2D5A43');
                        }}
                        className="p-1 rounded text-stone-400 hover:text-stone-700"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => {
                          setDeletingCat(c);
                          const remaining = categories.filter((other) => other.id !== c.id);
                          setReassignTargetCatId(remaining[0]?.id || 'sin_categoria');
                        }}
                        className="p-1 rounded text-stone-400 hover:text-rose-600"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="pt-4 border-t border-stone-200 dark:border-stone-800 flex items-center justify-between">
              <button
                type="button"
                onClick={handleResetCategories}
                className="text-xs text-stone-500 hover:text-stone-800 dark:hover:text-stone-200 flex items-center gap-1.5 underline"
              >
                <RotateCcw className="w-3 h-3" />
                <span>Restablecer categorías predeterminadas</span>
              </button>
              <button
                type="button"
                onClick={() => setIsCatManagerOpen(false)}
                className={`px-4 py-2 rounded-xl text-xs font-semibold shadow-xs ${theme.primaryBtn}`}
              >
                Cerrar
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Delete Category Reassignment Modal */}
      {deletingCat && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
          <div
            className={`w-full max-w-md rounded-2xl border shadow-2xl p-6 ${theme.bgCard} ${theme.borderCard}`}
          >
            <h3 className="font-serif font-bold text-lg text-rose-600 mb-2">
              Eliminar categoría "{deletingCat.name}"
            </h3>
            <p className="text-xs text-stone-600 dark:text-stone-400 mb-4 leading-relaxed">
              Para no perder la categorización de tus ideas, selecciona a qué categoría reasignarlas:
            </p>

            <select
              value={reassignTargetCatId}
              onChange={(e) => setReassignTargetCatId(e.target.value)}
              className={`w-full p-2.5 rounded-xl border text-xs mb-5 ${theme.borderCard} ${theme.bgCard} ${theme.textPrimary} focus:outline-none`}
            >
              <option value="sin_categoria">Dejar sin categoría ("sin_categoria")</option>
              {categories
                .filter((c) => c.id !== deletingCat.id)
                .map((c) => (
                  <option key={c.id} value={c.id}>
                    Reasignar a: {c.name}
                  </option>
                ))}
            </select>

            <div className="flex justify-end gap-3">
              <button
                type="button"
                onClick={() => setDeletingCat(null)}
                className="px-4 py-2 rounded-xl text-xs font-semibold border border-stone-300 dark:border-stone-700"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={handleDeleteCategory}
                className="px-4 py-2 rounded-xl text-xs font-semibold bg-rose-600 text-white shadow-md hover:bg-rose-700"
              >
                Confirmar y Reasignar
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Create / Edit Idea Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-150">
          <div
            className={`w-full max-w-xl rounded-3xl border shadow-2xl overflow-hidden flex flex-col ${theme.bgCard} ${theme.borderCard}`}
          >
            <div className="p-5 border-b border-stone-200 dark:border-stone-800 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className={`p-2 rounded-xl ${theme.accentBadge} ${theme.accentText}`}>
                  <Lightbulb className="w-5 h-5" />
                </div>
                <div>
                  <h3 className={`font-serif font-bold text-lg ${theme.textPrimary}`}>
                    {editingIdea ? 'Editar Idea' : 'Nueva Idea al Aire'}
                  </h3>
                  <p className="text-xs text-stone-500">Destello creativo sin censura</p>
                </div>
              </div>
              <button
                onClick={() => setIsModalOpen(false)}
                className="p-1.5 rounded-lg text-stone-400 hover:bg-black/5"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveIdea} className="p-6 space-y-4 max-h-[75vh] overflow-y-auto">
              <div>
                <label className="block text-xs font-semibold text-stone-700 dark:text-stone-300 mb-1">
                  Título de la idea *
                </label>
                <input
                  type="text"
                  required
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="Ej: El misterio del espejo roto en la torre"
                  className={`w-full px-3.5 py-2 rounded-xl border text-sm font-medium ${theme.borderCard} bg-stone-50/50 dark:bg-stone-900/50 ${theme.textPrimary} focus:outline-none`}
                />
              </div>

              {/* Tray & Category selection */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-stone-700 dark:text-stone-300 mb-1">
                    Bandeja
                  </label>
                  <select
                    value={tray}
                    onChange={(e) => setTray(e.target.value as IdeaTray)}
                    className={`w-full px-3 py-2 rounded-xl border text-xs font-medium ${theme.borderCard} bg-stone-50/50 dark:bg-stone-900/50 ${theme.textPrimary} focus:outline-none`}
                  >
                    <option value="en_espera">1. En Espera (Pendiente)</option>
                    <option value="realizadas">2. Realizada (Completada)</option>
                    <option value="descartadas">3. Descartada (Archivo)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-stone-700 dark:text-stone-300 mb-1">
                    Categoría
                  </label>
                  <select
                    value={categoryId}
                    onChange={(e) => setCategoryId(e.target.value)}
                    className={`w-full px-3 py-2 rounded-xl border text-xs font-medium ${theme.borderCard} bg-stone-50/50 dark:bg-stone-900/50 ${theme.textPrimary} focus:outline-none`}
                  >
                    {categories.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.name}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-700 dark:text-stone-300 mb-1">
                  Anotaciones y detalles
                </label>
                <textarea
                  rows={5}
                  value={content}
                  onChange={(e) => setContent(e.target.value)}
                  placeholder="Escribe libremente cualquier ocurrencia, fragmento de diálogo, pista o atmósfera..."
                  className={`w-full p-3 rounded-xl border text-xs font-serif ${theme.borderCard} bg-stone-50/50 dark:bg-stone-900/50 ${theme.textPrimary} focus:outline-none`}
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-4 border-t border-stone-200 dark:border-stone-800">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-xs font-semibold border border-stone-300 dark:border-stone-700 text-stone-700 dark:text-stone-300 hover:bg-black/5"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className={`px-5 py-2 rounded-xl text-xs font-semibold shadow-md ${theme.primaryBtn}`}
                >
                  {editingIdea ? 'Guardar Cambios' : 'Registrar Idea'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Idea Confirmation Modal */}
      {deleteConfirmIdea && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
          <div
            className={`w-full max-w-md rounded-2xl border shadow-2xl p-6 ${theme.bgCard} ${theme.borderCard}`}
          >
            <h3 className="font-serif font-bold text-lg text-rose-600 mb-2">
              ¿Eliminar "{deleteConfirmIdea.title}"?
            </h3>
            <p className="text-xs text-stone-600 dark:text-stone-400 mb-6 leading-relaxed">
              Estás a punto de borrar esta idea definitivamente.
            </p>
            <div className="flex justify-end gap-3">
              <button
                onClick={() => setDeleteConfirmIdea(null)}
                className="px-4 py-2 rounded-xl text-xs font-semibold border border-stone-300 dark:border-stone-700"
              >
                Cancelar
              </button>
              <button
                onClick={handleDeleteConfirm}
                className="px-4 py-2 rounded-xl text-xs font-semibold bg-rose-600 text-white hover:bg-rose-700 shadow-md"
              >
                Eliminar
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
