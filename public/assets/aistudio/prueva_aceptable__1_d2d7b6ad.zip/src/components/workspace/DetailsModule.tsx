import React, { useState, useEffect, useMemo } from 'react';
import {
  Plus,
  Search,
  Compass,
  MapPin,
  Shield,
  Layers,
  Sparkles,
  BookOpen,
  Users,
  Clock,
  Lightbulb,
  Edit2,
  Trash2,
  X,
  Check,
  Tag,
  Lock,
  HelpCircle,
  ArrowRight,
  Filter,
  Sliders,
  RotateCcw,
  PanelLeftClose,
  PanelLeftOpen,
  ArrowUp,
  ArrowDown,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { dbService } from '../../services/db';
import { WorldDetail, DetailCategory, Character, Chapter, Idea, TimelineEvent } from '../../types';
import { getTheme } from '../../utils/theme';

const ICON_COMPONENTS: Record<string, any> = {
  MapPin,
  Compass,
  Sparkles,
  Shield,
  Users,
  Lock,
  BookOpen,
  Layers,
  Clock,
  HelpCircle,
  Tag,
};

export const DetailsModule: React.FC = () => {
  const {
    activeBook,
    currentPalette,
    darkMode,
    toast,
    setIsSaving,
    navigateToEntity,
  } = useApp();

  const theme = getTheme(currentPalette, darkMode);

  const [details, setDetails] = useState<WorldDetail[]>([]);
  const [categories, setCategories] = useState<DetailCategory[]>([]);
  const [characters, setCharacters] = useState<Character[]>([]);
  const [chapters, setChapters] = useState<Chapter[]>([]);
  const [ideas, setIdeas] = useState<Idea[]>([]);
  const [timelineEvents, setTimelineEvents] = useState<TimelineEvent[]>([]);

  // Collapsible sidebar
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);

  const [selectedDetail, setSelectedDetail] = useState<WorldDetail | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<string>('todos');

  // Detail Modal State
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingDetail, setEditingDetail] = useState<WorldDetail | null>(null);
  const [deleteConfirmDetail, setDeleteConfirmDetail] = useState<WorldDetail | null>(null);

  // Category Management Modal State
  const [isCatManagerOpen, setIsCatManagerOpen] = useState(false);
  const [editingCat, setEditingCat] = useState<DetailCategory | null>(null);
  const [catNameInput, setCatNameInput] = useState('');
  const [catColorInput, setCatColorInput] = useState('#2D5A43');
  const [catIconInput, setCatIconInput] = useState('MapPin');
  const [deletingCat, setDeletingCat] = useState<DetailCategory | null>(null);
  const [reassignTargetCatId, setReassignTargetCatId] = useState<string>('sin_categoria');

  // Form Fields for WorldDetail
  const [name, setName] = useState('');
  const [category, setCategory] = useState<string>('lugares');
  const [description, setDescription] = useState('');
  const [historicalPeriod, setHistoricalPeriod] = useState('');
  const [tagInput, setTagInput] = useState('');
  const [tags, setTags] = useState<string[]>([]);
  const [immutableInfo, setImmutableInfo] = useState('');
  const [provisionalInfo, setProvisionalInfo] = useState('');
  const [relatedCharacterIds, setRelatedCharacterIds] = useState<string[]>([]);
  const [relatedChapterIds, setRelatedChapterIds] = useState<string[]>([]);
  const [relatedIdeaIds, setRelatedIdeaIds] = useState<string[]>([]);
  const [relatedTimelineEventIds, setRelatedTimelineEventIds] = useState<string[]>([]);

  const loadData = async () => {
    if (!activeBook) return;
    const cats = await dbService.getDetailCategories(activeBook.id);
    setCategories(cats);
    const dets = await dbService.getDetailsByBook(activeBook.id);
    setDetails(dets);
    const chars = await dbService.getCharactersByBook(activeBook.id);
    setCharacters(chars);
    const chaps = await dbService.getChaptersByBook(activeBook.id);
    setChapters(chaps);
    const ids = await dbService.getIdeasByBook(activeBook.id);
    setIdeas(ids);
    const evs = await dbService.getTimelineEventsByBook(activeBook.id);
    setTimelineEvents(evs);

    if (dets.length > 0 && !selectedDetail) {
      setSelectedDetail(dets[0]);
    } else if (selectedDetail) {
      const refreshed = dets.find((d) => d.id === selectedDetail.id) || null;
      setSelectedDetail(refreshed);
    }
  };

  useEffect(() => {
    loadData();
  }, [activeBook]);

  const openEditModal = (detail?: WorldDetail) => {
    if (detail) {
      setEditingDetail(detail);
      setName(detail.name);
      setCategory(detail.category);
      setDescription(detail.description);
      setHistoricalPeriod(detail.historicalPeriod || '');
      setTags(detail.tags || []);
      setImmutableInfo(detail.immutableInfo || '');
      setProvisionalInfo(detail.provisionalInfo || '');
      setRelatedCharacterIds(detail.relatedCharacterIds || []);
      setRelatedChapterIds(detail.relatedChapterIds || []);
      setRelatedIdeaIds(detail.relatedIdeaIds || []);
      setRelatedTimelineEventIds(detail.relatedTimelineEventIds || []);
    } else {
      setEditingDetail(null);
      setName('');
      setCategory(categories[0]?.id || 'lugares');
      setDescription('');
      setHistoricalPeriod('');
      setTags([]);
      setImmutableInfo('');
      setProvisionalInfo('');
      setRelatedCharacterIds([]);
      setRelatedChapterIds([]);
      setRelatedIdeaIds([]);
      setRelatedTimelineEventIds([]);
    }
    setTagInput('');
    setIsModalOpen(true);
  };

  const handleAddTag = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' || e.key === ',') {
      e.preventDefault();
      const val = tagInput.trim().replace(/^,|,$/g, '');
      if (val && !tags.includes(val)) {
        setTags([...tags, val]);
        setTagInput('');
      }
    }
  };

  const handleRemoveTag = (t: string) => {
    setTags(tags.filter((item) => item !== t));
  };

  const handleSaveDetail = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !activeBook) return;

    setIsSaving(true);
    try {
      const detailId =
        editingDetail?.id ||
        'det_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6);

      const record: WorldDetail = {
        id: detailId,
        bookId: activeBook.id,
        name: name.trim(),
        category: category as any,
        description: description.trim(),
        historicalPeriod: historicalPeriod.trim(),
        tags,
        immutableInfo: immutableInfo.trim(),
        provisionalInfo: provisionalInfo.trim(),
        relatedCharacterIds,
        relatedChapterIds,
        relatedIdeaIds,
        relatedTimelineEventIds,
        createdAt: editingDetail?.createdAt || new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };

      await dbService.saveDetail(record);
      await loadData();
      setSelectedDetail(record);
      setIsModalOpen(false);
      toast(
        editingDetail
          ? `Ficha "${record.name}" actualizada`
          : `Elemento "${record.name}" creado con éxito`,
        'success'
      );
    } finally {
      setIsSaving(false);
    }
  };

  const handleDeleteConfirm = async () => {
    if (!deleteConfirmDetail) return;
    setIsSaving(true);
    try {
      await dbService.deleteDetail(deleteConfirmDetail.id);
      await loadData();
      if (selectedDetail?.id === deleteConfirmDetail.id) {
        setSelectedDetail(null);
      }
      toast(`Elemento "${deleteConfirmDetail.name}" eliminado`, 'info');
      setDeleteConfirmDetail(null);
    } finally {
      setIsSaving(false);
    }
  };

  // CATEGORY MANAGEMENT
  const handleSaveCategory = async () => {
    if (!catNameInput.trim() || !activeBook) return;
    setIsSaving(true);
    try {
      const catId =
        editingCat?.id ||
        'cat_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6);

      const catRecord: DetailCategory = {
        id: catId,
        bookId: activeBook.id,
        name: catNameInput.trim(),
        color: catColorInput,
        icon: catIconInput,
        order: editingCat?.order || categories.length,
      };

      await dbService.saveDetailCategory(catRecord);
      const updated = await dbService.getDetailCategories(activeBook.id);
      setCategories(updated);
      setEditingCat(null);
      setCatNameInput('');
      toast('Categoría guardada correctamente', 'success');
    } finally {
      setIsSaving(false);
    }
  };

  const handleDeleteCategory = async () => {
    if (!deletingCat || !activeBook) return;
    setIsSaving(true);
    try {
      await dbService.deleteDetailCategoryAndReassign(
        deletingCat.id,
        reassignTargetCatId,
        activeBook.id
      );
      await loadData();
      setDeletingCat(null);
      toast(
        `Categoría eliminada. Elementos reasignados a "${reassignTargetCatId}".`,
        'success'
      );
    } finally {
      setIsSaving(false);
    }
  };

  const handleResetCategories = async () => {
    if (!activeBook) return;
    setIsSaving(true);
    try {
      const defaults = await dbService.resetDetailCategoriesToDefault(activeBook.id);
      setCategories(defaults);
      await loadData();
      toast('Categorías predeterminadas restablecidas', 'info');
    } finally {
      setIsSaving(false);
    }
  };

  const handleMoveCategory = async (index: number, direction: 'up' | 'down') => {
    const targetIdx = direction === 'up' ? index - 1 : index + 1;
    if (targetIdx < 0 || targetIdx >= categories.length) return;
    const reordered = [...categories];
    const [moved] = reordered.splice(index, 1);
    reordered.splice(targetIdx, 0, moved);
    setCategories(reordered);
    await dbService.saveDetailCategoryOrder(reordered);
  };

  // Filtered details
  const filteredDetails = useMemo(() => {
    return details.filter((d) => {
      if (categoryFilter !== 'todos' && d.category !== categoryFilter) return false;
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        return (
          d.name.toLowerCase().includes(q) ||
          d.description.toLowerCase().includes(q) ||
          (d.tags || []).some((t) => t.toLowerCase().includes(q))
        );
      }
      return true;
    });
  }, [details, categoryFilter, searchQuery]);

  return (
    <div className="flex flex-col lg:flex-row gap-6 min-h-[calc(100vh-10rem)] relative">
      {/* Toggle button when sidebar is collapsed */}
      {!isSidebarOpen && (
        <button
          onClick={() => setIsSidebarOpen(true)}
          className={`fixed left-2 bottom-6 z-40 p-2.5 rounded-xl border shadow-lg flex items-center gap-2 text-xs font-semibold backdrop-blur-md transition-all ${theme.bgCard} ${theme.borderCard} ${theme.textPrimary}`}
          title="Mostrar lista de detalles"
        >
          <PanelLeftOpen className="w-4 h-4" />
          <span className="hidden sm:inline">Detalles ({details.length})</span>
        </button>
      )}

      {/* Left List of World Details */}
      {isSidebarOpen && (
        <div
          className={`w-full lg:w-80 shrink-0 rounded-2xl border p-4 flex flex-col justify-between shadow-xs transition-all duration-300 ${theme.bgCard} ${theme.borderCard}`}
        >
          <div className="space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-stone-200 dark:border-stone-800">
              <div>
                <h3 className={`font-serif font-bold text-base ${theme.textPrimary}`}>
                  Detalles del Mundo ({details.length})
                </h3>
                <p className="text-[11px] text-stone-500">Lore y reglas del universo</p>
              </div>
              <div className="flex items-center gap-1">
                <button
                  onClick={() => setIsCatManagerOpen(true)}
                  className="p-2 rounded-xl text-stone-400 hover:text-stone-700 dark:hover:text-stone-200 hover:bg-black/5"
                  title="Gestionar categorías personalizadas"
                >
                  <Sliders className="w-4 h-4" />
                </button>
                <button
                  onClick={() => openEditModal()}
                  className={`p-2 rounded-xl text-xs font-semibold shadow-sm ${theme.primaryBtn}`}
                  title="Añadir nueva ficha del mundo"
                >
                  <Plus className="w-4 h-4" />
                </button>
                <button
                  onClick={() => setIsSidebarOpen(false)}
                  className="p-2 rounded-xl text-stone-400 hover:text-stone-700 dark:hover:text-stone-200 hover:bg-black/5"
                  title="Plegar panel lateral"
                >
                  <PanelLeftClose className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Search & Category Filter Pills */}
            <div className="space-y-2">
              <div className="relative">
                <Search className="w-3.5 h-3.5 text-stone-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Buscar lugares, reliquias, leyes..."
                  className={`w-full pl-9 pr-3 py-1.5 rounded-xl border text-xs ${theme.borderCard} ${theme.bgCard} ${theme.textPrimary} focus:outline-none`}
                />
              </div>

              <div className="flex gap-1 overflow-x-auto pb-1 text-[11px]">
                <button
                  onClick={() => setCategoryFilter('todos')}
                  className={`px-2 py-0.5 rounded-md whitespace-nowrap transition-all ${
                    categoryFilter === 'todos'
                      ? `${theme.activeTab} font-semibold shadow-xs`
                      : 'bg-stone-100 dark:bg-stone-800 text-stone-500 hover:bg-stone-200'
                  }`}
                >
                  Todos ({details.length})
                </button>
                {categories.map((c) => {
                  const isAct = categoryFilter === c.id;
                  return (
                    <button
                      key={c.id}
                      onClick={() => setCategoryFilter(c.id)}
                      className={`px-2 py-0.5 rounded-md whitespace-nowrap transition-all flex items-center gap-1 ${
                        isAct
                          ? `${theme.activeTab} font-semibold shadow-xs`
                          : 'bg-stone-100 dark:bg-stone-800 text-stone-500 hover:bg-stone-200'
                      }`}
                    >
                      {c.color && (
                        <span
                          className="w-2 h-2 rounded-full inline-block"
                          style={{ backgroundColor: c.color }}
                        />
                      )}
                      <span>{c.name}</span>
                    </button>
                  );
                })}

                {/* Visible + button at end of list (Req 9) */}
                <button
                  type="button"
                  onClick={() => {
                    setEditingCat(null);
                    setCatNameInput('');
                    setCatColorInput('#2D5A43');
                    setIsCatManagerOpen(true);
                  }}
                  className="px-2 py-0.5 rounded-md whitespace-nowrap transition-all border border-dashed border-stone-300 dark:border-stone-700 text-stone-600 dark:text-stone-300 hover:text-stone-900 dark:hover:text-stone-100 hover:border-amber-500 flex items-center gap-1 shrink-0 font-bold text-[11px]"
                  title="Agregar nueva categoría (+)"
                >
                  <Plus className="w-3 h-3" />
                  <span>Categoría</span>
                </button>
              </div>
            </div>

            {/* Items list */}
            <div className="space-y-1.5 max-h-[58vh] overflow-y-auto pr-1">
              {filteredDetails.length === 0 ? (
                <div className="text-center py-8 text-stone-400 text-xs">
                  No hay elementos en esta categoría.
                </div>
              ) : (
                filteredDetails.map((det) => {
                  const isSelected = selectedDetail?.id === det.id;
                  const detCat = categories.find(
                    (c) => c.id === det.category || c.name.toLowerCase() === det.category.toLowerCase()
                  );
                  const IconComponent =
                    detCat?.icon && ICON_COMPONENTS[detCat.icon]
                      ? ICON_COMPONENTS[detCat.icon]
                      : Compass;

                  return (
                    <div
                      key={det.id}
                      onClick={() => setSelectedDetail(det)}
                      className={`p-3 rounded-xl border cursor-pointer transition-all flex items-center justify-between ${
                        isSelected
                          ? `${theme.activeBorder} ${theme.accentBadge} shadow-xs`
                          : `${theme.borderCard} hover:bg-black/5 dark:hover:bg-white/5`
                      }`}
                    >
                      <div className="flex items-center gap-2.5 min-w-0 pr-2">
                        <div
                          className="p-2 rounded-lg shrink-0 text-white shadow-xs"
                          style={{
                            backgroundColor: detCat?.color || theme.accentHex,
                          }}
                        >
                          <IconComponent className="w-3.5 h-3.5" />
                        </div>
                        <div className="min-w-0">
                          <h4
                            className={`text-xs font-bold truncate ${
                              isSelected ? theme.textPrimary : 'text-stone-800 dark:text-stone-200'
                            }`}
                          >
                            {det.name}
                          </h4>
                          <div className="text-[10px] text-stone-500 truncate mt-0.5">
                            {detCat?.name || det.category}
                          </div>
                        </div>
                      </div>
                      {det.immutableInfo && (
                        <span title="Canon Inmutable" className={`shrink-0 ${theme.accentText}`}>
                          <Lock className="w-3 h-3" />
                        </span>
                      )}
                    </div>
                  );
                })
              )}
            </div>
          </div>

          <div className="pt-3 border-t border-stone-200 dark:border-stone-800 text-[11px] text-stone-500 flex items-center justify-between">
            <span>{categories.length} categorías configuradas</span>
            <button
              onClick={() => setIsCatManagerOpen(true)}
              className="text-stone-400 hover:text-stone-700 dark:hover:text-stone-200 underline text-[10px]"
            >
              Editar
            </button>
          </div>
        </div>
      )}

      {/* Right: Full Detail Content */}
      {selectedDetail ? (
        <div className="flex-1 space-y-6 min-w-0">
          {/* Header Card */}
          <div
            className={`p-6 rounded-3xl border shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4 ${theme.bgCard} ${theme.borderCard}`}
          >
            <div>
              <div className="flex items-center gap-2 mb-1">
                <span
                  className="text-[11px] px-2.5 py-0.5 rounded-full font-bold uppercase tracking-wider text-white"
                  style={{
                    backgroundColor:
                      categories.find((c) => c.id === selectedDetail.category)?.color ||
                      theme.accentHex,
                  }}
                >
                  {categories.find((c) => c.id === selectedDetail.category)?.name ||
                    selectedDetail.category}
                </span>
                {selectedDetail.historicalPeriod && (
                  <span className="text-xs text-stone-500 font-mono">
                    • Era: {selectedDetail.historicalPeriod}
                  </span>
                )}
              </div>
              <h2 className={`font-serif text-2xl font-bold ${theme.textPrimary}`}>
                {selectedDetail.name}
              </h2>
            </div>

            <div className="flex items-center gap-2 self-start sm:self-auto">
              <button
                onClick={() => openEditModal(selectedDetail)}
                className={`flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-semibold shadow-xs ${theme.primaryBtn}`}
              >
                <Edit2 className="w-3.5 h-3.5" />
                <span>Editar Elemento</span>
              </button>
              <button
                onClick={() => setDeleteConfirmDetail(selectedDetail)}
                className="p-2 rounded-xl border border-rose-300 text-rose-600 hover:bg-rose-500/10"
                title="Eliminar elemento"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Core Description */}
          <div className={`p-6 rounded-3xl border shadow-xs space-y-3 ${theme.bgCard} ${theme.borderCard}`}>
            <h4 className={`text-xs font-bold uppercase tracking-wider ${theme.accentText}`}>
              Descripción y Significado en la Trama
            </h4>
            <p className={`text-sm leading-relaxed font-serif whitespace-pre-line ${theme.textPrimary}`}>
              {selectedDetail.description || 'Sin descripción detallada.'}
            </p>
          </div>

          {/* Canon & Provisional Info */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Immutable Info */}
            <div className={`p-5 rounded-2xl border shadow-xs space-y-2 ${theme.bgCard} ${theme.borderCard}`}>
              <div className="flex items-center gap-1.5 text-xs font-bold text-emerald-800 dark:text-emerald-300 uppercase tracking-wider">
                <Lock className="w-3.5 h-3.5 text-emerald-600" />
                <span>Canon Inmutable (No Cambiar)</span>
              </div>
              <p className="text-xs leading-relaxed text-stone-600 dark:text-stone-300 font-serif">
                {selectedDetail.immutableInfo || 'Sin restricciones canónicas absolutas.'}
              </p>
            </div>

            {/* Provisional Info */}
            <div className={`p-5 rounded-2xl border shadow-xs space-y-2 ${theme.bgCard} ${theme.borderCard}`}>
              <div className={`flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider ${theme.accentText}`}>
                <Sparkles className="w-3.5 h-3.5" />
                <span>Ideas Provisionales (Sujeto a cambios)</span>
              </div>
              <p className="text-xs leading-relaxed text-stone-600 dark:text-stone-300 font-serif">
                {selectedDetail.provisionalInfo || 'Sin notas provisionales.'}
              </p>
            </div>
          </div>

          {/* Connected Entities */}
          <div className={`p-5 rounded-2xl border shadow-xs space-y-4 ${theme.bgCard} ${theme.borderCard}`}>
            <h4 className={`text-xs font-bold uppercase tracking-wider ${theme.textPrimary}`}>
              Conexiones Narrativas Cruzadas
            </h4>

            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3">
              {/* Characters */}
              <div className="p-3 rounded-xl border border-stone-200 dark:border-stone-800 bg-stone-50/50 dark:bg-stone-900/50">
                <span className="text-[10px] font-bold text-stone-400 uppercase tracking-wider block mb-1">
                  Personajes ({selectedDetail.relatedCharacterIds?.length || 0})
                </span>
                <div className="space-y-1">
                  {(selectedDetail.relatedCharacterIds || []).map((id) => {
                    const c = characters.find((char) => char.id === id);
                    return (
                      <span key={id} className="text-xs font-medium block truncate text-stone-700 dark:text-stone-300">
                        • {c ? c.name : id}
                      </span>
                    );
                  })}
                </div>
              </div>

              {/* Chapters */}
              <div className="p-3 rounded-xl border border-stone-200 dark:border-stone-800 bg-stone-50/50 dark:bg-stone-900/50">
                <span className="text-[10px] font-bold text-stone-400 uppercase tracking-wider block mb-1">
                  Capítulos ({selectedDetail.relatedChapterIds?.length || 0})
                </span>
                <div className="space-y-1">
                  {(selectedDetail.relatedChapterIds || []).map((id) => {
                    const ch = chapters.find((chap) => chap.id === id);
                    return (
                      <span key={id} className="text-xs font-medium block truncate text-stone-700 dark:text-stone-300">
                        • {ch ? ch.title : id}
                      </span>
                    );
                  })}
                </div>
              </div>

              {/* Timeline Events */}
              <div className="p-3 rounded-xl border border-stone-200 dark:border-stone-800 bg-stone-50/50 dark:bg-stone-900/50">
                <span className="text-[10px] font-bold text-stone-400 uppercase tracking-wider block mb-1">
                  Línea Temporal ({selectedDetail.relatedTimelineEventIds?.length || 0})
                </span>
                <div className="space-y-1">
                  {(selectedDetail.relatedTimelineEventIds || []).map((id) => {
                    const ev = timelineEvents.find((e) => e.id === id);
                    return (
                      <span key={id} className="text-xs font-medium block truncate text-stone-700 dark:text-stone-300">
                        • {ev ? ev.title : id}
                      </span>
                    );
                  })}
                </div>
              </div>

              {/* Ideas */}
              <div className="p-3 rounded-xl border border-stone-200 dark:border-stone-800 bg-stone-50/50 dark:bg-stone-900/50">
                <span className="text-[10px] font-bold text-stone-400 uppercase tracking-wider block mb-1">
                  Ideas Vinculadas ({selectedDetail.relatedIdeaIds?.length || 0})
                </span>
                <div className="space-y-1">
                  {(selectedDetail.relatedIdeaIds || []).map((id) => {
                    const i = ideas.find((idItem) => idItem.id === id);
                    return (
                      <span key={id} className="text-xs font-medium block truncate text-stone-700 dark:text-stone-300">
                        • {i ? i.title : id}
                      </span>
                    );
                  })}
                </div>
              </div>
            </div>
          </div>
        </div>
      ) : (
        <div
          className={`flex-1 p-16 rounded-3xl border text-center flex flex-col items-center justify-center ${theme.bgCard} ${theme.borderCard}`}
        >
          <Compass className="w-12 h-12 mb-3 text-stone-400 opacity-60" />
          <h3 className={`font-serif text-lg font-bold ${theme.textPrimary}`}>
            No hay ningún elemento del mundo seleccionado
          </h3>
          <p className="text-xs text-stone-500 max-w-sm mt-1 mb-4">
            Documenta geografía, magia, leyes, reliquias y linajes de tu universo creativo.
          </p>
          <button
            onClick={() => openEditModal()}
            className={`px-5 py-2.5 rounded-xl text-xs font-semibold shadow-md ${theme.primaryBtn}`}
          >
            Crear Ficha del Mundo
          </button>
        </div>
      )}

      {/* CATEGORY MANAGER MODAL */}
      {isCatManagerOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-150">
          <div
            className={`w-full max-w-xl rounded-3xl border shadow-2xl p-6 ${theme.bgCard} ${theme.borderCard}`}
          >
            <div className="flex items-center justify-between pb-4 border-b border-stone-200 dark:border-stone-800">
              <div className="flex items-center gap-2.5">
                <div className={`p-2 rounded-xl ${theme.accentBadge} ${theme.accentText}`}>
                  <Sliders className="w-5 h-5" />
                </div>
                <div>
                  <h3 className={`font-serif font-bold text-lg ${theme.textPrimary}`}>
                    Personalización de Categorías del Mundo
                  </h3>
                  <p className="text-xs text-stone-500">
                    Crea, renombra, colorea o reasigna categorías para tus fichas
                  </p>
                </div>
              </div>
              <button
                onClick={() => setIsCatManagerOpen(false)}
                className="p-1.5 rounded-lg text-stone-400 hover:bg-black/5"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Category Form */}
            <div className="py-4 space-y-3">
              <div className="flex flex-col sm:flex-row gap-2">
                <input
                  type="text"
                  value={catNameInput}
                  onChange={(e) => setCatNameInput(e.target.value)}
                  placeholder="Nombre de nueva categoría..."
                  className={`flex-1 px-3 py-2 rounded-xl border text-xs ${theme.borderCard} ${theme.bgCard} ${theme.textPrimary} focus:outline-none`}
                />
                <input
                  type="color"
                  value={catColorInput}
                  onChange={(e) => setCatColorInput(e.target.value)}
                  className="w-10 h-9 rounded-xl border p-0.5 cursor-pointer"
                  title="Color distintivo"
                />
                <button
                  type="button"
                  onClick={handleSaveCategory}
                  disabled={!catNameInput.trim()}
                  className={`px-4 py-2 rounded-xl text-xs font-semibold disabled:opacity-40 shadow-xs ${theme.primaryBtn}`}
                >
                  {editingCat ? 'Guardar' : 'Añadir'}
                </button>
              </div>

              {/* Existing Categories list */}
              <div className="space-y-1.5 max-h-56 overflow-y-auto pr-1 pt-2">
                {categories.map((c, index) => (
                  <div
                    key={c.id}
                    className="flex items-center justify-between p-2.5 rounded-xl border border-stone-200 dark:border-stone-800 bg-stone-50/50 dark:bg-stone-900/50 text-xs"
                  >
                    <div className="flex items-center gap-2">
                      <span
                        className="w-3.5 h-3.5 rounded-full inline-block shrink-0"
                        style={{ backgroundColor: c.color || '#2D5A43' }}
                      />
                      <span className={`font-medium ${theme.textPrimary}`}>{c.name}</span>
                    </div>

                    <div className="flex items-center gap-1">
                      <button
                        onClick={() => handleMoveCategory(index, 'up')}
                        disabled={index === 0}
                        className="p-1 rounded text-stone-400 hover:text-stone-700 disabled:opacity-30"
                        title="Subir orden"
                      >
                        <ArrowUp className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => handleMoveCategory(index, 'down')}
                        disabled={index === categories.length - 1}
                        className="p-1 rounded text-stone-400 hover:text-stone-700 disabled:opacity-30"
                        title="Bajar orden"
                      >
                        <ArrowDown className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => {
                          setEditingCat(c);
                          setCatNameInput(c.name);
                          setCatColorInput(c.color || '#2D5A43');
                        }}
                        className="p-1 rounded text-stone-400 hover:text-stone-700"
                        title="Renombrar / Editar"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => {
                          setDeletingCat(c);
                          const remaining = categories.filter((other) => other.id !== c.id);
                          setReassignTargetCatId(remaining[0]?.id || 'sin_categoria');
                        }}
                        className="p-1 rounded text-stone-400 hover:text-rose-600"
                        title="Eliminar con reasignación segura"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Reset to defaults button */}
            <div className="pt-4 border-t border-stone-200 dark:border-stone-800 flex items-center justify-between">
              <button
                type="button"
                onClick={handleResetCategories}
                className="text-xs text-stone-500 hover:text-stone-800 dark:hover:text-stone-200 flex items-center gap-1.5 underline"
              >
                <RotateCcw className="w-3 h-3" />
                <span>Restablecer categorías predeterminadas</span>
              </button>
              <button
                type="button"
                onClick={() => setIsCatManagerOpen(false)}
                className={`px-4 py-2 rounded-xl text-xs font-semibold shadow-xs ${theme.primaryBtn}`}
              >
                Cerrar
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Delete Category Reassignment Modal */}
      {deletingCat && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-150">
          <div
            className={`w-full max-w-md rounded-2xl border shadow-2xl p-6 ${theme.bgCard} ${theme.borderCard}`}
          >
            <h3 className="font-serif font-bold text-lg text-rose-600 mb-2">
              Eliminar categoría "{deletingCat.name}"
            </h3>
            <p className="text-xs text-stone-600 dark:text-stone-400 mb-4 leading-relaxed">
              Para evitar que los elementos asociados se borren por accidente, selecciona a qué
              categoría deseas reasignarlos:
            </p>

            <select
              value={reassignTargetCatId}
              onChange={(e) => setReassignTargetCatId(e.target.value)}
              className={`w-full p-2.5 rounded-xl border text-xs mb-5 ${theme.borderCard} ${theme.bgCard} ${theme.textPrimary} focus:outline-none`}
            >
              <option value="sin_categoria">Dejar sin categoría ("sin_categoria")</option>
              {categories
                .filter((c) => c.id !== deletingCat.id)
                .map((c) => (
                  <option key={c.id} value={c.id}>
                    Reasignar a: {c.name}
                  </option>
                ))}
            </select>

            <div className="flex justify-end gap-3">
              <button
                type="button"
                onClick={() => setDeletingCat(null)}
                className="px-4 py-2 rounded-xl text-xs font-semibold border border-stone-300 dark:border-stone-700"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={handleDeleteCategory}
                className="px-4 py-2 rounded-xl text-xs font-semibold bg-rose-600 text-white shadow-md hover:bg-rose-700"
              >
                Confirmar y Reasignar
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Create / Edit WorldDetail Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-150">
          <div
            className={`w-full max-w-2xl rounded-3xl border shadow-2xl overflow-hidden flex flex-col ${theme.bgCard} ${theme.borderCard}`}
          >
            <div className="p-5 border-b border-stone-200 dark:border-stone-800 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className={`p-2.5 rounded-2xl ${theme.accentBadge} ${theme.accentText}`}>
                  <Compass className="w-5 h-5" />
                </div>
                <div>
                  <h3 className={`font-serif font-bold text-lg ${theme.textPrimary}`}>
                    {editingDetail ? `Editar ${editingDetail.name}` : 'Nueva Ficha del Mundo'}
                  </h3>
                  <p className="text-xs text-stone-500">Lore, geografía, magia, instituciones y linajes</p>
                </div>
              </div>
              <button
                onClick={() => setIsModalOpen(false)}
                className="p-1.5 rounded-lg text-stone-400 hover:bg-black/5"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveDetail} className="p-6 space-y-5 max-h-[75vh] overflow-y-auto">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-stone-700 dark:text-stone-300 mb-1">
                    Nombre del elemento *
                  </label>
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="Ej: La Ciudad Flotante de Caelum"
                    className={`w-full px-3.5 py-2 rounded-xl border text-sm font-medium ${theme.borderCard} bg-stone-50/50 dark:bg-stone-900/50 ${theme.textPrimary} focus:outline-none`}
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-stone-700 dark:text-stone-300 mb-1">
                    Categoría
                  </label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                    className={`w-full px-3 py-2 rounded-xl border text-xs font-medium ${theme.borderCard} bg-stone-50/50 dark:bg-stone-900/50 ${theme.textPrimary} focus:outline-none`}
                  >
                    {categories.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.name}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-700 dark:text-stone-300 mb-1">
                  Descripción profunda
                </label>
                <textarea
                  rows={4}
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Historia, origen, geografía, importancia o función dramática..."
                  className={`w-full p-3 rounded-xl border text-xs font-serif ${theme.borderCard} bg-stone-50/50 dark:bg-stone-900/50 ${theme.textPrimary} focus:outline-none`}
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-emerald-800 dark:text-emerald-300 mb-1 flex items-center gap-1">
                    <Lock className="w-3 h-3 text-emerald-600" />
                    Canon Inmutable (Regla fija)
                  </label>
                  <textarea
                    rows={2}
                    value={immutableInfo}
                    onChange={(e) => setImmutableInfo(e.target.value)}
                    placeholder="Leyes que no se pueden violar sin romper la coherencia..."
                    className={`w-full p-2.5 rounded-xl border text-xs font-serif ${theme.borderCard} bg-stone-50/50 dark:bg-stone-900/50 ${theme.textPrimary} focus:outline-none`}
                  />
                </div>

                <div>
                  <label className={`block text-xs font-semibold mb-1 flex items-center gap-1 ${theme.accentText}`}>
                    <Sparkles className="w-3 h-3" />
                    Notas provisionales
                  </label>
                  <textarea
                    rows={2}
                    value={provisionalInfo}
                    onChange={(e) => setProvisionalInfo(e.target.value)}
                    placeholder="Ideas tentativas o misterios aún no resueltos..."
                    className={`w-full p-2.5 rounded-xl border text-xs font-serif ${theme.borderCard} bg-stone-50/50 dark:bg-stone-900/50 ${theme.textPrimary} focus:outline-none`}
                  />
                </div>
              </div>

              <div className="flex items-center justify-end gap-3 pt-4 border-t border-stone-200 dark:border-stone-800">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-xs font-semibold border border-stone-300 dark:border-stone-700 text-stone-700 dark:text-stone-300 hover:bg-black/5"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className={`px-5 py-2 rounded-xl text-xs font-semibold shadow-md ${theme.primaryBtn}`}
                >
                  {editingDetail ? 'Guardar Cambios' : 'Crear Ficha'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Item Confirmation Modal */}
      {deleteConfirmDetail && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
          <div
            className={`w-full max-w-md rounded-2xl border shadow-2xl p-6 ${theme.bgCard} ${theme.borderCard}`}
          >
            <h3 className="font-serif font-bold text-lg text-rose-600 mb-2">
              ¿Eliminar "{deleteConfirmDetail.name}"?
            </h3>
            <p className="text-xs text-stone-600 dark:text-stone-400 mb-6 leading-relaxed">
              Estás a punto de borrar esta ficha del mundo. Esta acción no se puede deshacer.
            </p>
            <div className="flex justify-end gap-3">
              <button
                onClick={() => setDeleteConfirmDetail(null)}
                className="px-4 py-2 rounded-xl text-xs font-semibold border border-stone-300 dark:border-stone-700"
              >
                Cancelar
              </button>
              <button
                onClick={handleDeleteConfirm}
                className="px-4 py-2 rounded-xl text-xs font-semibold bg-rose-600 text-white hover:bg-rose-700 shadow-md"
              >
                Eliminar
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
