import {
  Book,
  Chapter,
  AudioRecord,
  Character,
  WorldDetail,
  Idea,
  TimelineEvent,
  TimelineConnection,
  TimelineLane,
  DetailCategory,
  IdeaCategory,
  TimelineCategory,
  CharacterCategory,
  CustomPaletteConfig,
  CustomFontItem,
  AppSettings,
} from '../types';

const DB_NAME = 'PlumaTiempoDB';
const DB_VERSION = 3;

interface StoredAudio {
  id: string;
  bookId: string;
  chapterId: string;
  name: string;
  fileName: string;
  mimeType: string;
  size: number;
  duration: number;
  createdAt: string;
  notes: string;
  transcription?: string;
  blob?: Blob;
}

class DatabaseService {
  private dbPromise: Promise<IDBDatabase> | null = null;

  private openDB(): Promise<IDBDatabase> {
    if (this.dbPromise) return this.dbPromise;

    this.dbPromise = new Promise((resolve, reject) => {
      const request = indexedDB.open(DB_NAME, DB_VERSION);

      request.onupgradeneeded = (event) => {
        const db = (event.target as IDBOpenDBRequest).result;

        if (!db.objectStoreNames.contains('books')) {
          db.createObjectStore('books', { keyPath: 'id' });
        }
        if (!db.objectStoreNames.contains('chapters')) {
          const store = db.createObjectStore('chapters', { keyPath: 'id' });
          store.createIndex('bookId', 'bookId', { unique: false });
        }
        if (!db.objectStoreNames.contains('characters')) {
          const store = db.createObjectStore('characters', { keyPath: 'id' });
          store.createIndex('bookId', 'bookId', { unique: false });
        }
        if (!db.objectStoreNames.contains('characterCategories')) {
          const store = db.createObjectStore('characterCategories', { keyPath: 'id' });
          store.createIndex('bookId', 'bookId', { unique: false });
        }
        if (!db.objectStoreNames.contains('details')) {
          const store = db.createObjectStore('details', { keyPath: 'id' });
          store.createIndex('bookId', 'bookId', { unique: false });
        }
        if (!db.objectStoreNames.contains('detailCategories')) {
          const store = db.createObjectStore('detailCategories', { keyPath: 'id' });
          store.createIndex('bookId', 'bookId', { unique: false });
        }
        if (!db.objectStoreNames.contains('ideas')) {
          const store = db.createObjectStore('ideas', { keyPath: 'id' });
          store.createIndex('bookId', 'bookId', { unique: false });
        }
        if (!db.objectStoreNames.contains('ideaCategories')) {
          const store = db.createObjectStore('ideaCategories', { keyPath: 'id' });
          store.createIndex('bookId', 'bookId', { unique: false });
        }
        if (!db.objectStoreNames.contains('timelineEvents')) {
          const store = db.createObjectStore('timelineEvents', { keyPath: 'id' });
          store.createIndex('bookId', 'bookId', { unique: false });
        }
        if (!db.objectStoreNames.contains('timelineCategories')) {
          const store = db.createObjectStore('timelineCategories', { keyPath: 'id' });
          store.createIndex('bookId', 'bookId', { unique: false });
        }
        if (!db.objectStoreNames.contains('timelineConnections')) {
          const store = db.createObjectStore('timelineConnections', { keyPath: 'id' });
          store.createIndex('bookId', 'bookId', { unique: false });
        }
        if (!db.objectStoreNames.contains('timelineLanes')) {
          const store = db.createObjectStore('timelineLanes', { keyPath: 'id' });
          store.createIndex('bookId', 'bookId', { unique: false });
        }
        if (!db.objectStoreNames.contains('audios')) {
          const store = db.createObjectStore('audios', { keyPath: 'id' });
          store.createIndex('bookId', 'bookId', { unique: false });
          store.createIndex('chapterId', 'chapterId', { unique: false });
        }
        if (!db.objectStoreNames.contains('customPalettes')) {
          db.createObjectStore('customPalettes', { keyPath: 'id' });
        }
        if (!db.objectStoreNames.contains('customFonts')) {
          db.createObjectStore('customFonts', { keyPath: 'id' });
        }
        if (!db.objectStoreNames.contains('settings')) {
          db.createObjectStore('settings', { keyPath: 'key' });
        }
      };

      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });

    return this.dbPromise;
  }

  // --- Generic Helpers ---
  private async getAll<T>(storeName: string): Promise<T[]> {
    const db = await this.openDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(storeName, 'readonly');
      const store = tx.objectStore(storeName);
      const req = store.getAll();
      req.onsuccess = () => resolve(req.result || []);
      req.onerror = () => reject(req.error);
    });
  }

  private async getById<T>(storeName: string, id: string): Promise<T | null> {
    const db = await this.openDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(storeName, 'readonly');
      const store = tx.objectStore(storeName);
      const req = store.get(id);
      req.onsuccess = () => resolve(req.result || null);
      req.onerror = () => reject(req.error);
    });
  }

  private async getByIndex<T>(storeName: string, indexName: string, value: string): Promise<T[]> {
    const db = await this.openDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(storeName, 'readonly');
      const store = tx.objectStore(storeName);
      const idx = store.index(indexName);
      const req = idx.getAll(value);
      req.onsuccess = () => resolve(req.result || []);
      req.onerror = () => reject(req.error);
    });
  }

  private async put<T>(storeName: string, item: T): Promise<void> {
    const db = await this.openDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(storeName, 'readwrite');
      const store = tx.objectStore(storeName);
      const req = store.put(item);
      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    });
  }

  private async delete(storeName: string, id: string): Promise<void> {
    const db = await this.openDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(storeName, 'readwrite');
      const store = tx.objectStore(storeName);
      const req = store.delete(id);
      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    });
  }

  // --- Books ---
  async getBooks(): Promise<Book[]> {
    return this.getAll<Book>('books');
  }

  async saveBook(book: Book): Promise<void> {
    await this.put('books', book);
  }

  async deleteBook(bookId: string): Promise<void> {
    // Cascade delete all entities of that book
    const chapters = await this.getChaptersByBook(bookId);
    for (const c of chapters) {
      await this.deleteChapter(c.id);
    }
    const characters = await this.getCharactersByBook(bookId);
    for (const c of characters) {
      await this.delete('characters', c.id);
    }
    const details = await this.getDetailsByBook(bookId);
    for (const d of details) {
      await this.delete('details', d.id);
    }
    const ideas = await this.getIdeasByBook(bookId);
    for (const i of ideas) {
      await this.delete('ideas', i.id);
    }
    const events = await this.getTimelineEventsByBook(bookId);
    for (const e of events) {
      await this.delete('timelineEvents', e.id);
    }
    const connections = await this.getTimelineConnectionsByBook(bookId);
    for (const c of connections) {
      await this.delete('timelineConnections', c.id);
    }
    await this.delete('books', bookId);
  }

  // --- Chapters ---
  async getChaptersByBook(bookId: string): Promise<Chapter[]> {
    const list = await this.getByIndex<Chapter>('chapters', 'bookId', bookId);
    return list.sort((a, b) => a.order - b.order);
  }

  async saveChapter(chapter: Chapter): Promise<void> {
    await this.put('chapters', chapter);
  }

  async deleteChapter(chapterId: string): Promise<void> {
    // Delete chapter audios too
    const audios = await this.getAudiosByChapter(chapterId);
    for (const a of audios) {
      await this.deleteAudio(a.id);
    }
    await this.delete('chapters', chapterId);
  }

  // --- Characters ---
  async getCharactersByBook(bookId: string): Promise<Character[]> {
    return this.getByIndex<Character>('characters', 'bookId', bookId);
  }

  async saveCharacter(character: Character): Promise<void> {
    await this.put('characters', character);
  }

  async deleteCharacter(characterId: string): Promise<void> {
    await this.delete('characters', characterId);
  }

  // --- World Details ---
  async getDetailsByBook(bookId: string): Promise<WorldDetail[]> {
    return this.getByIndex<WorldDetail>('details', 'bookId', bookId);
  }

  async saveDetail(detail: WorldDetail): Promise<void> {
    await this.put('details', detail);
  }

  async deleteDetail(detailId: string): Promise<void> {
    await this.delete('details', detailId);
  }

  // --- Detail Categories ---
  async getDetailCategoriesByBook(bookId: string): Promise<DetailCategory[]> {
    let list = await this.getByIndex<DetailCategory>('detailCategories', 'bookId', bookId);
    if (list.length === 0) {
      const defaults: DetailCategory[] = [
        { id: `dcat_lug_${bookId}`, bookId, name: 'Lugares', color: '#2D5A43', icon: 'MapPin', isDefault: true },
        { id: `dcat_obj_${bookId}`, bookId, name: 'Objetos', color: '#1B3B5C', icon: 'Sparkles', isDefault: true },
        { id: `dcat_org_${bookId}`, bookId, name: 'Organizaciones', color: '#933D2D', icon: 'Shield', isDefault: true },
        { id: `dcat_fam_${bookId}`, bookId, name: 'Familias y linajes', color: '#583778', icon: 'Users', isDefault: true },
        { id: `dcat_his_${bookId}`, bookId, name: 'Historia', color: '#8C6D3B', icon: 'Clock', isDefault: true },
        { id: `dcat_reg_${bookId}`, bookId, name: 'Reglas del mundo', color: '#165B54', icon: 'Lock', isDefault: true },
        { id: `dcat_mag_${bookId}`, bookId, name: 'Magia o tecnología', color: '#4F6C8D', icon: 'Sparkles', isDefault: true },
        { id: `dcat_otr_${bookId}`, bookId, name: 'Otros', color: '#64748B', icon: 'Compass', isDefault: true },
      ];
      for (const d of defaults) {
        await this.put('detailCategories', d);
      }
      list = defaults;
    }
    return list;
  }

  async saveDetailCategory(cat: DetailCategory): Promise<void> {
    await this.put('detailCategories', cat);
  }

  async deleteDetailCategory(bookId: string, catId: string, reassignToCatId?: string): Promise<void> {
    const details = await this.getDetailsByBook(bookId);
    for (const d of details) {
      if (d.category === catId) {
        await this.saveDetail({
          ...d,
          category: reassignToCatId || 'sin_categoria',
          updatedAt: new Date().toISOString(),
        });
      }
    }
    await this.delete('detailCategories', catId);
  }

  async getDetailCategories(bookId: string): Promise<DetailCategory[]> {
    return this.getDetailCategoriesByBook(bookId);
  }

  async deleteDetailCategoryAndReassign(catId: string, reassignToCatId: string, bookId: string): Promise<void> {
    return this.deleteDetailCategory(bookId, catId, reassignToCatId);
  }

  async resetDetailCategoriesToDefault(bookId: string): Promise<DetailCategory[]> {
    const existing = await this.getByIndex<DetailCategory>('detailCategories', 'bookId', bookId);
    for (const c of existing) {
      await this.delete('detailCategories', c.id);
    }
    return this.getDetailCategoriesByBook(bookId);
  }

  // --- Ideas ---
  async getIdeasByBook(bookId: string): Promise<Idea[]> {
    const list = await this.getByIndex<Idea>('ideas', 'bookId', bookId);
    // Backward compatibility: ensure tray property exists
    return list.map((i) => {
      let tray = i.tray;
      if (!tray) {
        if (i.status === 'utilizada') tray = 'realizadas';
        else if (i.status === 'descartada') tray = 'descartadas';
        else tray = 'en_espera';
      }
      return { ...i, tray };
    });
  }

  async saveIdea(idea: Idea): Promise<void> {
    await this.put('ideas', idea);
  }

  async deleteIdea(ideaId: string): Promise<void> {
    await this.delete('ideas', ideaId);
  }

  // --- Idea Categories ---
  async getIdeaCategoriesByBook(bookId: string): Promise<IdeaCategory[]> {
    let list = await this.getByIndex<IdeaCategory>('ideaCategories', 'bookId', bookId);
    if (list.length === 0) {
      const defaults: IdeaCategory[] = [
        { id: `icat_tra_${bookId}`, bookId, name: 'Trama principal', color: '#2D5A43' },
        { id: `icat_sub_${bookId}`, bookId, name: 'Subtramas', color: '#1B3B5C' },
        { id: `icat_per_${bookId}`, bookId, name: 'Personajes', color: '#583778' },
        { id: `icat_esc_${bookId}`, bookId, name: 'Escenas', color: '#933D2D' },
        { id: `icat_dia_${bookId}`, bookId, name: 'Diálogos', color: '#8C6D3B' },
        { id: `icat_mis_${bookId}`, bookId, name: 'Misterios y revelaciones', color: '#D47754' },
        { id: `icat_mun_${bookId}`, bookId, name: 'Mundo y ambientación', color: '#165B54' },
        { id: `icat_ins_${bookId}`, bookId, name: 'Inspiración', color: '#4F6C8D' },
        { id: `icat_otr_${bookId}`, bookId, name: 'Otros', color: '#64748B' },
      ];
      for (const d of defaults) {
        await this.put('ideaCategories', d);
      }
      list = defaults;
    }
    return list;
  }

  async saveIdeaCategory(cat: IdeaCategory): Promise<void> {
    await this.put('ideaCategories', cat);
  }

  async deleteIdeaCategory(bookId: string, catId: string, reassignToCatId?: string): Promise<void> {
    const ideas = await this.getIdeasByBook(bookId);
    for (const i of ideas) {
      if (i.category === catId) {
        await this.saveIdea({
          ...i,
          category: reassignToCatId || 'sin_categoria',
          updatedAt: new Date().toISOString(),
        });
      }
    }
    await this.delete('ideaCategories', catId);
  }

  // --- Timeline Categories ---
  async getTimelineCategoriesByBook(bookId: string): Promise<TimelineCategory[]> {
    let list = await this.getByIndex<TimelineCategory>('timelineCategories', 'bookId', bookId);
    if (list.length === 0) {
      const defaults: TimelineCategory[] = [
        { id: `tcat_tra_${bookId}`, bookId, name: 'Trama principal', color: '#2D5A43' },
        { id: `tcat_sub_${bookId}`, bookId, name: 'Subtrama', color: '#4F6C8D' },
        { id: `tcat_per_${bookId}`, bookId, name: 'Personajes', color: '#583778' },
        { id: `tcat_his_${bookId}`, bookId, name: 'Historia del mundo', color: '#1B3B5C' },
        { id: `tcat_rev_${bookId}`, bookId, name: 'Revelaciones', color: '#D47754' },
        { id: `tcat_con_${bookId}`, bookId, name: 'Conflictos', color: '#933D2D' },
        { id: `tcat_rel_${bookId}`, bookId, name: 'Relaciones', color: '#8C6D3B' },
        { id: `tcat_otr_${bookId}`, bookId, name: 'Otros', color: '#64748B' },
      ];
      for (const d of defaults) {
        await this.put('timelineCategories', d);
      }
      list = defaults;
    }
    return list;
  }

  async saveTimelineCategory(cat: TimelineCategory): Promise<void> {
    await this.put('timelineCategories', cat);
  }

  async deleteTimelineCategory(bookId: string, catId: string, reassignToCatId?: string): Promise<void> {
    const events = await this.getTimelineEventsByBook(bookId);
    for (const e of events) {
      if (e.category === catId) {
        await this.saveTimelineEvent({
          ...e,
          category: reassignToCatId || 'sin_categoria',
          updatedAt: new Date().toISOString(),
        });
      }
    }
    await this.delete('timelineCategories', catId);
  }

  async getTimelineCategories(bookId: string): Promise<TimelineCategory[]> {
    return this.getTimelineCategoriesByBook(bookId);
  }

  async deleteTimelineCategoryAndReassign(catId: string, reassignToCatId: string, bookId: string): Promise<void> {
    return this.deleteTimelineCategory(bookId, catId, reassignToCatId);
  }

  async resetTimelineCategoriesToDefault(bookId: string): Promise<TimelineCategory[]> {
    const existing = await this.getByIndex<TimelineCategory>('timelineCategories', 'bookId', bookId);
    for (const c of existing) {
      await this.delete('timelineCategories', c.id);
    }
    return this.getTimelineCategoriesByBook(bookId);
  }

  async getIdeaCategories(bookId: string): Promise<IdeaCategory[]> {
    return this.getIdeaCategoriesByBook(bookId);
  }

  async deleteIdeaCategoryAndReassign(catId: string, reassignToCatId: string, bookId: string): Promise<void> {
    return this.deleteIdeaCategory(bookId, catId, reassignToCatId);
  }

  async resetIdeaCategoriesToDefault(bookId: string): Promise<IdeaCategory[]> {
    const existing = await this.getByIndex<IdeaCategory>('ideaCategories', 'bookId', bookId);
    for (const c of existing) {
      await this.delete('ideaCategories', c.id);
    }
    return this.getIdeaCategoriesByBook(bookId);
  }

  // --- Timeline Events ---
  async getTimelineEventsByBook(bookId: string): Promise<TimelineEvent[]> {
    return this.getByIndex<TimelineEvent>('timelineEvents', 'bookId', bookId);
  }

  async saveTimelineEvent(event: TimelineEvent): Promise<void> {
    await this.put('timelineEvents', event);
  }

  async deleteTimelineEvent(eventId: string): Promise<void> {
    // Also delete connections touching this event
    const allConns = await this.getAll<TimelineConnection>('timelineConnections');
    for (const c of allConns) {
      if (c.sourceEventId === eventId || c.targetEventId === eventId) {
        await this.delete('timelineConnections', c.id);
      }
    }
    // Also re-parent or delete sub-events
    const allEvents = await this.getAll<TimelineEvent>('timelineEvents');
    for (const e of allEvents) {
      if (e.parentEventId === eventId) {
        // detach sub-event
        await this.put('timelineEvents', { ...e, parentEventId: null });
      }
    }
    await this.delete('timelineEvents', eventId);
  }

  // --- Timeline Connections ---
  async getTimelineConnectionsByBook(bookId: string): Promise<TimelineConnection[]> {
    return this.getByIndex<TimelineConnection>('timelineConnections', 'bookId', bookId);
  }

  async saveTimelineConnection(connection: TimelineConnection): Promise<void> {
    await this.put('timelineConnections', connection);
  }

  async deleteTimelineConnection(connectionId: string): Promise<void> {
    await this.delete('timelineConnections', connectionId);
  }

  // --- Timeline Lanes (Carriles / Modo B) ---
  async getTimelineLanesByBook(bookId: string): Promise<TimelineLane[]> {
    let list = await this.getByIndex<TimelineLane>('timelineLanes', 'bookId', bookId);
    if (list.length === 0) {
      const defaults: TimelineLane[] = [
        {
          id: `lane_trama_${bookId}`,
          bookId,
          name: 'Trama Principal',
          description: 'Hitos clave y giros de la trama principal',
          color: '#2D5A43',
          category: 'trama_principal',
          order: 0,
          isVisible: true,
          createdAt: new Date().toISOString(),
        },
        {
          id: `lane_personajes_${bookId}`,
          bookId,
          name: 'Vida de Personajes',
          description: 'Líneas biográficas, nacimientos, arcos evolutivos',
          color: '#1B3B5C',
          category: 'personajes',
          order: 1,
          isVisible: true,
          createdAt: new Date().toISOString(),
        },
        {
          id: `lane_historia_${bookId}`,
          bookId,
          name: 'Historia y Política',
          description: 'Acontecimientos del reino, guerras y tratados',
          color: '#8C6D3B',
          category: 'historia',
          order: 2,
          isVisible: true,
          createdAt: new Date().toISOString(),
        },
        {
          id: `lane_revelaciones_${bookId}`,
          bookId,
          name: 'Revelaciones y Misterios',
          description: 'Pistas descubiertas, secretos desvelados',
          color: '#583778',
          category: 'revelaciones',
          order: 3,
          isVisible: true,
          createdAt: new Date().toISOString(),
        },
      ];
      for (const lane of defaults) {
        await this.put('timelineLanes', lane);
      }
      list = defaults;
    }
    return list.sort((a, b) => a.order - b.order);
  }

  async saveTimelineLane(lane: TimelineLane): Promise<void> {
    await this.put('timelineLanes', lane);
  }

  async deleteTimelineLane(laneId: string): Promise<void> {
    await this.delete('timelineLanes', laneId);
  }

  async reorderTimelineLanes(lanes: TimelineLane[]): Promise<void> {
    for (const lane of lanes) {
      await this.put('timelineLanes', lane);
    }
  }

  // --- Character Categories (Arquetipos y Roles Expandidos) ---
  async getCharacterCategoriesByBook(bookId: string): Promise<CharacterCategory[]> {
    let list = await this.getByIndex<CharacterCategory>('characterCategories', 'bookId', bookId);
    if (list.length === 0) {
      const defaults: Omit<CharacterCategory, 'id'>[] = [
        { bookId, name: 'Protagonista', color: '#1E3B5C', order: 0, isDefault: true },
        { bookId, name: 'Antagonista', color: '#933D2D', order: 1, isDefault: true },
        { bookId, name: 'Deuteragonista', color: '#2D5A43', order: 2, isDefault: true },
        { bookId, name: 'Tritagonista', color: '#583778', order: 3, isDefault: true },
        { bookId, name: 'Secundario', color: '#32526F', order: 4, isDefault: true },
        { bookId, name: 'Mentor / Sabio', color: '#8C6D3B', order: 5, isDefault: true },
        { bookId, name: 'Aliado / Cómplice', color: '#2A5682', order: 6, isDefault: true },
        { bookId, name: 'Interés Romántico', color: '#A64452', order: 7, isDefault: true },
        { bookId, name: 'Guardián del Umbral', color: '#785434', order: 8, isDefault: true },
        { bookId, name: 'Héroe Trágico', color: '#822A2A', order: 9, isDefault: true },
        { bookId, name: 'Falso Aliado / Traidor', color: '#7A324E', order: 10, isDefault: true },
        { bookId, name: 'Coro / Voces', color: '#4A5568', order: 11, isDefault: true },
        { bookId, name: 'Narrador', color: '#3B6E64', order: 12, isDefault: true },
        { bookId, name: 'Personaje Histórico', color: '#6B4F35', order: 13, isDefault: true },
        { bookId, name: 'Símbolo / Alegoría', color: '#70487E', order: 14, isDefault: true },
        { bookId, name: 'Animal / Criatura', color: '#4F6D44', order: 15, isDefault: true },
        { bookId, name: 'Entidad Sobrenatural', color: '#2E6B6B', order: 16, isDefault: true },
        { bookId, name: 'Terciario / Extra', color: '#64748B', order: 17, isDefault: true },
        { bookId, name: 'Otro', color: '#475569', order: 18, isDefault: true },
      ];
      const created: CharacterCategory[] = [];
      for (let i = 0; i < defaults.length; i++) {
        const item: CharacterCategory = {
          ...defaults[i],
          id: `ccat_${i}_${bookId}`,
        };
        await this.put('characterCategories', item);
        created.push(item);
      }
      list = created;
    }
    return list.sort((a, b) => a.order - b.order);
  }

  async saveCharacterCategory(category: CharacterCategory): Promise<void> {
    await this.put('characterCategories', category);
  }

  async deleteCharacterCategory(bookId: string, catId: string, reassignToCatId?: string): Promise<void> {
    const chars = await this.getCharactersByBook(bookId);
    for (const c of chars) {
      if (c.role === catId || (c.categoryIds && c.categoryIds.includes(catId))) {
        const updatedCatIds = (c.categoryIds || []).filter((id) => id !== catId);
        if (reassignToCatId && !updatedCatIds.includes(reassignToCatId)) {
          updatedCatIds.push(reassignToCatId);
        }
        await this.saveCharacter({
          ...c,
          role: c.role === catId ? (reassignToCatId || 'secundario') : c.role,
          categoryIds: updatedCatIds,
          updatedAt: new Date().toISOString(),
        });
      }
    }
    await this.delete('characterCategories', catId);
  }

  async resetCharacterCategoriesToDefault(bookId: string): Promise<CharacterCategory[]> {
    const existing = await this.getByIndex<CharacterCategory>('characterCategories', 'bookId', bookId);
    for (const c of existing) {
      await this.delete('characterCategories', c.id);
    }
    return this.getCharacterCategoriesByBook(bookId);
  }

  // --- Custom Palettes (3-Color Custom Themes) ---
  async getCustomPalettes(): Promise<CustomPaletteConfig[]> {
    return this.getAll<CustomPaletteConfig>('customPalettes');
  }

  async saveCustomPalette(palette: CustomPaletteConfig): Promise<void> {
    await this.put('customPalettes', palette);
  }

  async deleteCustomPalette(paletteId: string): Promise<void> {
    await this.delete('customPalettes', paletteId);
  }

  // --- Custom Fonts (Local TTF/OTF Files in IndexedDB) ---
  async getCustomFonts(): Promise<CustomFontItem[]> {
    return this.getAll<CustomFontItem>('customFonts');
  }

  async saveCustomFont(font: CustomFontItem): Promise<void> {
    await this.put('customFonts', font);
  }

  async deleteCustomFont(fontId: string): Promise<void> {
    await this.delete('customFonts', fontId);
  }

  // --- Detail Category Reordering ---
  async saveDetailCategoryOrder(categories: DetailCategory[]): Promise<void> {
    for (let i = 0; i < categories.length; i++) {
      const cat = { ...categories[i], order: i };
      await this.put('detailCategories', cat);
    }
  }

  // --- Audios (Blob Storage) ---
  async saveAudio(audioRecord: AudioRecord, fileBlob: Blob): Promise<void> {
    const stored: StoredAudio = {
      ...audioRecord,
      blob: fileBlob,
    };
    await this.put('audios', stored);
  }

  async getAudiosByChapter(chapterId: string): Promise<AudioRecord[]> {
    const list = await this.getByIndex<StoredAudio>('audios', 'chapterId', chapterId);
    return list.map((item) => {
      let blobUrl: string | undefined;
      if (item.blob) {
        try {
          blobUrl = URL.createObjectURL(item.blob);
        } catch (e) {
          console.warn('Could not create ObjectURL', e);
        }
      }
      return {
        id: item.id,
        bookId: item.bookId,
        chapterId: item.chapterId,
        name: item.name,
        fileName: item.fileName,
        mimeType: item.mimeType,
        size: item.size,
        duration: item.duration,
        createdAt: item.createdAt,
        notes: item.notes,
        transcription: item.transcription,
        blobDataUrl: blobUrl,
      };
    });
  }

  async getAudioBlob(audioId: string): Promise<Blob | null> {
    const item = await this.getById<StoredAudio>('audios', audioId);
    return item?.blob || null;
  }

  async updateAudioMetadata(
    audioId: string,
    updates: Partial<Pick<AudioRecord, 'name' | 'notes' | 'transcription'>>
  ): Promise<void> {
    const item = await this.getById<StoredAudio>('audios', audioId);
    if (!item) return;
    const updated = { ...item, ...updates };
    await this.put('audios', updated);
  }

  async deleteAudio(audioId: string): Promise<void> {
    await this.delete('audios', audioId);
  }

  // --- Settings ---
  async getSettings(): Promise<AppSettings> {
    const record = await this.getById<{ key: string; value: AppSettings }>('settings', 'app_config');
    if (record?.value) return record.value;
    return {
      globalPalette: 'bosque',
      darkMode: false,
      editorFontSize: 18,
      editorFontFamily: 'lora',
      autoSaveDelay: 1000,
    };
  }

  async saveSettings(settings: AppSettings): Promise<void> {
    await this.put('settings', { key: 'app_config', value: settings });
  }

  // --- Storage Quota info ---
  async getStorageEstimate(): Promise<{ usage: number; quota: number }> {
    if (navigator.storage && navigator.storage.estimate) {
      const est = await navigator.storage.estimate();
      return { usage: est.usage || 0, quota: est.quota || 0 };
    }
    return { usage: 0, quota: 0 };
  }

  // --- Export and Import Project ---
  async exportBookToJson(bookId: string): Promise<string> {
    const book = await this.getById<Book>('books', bookId);
    if (!book) throw new Error('Libro no encontrado');

    const chapters = await this.getChaptersByBook(bookId);
    const characters = await this.getCharactersByBook(bookId);
    const details = await this.getDetailsByBook(bookId);
    const ideas = await this.getIdeasByBook(bookId);
    const timelineEvents = await this.getTimelineEventsByBook(bookId);
    const timelineConnections = await this.getTimelineConnectionsByBook(bookId);

    const data = {
      version: 1,
      exportedAt: new Date().toISOString(),
      book,
      chapters,
      characters,
      details,
      ideas,
      timelineEvents,
      timelineConnections,
    };

    return JSON.stringify(data, null, 2);
  }

  async importBookFromJson(jsonString: string): Promise<string> {
    const parsed = JSON.parse(jsonString);
    if (!parsed.book || !parsed.book.title) {
      throw new Error('El archivo JSON no tiene un formato válido de proyecto de Pluma & Tiempo.');
    }

    const newBookId = 'book_' + Date.now() + '_' + Math.random().toString(36).substring(2, 7);
    const oldBookId = parsed.book.id;

    const importedBook: Book = {
      ...parsed.book,
      id: newBookId,
      title: `${parsed.book.title} (Importado)`,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    await this.saveBook(importedBook);

    // Map old IDs to new IDs
    const idMap: Record<string, string> = { [oldBookId]: newBookId };

    // Chapters
    for (const c of parsed.chapters || []) {
      const newChapId = 'chap_' + Date.now() + '_' + Math.random().toString(36).substring(2, 7);
      idMap[c.id] = newChapId;
      await this.saveChapter({
        ...c,
        id: newChapId,
        bookId: newBookId,
        audioIds: [], // audio binary blobs not included in JSON text
      });
    }

    // Characters
    for (const ch of parsed.characters || []) {
      const newCharId = 'char_' + Date.now() + '_' + Math.random().toString(36).substring(2, 7);
      idMap[ch.id] = newCharId;
      await this.saveCharacter({
        ...ch,
        id: newCharId,
        bookId: newBookId,
      });
    }

    // Details
    for (const d of parsed.details || []) {
      const newDetId = 'det_' + Date.now() + '_' + Math.random().toString(36).substring(2, 7);
      idMap[d.id] = newDetId;
      await this.saveDetail({
        ...d,
        id: newDetId,
        bookId: newBookId,
      });
    }

    // Ideas
    for (const i of parsed.ideas || []) {
      const newIdeaId = 'idea_' + Date.now() + '_' + Math.random().toString(36).substring(2, 7);
      idMap[i.id] = newIdeaId;
      await this.saveIdea({
        ...i,
        id: newIdeaId,
        bookId: newBookId,
      });
    }

    // Timeline Events
    for (const e of parsed.timelineEvents || []) {
      const newEvId = 'ev_' + Date.now() + '_' + Math.random().toString(36).substring(2, 7);
      idMap[e.id] = newEvId;
      await this.saveTimelineEvent({
        ...e,
        id: newEvId,
        bookId: newBookId,
      });
    }

    // Timeline Connections
    for (const conn of parsed.timelineConnections || []) {
      const newConnId = 'conn_' + Date.now() + '_' + Math.random().toString(36).substring(2, 7);
      await this.saveTimelineConnection({
        ...conn,
        id: newConnId,
        bookId: newBookId,
        sourceEventId: idMap[conn.sourceEventId] || conn.sourceEventId,
        targetEventId: idMap[conn.targetEventId] || conn.targetEventId,
      });
    }

    return newBookId;
  }

  // --- Seed initial data if database is brand new ---
  async seedIfEmpty(): Promise<void> {
    const books = await this.getBooks();
    if (books.length > 0) return;

    // Create rich initial demonstration book
    const bookId = 'book_cronicas_valoria';
    const demoBook: Book = {
      id: bookId,
      title: 'Las Sombras de Valoria',
      subtitle: 'El despertar del linaje olvidado',
      description:
        'En una ciudad suspendida sobre un mar de niebla eterna, un relojero descubre un mecanismo que revela memorias de reyes caídos y profecías de una rebelión inminente.',
      genre: 'Fantasía Oscura y Misterio',
      status: 'escritura',
      createdAt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 30).toISOString(),
      updatedAt: new Date().toISOString(),
      colorPalette: 'bosque',
      targetWordCount: 80000,
      coverGradient: 'from-emerald-950 via-teal-900 to-stone-900',
      coverIcon: 'Compass',
      isArchived: false,
    };
    await this.saveBook(demoBook);

    // Characters
    const char1: Character = {
      id: 'char_aelys',
      bookId,
      name: 'Aélys Vane',
      aliases: 'El Relojero Ciego, La Sombra del Campanario',
      age: '29 años',
      birthDate: 'Año 1412, Noche de la Lente Roja',
      role: 'protagonista',
      appearance: 'Cabello cenizo desordenado, ojos ambarinos de mirada huidiza, manos curtidas por engranajes y ácidos de orfebrería.',
      personality: 'Metódico, escéptico ante la magia formal, leal en silencio y atormentado por pesadillas recurrentes.',
      backstory: 'Huérfano tras el Gran Incendio del Distrito de los Fuegos. Aprendiz del maestro Horologer hasta que este desapareció misteriosamente.',
      motivations: 'Descubrir qué causó la demencia de su mentor y descifrar la llave octogonal.',
      goals: 'Reparar el Astrolabio de la Catedral antes del eclipse solar de invierno.',
      fears: 'Perder el control de sus recuerdos y la ceguera progresiva.',
      strengths: 'Oído absoluto para metales, intuición deductiva y memoria eidética.',
      weaknesses: 'Dificultad extrema para confiar en aliados y renuencia al uso de armas.',
      secrets: 'Conserva en un doble fondo la carta sellada de la última emperatriz de Valoria.',
      evolution: 'Pasa del retraimiento artesanal a asumir el liderazgo táctico de la Resistencia.',
      firstAppearance: 'Capítulo 1: El tic-tac de la niebla',
      additionalNotes: 'Nunca duerme sin encender una vela aromática de salvia.',
      avatarColor: '#2D5A43',
      relationships: [
        {
          targetCharacterId: 'char_morrigan',
          relationType: 'Aliado',
          description: 'Pacto de conveniencia mutua; ella le suministra planos prohibidos.',
        },
        {
          targetCharacterId: 'char_valerius',
          relationType: 'Enemigo',
          description: 'Inquisidor del Tribunal que persigue a los relojeros independientes.',
        },
      ],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    const char2: Character = {
      id: 'char_morrigan',
      bookId,
      name: 'Lady Morrigan Drake',
      aliases: 'La Grulla de Ceniza',
      age: '34 años',
      birthDate: 'Año 1407, Solsticio de Invierno',
      role: 'secundario',
      appearance: 'Vestiduras de seda carbón, hombreras con filigrana de plata, porte altivo y una cicatriz fina en la mejilla izquierda.',
      personality: 'Estratega calculadora, ingeniosa, amante de la música sacra y ferozmente protectora de los suyos.',
      backstory: 'Hija desterrada de la Casa Drake por negarse a entregar la biblioteca familiar a la Inquisición.',
      motivations: 'Recuperar el honor de su linaje y derrocar el monopolio del éter.',
      goals: 'Comprar los votos de tres senadores antes del equinoccio.',
      fears: 'Que el veneno que corre en su sangre por el pacto ancestral despierte.',
      strengths: 'Finanzas, diplomacia despiadada y esgrima cortesana.',
      weaknesses: 'Orgullo aristocrático y rencor implacable.',
      secrets: 'Mantiene una red secreta de espías niños en los muelles de niebla.',
      evolution: 'Comprende que el sacrificio personal es inevitable para salvar la ciudad.',
      firstAppearance: 'Capítulo 2: El precio de un secreto',
      additionalNotes: 'Porta siempre un anillo con cianuro líquido.',
      avatarColor: '#583778',
      relationships: [
        {
          targetCharacterId: 'char_aelys',
          relationType: 'Aliado',
          description: 'Socia comercial y confidente cautelosa.',
        },
      ],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    const char3: Character = {
      id: 'char_valerius',
      bookId,
      name: 'Canciller Valerius Thorne',
      aliases: 'La Mano de Hierro',
      age: '56 años',
      birthDate: 'Año 1385, Primavera',
      role: 'antagonista',
      appearance: 'Hombre corpulento de mirada gélida, túnica cardenalicia escarlata y guantelete de latón.',
      personality: 'Fanático del orden absoluto, implacable, elocuente y convencido de que la libertad conduce al caos.',
      backstory: 'Veterano de la Guerra de los Canales, ascendió sofocando las revueltas obreras.',
      motivations: 'Consolidar el gobierno teocrático y purificar la tecnología herética.',
      goals: 'Incautar el Astrolabio y ejecutar a los conspiradores.',
      fears: 'Que el pueblo descubra que el núcleo de éter de la ciudad se está apagando.',
      strengths: 'Poder político ilimitado, oratoria persuasiva y guardia pretoriana.',
      weaknesses: 'Paranoia creciente y arrogancia institucional.',
      secrets: 'Él mismo ordenó el Gran Incendio hace quince años.',
      evolution: 'Se aísla progresivamente hasta quedar atrapado en su propia fortaleza.',
      firstAppearance: 'Capítulo 1: Mencionado en pregones',
      additionalNotes: 'Padece gota y consume polvo de loto para el dolor.',
      avatarColor: '#933D2D',
      relationships: [
        {
          targetCharacterId: 'char_aelys',
          relationType: 'Enemigo',
          description: 'Orden de captura y confiscación de su taller.',
        },
      ],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    await this.saveCharacter(char1);
    await this.saveCharacter(char2);
    await this.saveCharacter(char3);

    // Chapters
    const chap1: Chapter = {
      id: 'chap_1',
      bookId,
      order: 1,
      number: 1,
      title: 'El tic-tac de la niebla',
      synopsis: 'Aélys trabaja en su taller durante una noche de tormenta cuando un cliente anónimo le entrega un artefacto octogonal con inscripciones imperiales.',
      content: `La niebla nunca descansaba sobre los tejados de Valoria. Se deslizaba entre las cornisas como el aliento frío de un león dormido, acariciando las veletas de latón y apagando los faroles de gas antes de la medianoche.

Aélys Vane sostenía la pinza de precisión con la firmeza de quien ha aprendido a respirar solo entre pulsaciones de engranajes. Frente a él, sobre el tapete de fieltro verde botella, el corazón de un reloj de agua vibraba con una cadencia irregular. Tres latidos rápidos, un suspiro de vapor y una pausa ominosa.

—Falta un diente en la rueda de escape —murmuró para sí mismo. Su voz sonó rasposa en el silencio del taller.

En la calle de los Plateros, los pasos apresurados resonaron sobre los adoquines húmedos. Aélys no levantó la vista de la lupa de joyero sujeta a su ojo derecho. En aquel distrito, mirar a través del cristal a deshoras atraía preguntas que ningún artesano honrado deseaba responder.

Sin embargo, los nudillos sonaron contra el portón de roble reforzado. Tres golpes secos, una pausa calculada, dos golpes más. El código de la Cofradía de Horologers. Una señal que nadie había utilizado desde hacía quince inviernos, cuando el Gran Incendio consumió la biblioteca del archivo municipal.

Aélys bajó la pinza con lentitud. Su pulgar rozó la empuñadura del estilete oculto bajo el borde del banco de trabajo.

—El taller está cerrado hasta el toque del alba —dijo en voz alta, sin moverse.

—El alba no vendrá esta noche si no abres, Aélys —respondió una voz desde el otro lado, amortiguada por la niebla pero teñida de una autoridad inconfundible—. Traigo lo que tu maestro enterró en las criptas de San Jude.`,
      status: 'borrador',
      createdAt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 10).toISOString(),
      updatedAt: new Date().toISOString(),
      wordCount: 268,
      characterCount: 1690,
      privateNotes: 'Asegurar que la mención a los quince inviernos coincida con la fecha del Gran Incendio en la línea de tiempo.',
      relatedCharacterIds: ['char_aelys'],
      relatedTimelineEventIds: ['ev_mecanismo_octogonal'],
      audioIds: [],
    };

    const chap2: Chapter = {
      id: 'chap_2',
      bookId,
      order: 2,
      number: 2,
      title: 'El precio de un secreto',
      synopsis: 'Aélys se reúne con Lady Morrigan en los muelles bajos para descifrar el pergamino encíclico.',
      content: `Los muelles de niebla olían a brea rancia, salitre condensado y carbón vegetal quemado a media combustión. Las gabarras mecánicas atracaban entre gruñidos de cadenas oxidadas, descargando fardos de seda envueltos en lona encerada.

Lady Morrigan aguardaba bajo el alero del almacén diecisiete. Portaba una capa impermeable de tono humo, con la capucha levantada lo suficiente como para ocultar sus ojos pero dejar al descubierto la sonrisa afilada de sus labios pálidos.

—Llegas tarde, artesano —dijo ella, sin girar la cabeza—. En mi mundo, tres minutos de retraso son equivalentes a una sentencia de destierro.

—En mi mundo, apresurarse con un mecanismo de resorte de éter significa perder tres dedos y el techo del taller —replicó Aélys, quitándose el fango de las botas contra el bordillo.

Morrigan extrajo de su manguito de piel una lámina de cobre perforada. Los orificios formaban constelaciones que Aélys reconoció al instante: no eran mapas náuticos, sino la partitura armónica del Gran Astrolabio.

—Valerius ha convocado al consejo de censura para mañana al mediodía —advirtió la dama—. Si no ponemos la llave en funcionamiento antes de que caiga la campana mayor, el Canciller declarará herético cualquier instrumento de cuerda mecánica. Y tú serás el primero en subir al cadalso de la Plaza del Reloj.`,
      status: 'en_proceso',
      createdAt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 5).toISOString(),
      updatedAt: new Date().toISOString(),
      wordCount: 206,
      characterCount: 1350,
      privateNotes: 'Revisar si Morrigan ya conocía a Valerius antes de la Guerra de los Canales.',
      relatedCharacterIds: ['char_aelys', 'char_morrigan'],
      relatedTimelineEventIds: ['ev_pacto_muelles'],
      audioIds: [],
    };

    await this.saveChapter(chap1);
    await this.saveChapter(chap2);

    // World Details
    const det1: WorldDetail = {
      id: 'det_astrolabio',
      bookId,
      name: 'El Gran Astrolabio de Valoria',
      category: 'magia_tecnologia',
      description: 'Monumental mecanismo esférico de bronce y cristal de cuarzo situado en la cúpula de la Catedral del Eón. Regula las compuertas que impiden que el mar de niebla tóxica inunde los distritos habitados.',
      historicalPeriod: 'Construido en el Año 1280 por la dinastía solar',
      tags: ['tecnologia', 'relojería', 'éther', 'vital'],
      immutableInfo: 'CANON FIJO: Requiere tres llaves octogonales gemelas giradas al unísono para modificar su ciclo de 72 horas. Sin este ciclo, la niebla sube 10 metros por día.',
      provisionalInfo: 'Teoría: Se cree que el núcleo contiene un fragmento de una estrella caída que aún late.',
      relatedCharacterIds: ['char_aelys'],
      relatedChapterIds: ['chap_1', 'chap_2'],
      relatedIdeaIds: [],
      relatedTimelineEventIds: ['ev_creacion_astrolabio'],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    const det2: WorldDetail = {
      id: 'det_niebla_eterna',
      bookId,
      name: 'El Mar de Niebla (Calina del Abismo)',
      category: 'reglas_mundo',
      description: 'Manto gaseoso denso y pesado que cubre el mundo inferior. A nivel de suelo contiene esporas fosforescentes que inducen amnesia si se respiran sin filtro de salmuera.',
      historicalPeriod: 'Surgió tras la Fractura del Eón hace 400 años',
      tags: ['peligro', 'medioambiente', 'ley_fisica'],
      immutableInfo: 'CANON: Ningún ser humano sobrevive más de 20 minutos expuesto directamente a la niebla sin máscara con carbón activo y sal gema.',
      provisionalInfo: 'Los contrabandistas afirman que existen bestias aladas ciegas que habitan en sus profundidades.',
      relatedCharacterIds: [],
      relatedChapterIds: ['chap_1'],
      relatedIdeaIds: [],
      relatedTimelineEventIds: [],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    const det3: WorldDetail = {
      id: 'det_tribunal_censura',
      bookId,
      name: 'El Tribunal de la Balanza de Hierro',
      category: 'organizaciones',
      description: 'Brazo inquisitorial teocrático encabezado por el Canciller Valerius Thorne. Controla la distribución de éter y quema cualquier invención que no cuente con el sello pontificio.',
      historicalPeriod: 'Fundado tras el Gran Incendio del Año 1426',
      tags: ['gobierno', 'inquisicion', 'antagonistas'],
      immutableInfo: 'Cuentan con un ejército privado de 2.000 Guardias Escarlata y control de las reservas de alimentos.',
      provisionalInfo: 'Varios capitanes de la guardia dudan de la legitimidad de Thorne.',
      relatedCharacterIds: ['char_valerius'],
      relatedChapterIds: ['chap_2'],
      relatedIdeaIds: [],
      relatedTimelineEventIds: ['ev_gran_incendio'],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    await this.saveDetail(det1);
    await this.saveDetail(det2);
    await this.saveDetail(det3);

    // Ideas
    const idea1: Idea = {
      id: 'idea_1',
      bookId,
      title: 'El traidor dentro de la Cofradía de Relojeros',
      content: '¿Y si el anciano Horologer fingió su secuestro para obligar a Aélys a resolver el acertijo final que él nunca pudo descifrar por orgullo?',
      tags: ['giro_trama', 'personajes', 'misterio'],
      status: 'en_desarrollo',
      tray: 'en_espera',
      priority: 'alta',
      relatedCharacterIds: ['char_aelys'],
      relatedChapterIds: ['chap_1'],
      relatedDetailIds: ['det_astrolabio'],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    const idea2: Idea = {
      id: 'idea_2',
      bookId,
      title: 'Capítulo en el puente levadizo durante el eclipse',
      content: 'Escena de persecución en carruajes de vapor sobre el Gran Viaducto mientras la niebla empieza a lamer los pilares superiores.',
      tags: ['accion', 'climax', 'escenario'],
      status: 'nueva',
      tray: 'en_espera',
      priority: 'media',
      relatedCharacterIds: ['char_aelys', 'char_morrigan', 'char_valerius'],
      relatedChapterIds: [],
      relatedDetailIds: ['det_niebla_eterna'],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    await this.saveIdea(idea1);
    await this.saveIdea(idea2);

    // Timeline Events (Showing off absolute, relative, hierarchical and connected points)
    const ev1: TimelineEvent = {
      id: 'ev_creacion_astrolabio',
      bookId,
      title: 'Construcción del Gran Astrolabio',
      description: 'El gremio de arquitectos celestiales instala la maquinaria primordial sobre la aguja de la Catedral de Valoria.',
      dateType: 'exacta',
      dateDisplay: 'Año 1280 (Era Solar)',
      numericSortValue: 1280,
      category: 'trasfondo_historico',
      color: '#4A7C59',
      status: 'confirmado',
      characterIds: [],
      chapterIds: [],
      detailIds: ['det_astrolabio'],
      notes: 'Punto de partida del cómputo cronológico moderno de la ciudad.',
      parentEventId: null,
      x: 100,
      y: 200,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    const ev2: TimelineEvent = {
      id: 'ev_gran_incendio',
      bookId,
      title: 'El Gran Incendio de los Archivos',
      description: 'Fuego misterioso que destruye los registros imperiales y la biblioteca secreta de los relojeros.',
      dateType: 'exacta',
      dateDisplay: 'Año 1426 (Hace 15 años)',
      numericSortValue: 1426,
      category: 'batalla_conflicto',
      color: '#933D2D',
      status: 'confirmado',
      characterIds: ['char_valerius'],
      chapterIds: ['chap_1'],
      detailIds: ['det_tribunal_censura'],
      notes: 'Valerius utilizó la catástrofe para proclamar la Ley Marcial.',
      parentEventId: null,
      x: 450,
      y: 200,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    // Sub-events of Gran Incendio
    const ev2_1: TimelineEvent = {
      id: 'ev_incendio_sub1',
      bookId,
      title: 'A.1: Explosión del ala norte',
      description: 'Estallido en la cámara de alquimia subterránea que incomunica a los guardias.',
      dateType: 'exacta',
      dateDisplay: 'Año 1426, 21:00 hs',
      numericSortValue: 1426.1,
      category: 'batalla_conflicto',
      color: '#D47754',
      status: 'confirmado',
      characterIds: [],
      chapterIds: [],
      detailIds: [],
      notes: 'Primer indicio de sabotaje deliberado.',
      parentEventId: 'ev_gran_incendio',
      orderInParent: 1,
      x: 420,
      y: 350,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    const ev2_2: TimelineEvent = {
      id: 'ev_incendio_sub2',
      bookId,
      title: 'A.2: Desaparición de las crónicas dinásticas',
      description: 'Tres encapuchados escapan en una barcaza fluvial con los pergaminos de sangre.',
      dateType: 'exacta',
      dateDisplay: 'Año 1426, Medianoche',
      numericSortValue: 1426.2,
      category: 'revelacion',
      color: '#D47754',
      status: 'confirmado',
      characterIds: [],
      chapterIds: [],
      detailIds: [],
      notes: 'Testigo: el padre de Aélys antes de fallecer.',
      parentEventId: 'ev_gran_incendio',
      orderInParent: 2,
      x: 580,
      y: 350,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    // Relative event: 15 years after Gran Incendio!
    const ev3: TimelineEvent = {
      id: 'ev_mecanismo_octogonal',
      bookId,
      title: 'Entrega del Artefacto Octogonal',
      description: 'Un emisario anónimo entrega a Aélys la llave perdida que reactiva el núcleo del Astrolabio.',
      dateType: 'relativa',
      dateDisplay: '15 años después del Gran Incendio (Año 1441)',
      numericSortValue: 1441,
      relativeToEventId: 'ev_gran_incendio',
      relativeOffsetYears: 15,
      relativeConditionText: 'Exactamente 15 años después de las cenizas del archivo',
      category: 'trama_principal',
      color: '#2D5A43',
      status: 'confirmado',
      characterIds: ['char_aelys'],
      chapterIds: ['chap_1'],
      detailIds: ['det_astrolabio'],
      notes: 'Inicio formal de la novela en tiempo presente.',
      parentEventId: null,
      x: 850,
      y: 200,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    // Subsequent connected event: Pacto de los Muelles
    const ev4: TimelineEvent = {
      id: 'ev_pacto_muelles',
      bookId,
      title: 'El Pacto de los Muelles de Niebla',
      description: 'Aélys y Morrigan sellan una alianza secreta para desencriptar el códice antes del eclipse.',
      dateType: 'relativa',
      dateDisplay: '3 días después del Artefacto Octogonal',
      numericSortValue: 1441.02,
      relativeToEventId: 'ev_mecanismo_octogonal',
      relativeOffsetYears: 0,
      relativeConditionText: 'Tres jornadas tras la llegada del emisario',
      category: 'arco_personaje',
      color: '#583778',
      status: 'confirmado',
      characterIds: ['char_aelys', 'char_morrigan'],
      chapterIds: ['chap_2'],
      detailIds: [],
      notes: 'Ambos se arriesgan a la pena de decapitación pública.',
      parentEventId: null,
      x: 1200,
      y: 200,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    // Future event: El Eclipse de Invierno
    const ev5: TimelineEvent = {
      id: 'ev_eclipse_invierno',
      bookId,
      title: 'El Eclipse de Invierno (Clímax Pronosticado)',
      description: 'Momento en que el Astrolabio se alineará con los tres soles menores y decidirá la salvación o sepultura de Valoria.',
      dateType: 'aproximada',
      dateDisplay: 'Solsticio de Invierno, Año 1441',
      numericSortValue: 1441.9,
      category: 'trama_principal',
      color: '#1B3B5C',
      status: 'provisional',
      characterIds: ['char_aelys', 'char_morrigan', 'char_valerius'],
      chapterIds: [],
      detailIds: ['det_astrolabio', 'det_niebla_eterna'],
      notes: 'Límite temporal estricto para la resistencia.',
      parentEventId: null,
      x: 1550,
      y: 200,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    await this.saveTimelineEvent(ev1);
    await this.saveTimelineEvent(ev2);
    await this.saveTimelineEvent(ev2_1);
    await this.saveTimelineEvent(ev2_2);
    await this.saveTimelineEvent(ev3);
    await this.saveTimelineEvent(ev4);
    await this.saveTimelineEvent(ev5);

    // Connections between timeline points
    const conn1: TimelineConnection = {
      id: 'conn_1',
      bookId,
      title: 'Legado tecnológico de origen',
      description: 'El diseño del astrolabio guardó las directrices que provocaron la codicia del tribunal siglos después.',
      sourceEventId: 'ev_creacion_astrolabio',
      targetEventId: 'ev_gran_incendio',
      relationType: 'historica',
      direction: 'source_to_target',
      color: '#6E9BB8',
      style: 'solid',
      labelVisible: true,
      createdAt: new Date().toISOString(),
    };

    const conn2: TimelineConnection = {
      id: 'conn_2',
      bookId,
      title: 'Consecuencia directa: 15 años de silencio',
      description: 'El incendio provocó la ocultación del artefacto hasta que la muerte del maestro forzó su reaparición.',
      sourceEventId: 'ev_gran_incendio',
      targetEventId: 'ev_mecanismo_octogonal',
      relationType: 'causa_consecuencia',
      direction: 'source_to_target',
      color: '#933D2D',
      style: 'solid',
      labelVisible: true,
      createdAt: new Date().toISOString(),
    };

    const conn3: TimelineConnection = {
      id: 'conn_3',
      bookId,
      title: 'Pacto de urgencia táctica',
      description: 'La entrega del artefacto desata la persecución que empuja a Aélys hacia Morrigan.',
      sourceEventId: 'ev_mecanismo_octogonal',
      targetEventId: 'ev_pacto_muelles',
      relationType: 'continuacion',
      direction: 'source_to_target',
      color: '#2D5A43',
      style: 'solid',
      labelVisible: true,
      createdAt: new Date().toISOString(),
    };

    const conn4: TimelineConnection = {
      id: 'conn_4',
      bookId,
      title: 'Dependencia del destino de la ciudad',
      description: 'El éxito del pacto en los muelles determinará si la ciudad sobrevive al eclipse.',
      sourceEventId: 'ev_pacto_muelles',
      targetEventId: 'ev_eclipse_invierno',
      relationType: 'dependencia',
      direction: 'source_to_target',
      color: '#583778',
      style: 'dashed',
      labelVisible: true,
      createdAt: new Date().toISOString(),
    };

    await this.saveTimelineConnection(conn1);
    await this.saveTimelineConnection(conn2);
    await this.saveTimelineConnection(conn3);
    await this.saveTimelineConnection(conn4);
  }
}

export const dbService = new DatabaseService();
