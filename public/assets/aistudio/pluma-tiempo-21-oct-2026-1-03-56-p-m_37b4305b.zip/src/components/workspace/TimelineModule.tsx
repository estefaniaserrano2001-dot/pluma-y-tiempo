import React, { useState, useEffect, useRef, useMemo, useCallback } from 'react';
import {
  Plus,
  Search,
  Clock,
  Compass,
  ZoomIn,
  ZoomOut,
  Maximize2,
  Minimize2,
  Layers,
  Share2,
  ChevronRight,
  ChevronDown,
  Eye,
  EyeOff,
  AlertTriangle,
  Move,
  Link as LinkIcon,
  Unlink,
  Edit2,
  Trash2,
  X,
  Check,
  ArrowRight,
  Calendar,
  Sparkles,
  Users,
  BookOpen,
  Filter,
  Sliders,
  RotateCcw,
  Upload,
  Image as ImageIcon,
  PanelRightClose,
  PanelRightOpen,
  SlidersHorizontal,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { dbService } from '../../services/db';
import {
  TimelineEvent,
  TimelineConnection,
  TimelineEventDateType,
  ConnectionRelationType,
  ConnectionDirection,
  Character,
  Chapter,
  WorldDetail,
  TimelineCategory,
  MediaImage,
} from '../../types';
import { getTheme } from '../../utils/theme';
import {
  resolveEventDates,
  checkConnectionConsistency,
  TemporalConflict,
} from '../../utils/timelineEngine';

const RELATION_TYPES: { id: ConnectionRelationType; label: string }[] = [
  { id: 'causa_consecuencia', label: 'Causa y consecuencia' },
  { id: 'continuacion', label: 'Continuación' },
  { id: 'paralelismo', label: 'Paralelismo' },
  { id: 'contradiccion', label: 'Contradicción' },
  { id: 'revelacion', label: 'Revelación' },
  { id: 'familiar', label: 'Relación familiar' },
  { id: 'historica', label: 'Relación histórica' },
  { id: 'dependencia', label: 'Dependencia' },
  { id: 'coincidencia', label: 'Coincidencia' },
  { id: 'personalizada', label: 'Relación personalizada' },
];

export const TimelineModule: React.FC = () => {
  const {
    activeBook,
    currentPalette,
    darkMode,
    toast,
    setIsSaving,
    navigateToEntity,
  } = useApp();

  const theme = getTheme(currentPalette, darkMode);

  const [events, setEvents] = useState<TimelineEvent[]>([]);
  const [categories, setCategories] = useState<TimelineCategory[]>([]);
  const [connections, setConnections] = useState<TimelineConnection[]>([]);
  const [characters, setCharacters] = useState<Character[]>([]);
  const [chapters, setChapters] = useState<Chapter[]>([]);
  const [details, setDetails] = useState<WorldDetail[]>([]);

  // View mode: 'canvas' (2D interactive canvas) vs 'chronological' (linear track)
  const [timelineViewMode, setTimelineViewMode] = useState<'canvas' | 'chronological'>('canvas');

  // Display density level: 'puntos' | 'nombres' | 'detallada'
  const [displayLevel, setDisplayLevel] = useState<'puntos' | 'nombres' | 'detallada'>('nombres');

  // Full screen mode
  const [isFullscreen, setIsFullscreen] = useState(false);

  // Inspector panel collapse toggle
  const [isInspectorOpen, setIsInspectorOpen] = useState(true);

  // Floating filter mini-panel open toggle
  const [isFloatingFilterOpen, setIsFloatingFilterOpen] = useState(false);
  const [importanceFilter, setImportanceFilter] = useState<'todas' | 'alta' | 'media' | 'baja'>('todas');

  // Canvas Pan & Zoom coordinates
  const [zoom, setZoom] = useState<number>(1);
  const [pan, setPan] = useState<{ x: number; y: number }>({ x: 200, y: 150 });
  const [isPanning, setIsPanning] = useState(false);
  const startPanRef = useRef<{ x: number; y: number }>({ x: 0, y: 0 });
  const canvasRef = useRef<HTMLDivElement>(null);

  // Dragging event node
  const [draggingEventId, setDraggingEventId] = useState<string | null>(null);
  const dragStartOffset = useRef<{ x: number; y: number }>({ x: 0, y: 0 });

  // Selected item on canvas / panel
  const [selectedEventId, setSelectedEventId] = useState<string | null>(null);
  const [selectedConnectionId, setSelectedConnectionId] = useState<string | null>(null);

  // Hidden nodes (temporarily hidden from canvas)
  const [hiddenEventIds, setHiddenEventIds] = useState<string[]>([]);
  const [collapsedParentIds, setCollapsedParentIds] = useState<string[]>([]);

  // Search & Filter in Lateral Panel
  const [panelTab, setPanelTab] = useState<'acontecimientos' | 'subpuntos' | 'conexiones'>('acontecimientos');
  const [panelSearchQuery, setPanelSearchQuery] = useState('');
  const [filterCategory, setFilterCategory] = useState<string>('todas');
  const [filterCharacterId, setFilterCharacterId] = useState<string>('todos');

  // Modals for Create / Edit Event & Connection
  const [isEventModalOpen, setIsEventModalOpen] = useState(false);
  const [editingEvent, setEditingEvent] = useState<TimelineEvent | null>(null);
  const [parentForSubEvent, setParentForSubEvent] = useState<TimelineEvent | null>(null);
  const [deleteConfirmEvent, setDeleteConfirmEvent] = useState<TimelineEvent | null>(null);

  const [isConnModalOpen, setIsConnModalOpen] = useState(false);
  const [editingConnection, setEditingConnection] = useState<TimelineConnection | null>(null);
  const [deleteConfirmConn, setDeleteConfirmConn] = useState<TimelineConnection | null>(null);

  // Category Manager Modal State
  const [isCatManagerOpen, setIsCatManagerOpen] = useState(false);
  const [catNameInput, setCatNameInput] = useState('');
  const [catColorInput, setCatColorInput] = useState('#2D5A43');
  const [editingCat, setEditingCat] = useState<TimelineCategory | null>(null);
  const [deletingCat, setDeletingCat] = useState<TimelineCategory | null>(null);
  const [reassignTargetCatId, setReassignTargetCatId] = useState<string>('sin_categoria');

  // Event Form State
  const [eventTitle, setEventTitle] = useState('');
  const [eventDesc, setEventDesc] = useState('');
  const [eventDateType, setEventDateType] = useState<TimelineEventDateType>('exacta');
  const [eventDateDisplay, setEventDateDisplay] = useState('');
  const [eventNumericValue, setEventNumericValue] = useState<number>(1400);
  const [eventRelativeToId, setEventRelativeToId] = useState<string>('');
  const [eventRelativeOffset, setEventRelativeOffset] = useState<number>(15);
  const [eventRelativeCondition, setEventRelativeCondition] = useState<string>('');
  const [eventCategory, setEventCategory] = useState<string>('trama_principal');
  const [eventImportance, setEventImportance] = useState<TimelineEvent['importance']>('media');
  const [eventColor, setEventColor] = useState('#2D5A43');
  const [eventCharacterIds, setEventCharacterIds] = useState<string[]>([]);
  const [eventChapterIds, setEventChapterIds] = useState<string[]>([]);
  const [eventImages, setEventImages] = useState<MediaImage[]>([]);

  // Connection Form State
  const [connTitle, setConnTitle] = useState('');
  const [connDesc, setConnDesc] = useState('');
  const [connSourceId, setConnSourceId] = useState('');
  const [connTargetId, setConnTargetId] = useState('');
  const [connRelationType, setConnRelationType] = useState<ConnectionRelationType>('causa_consecuencia');
  const [connDirection, setConnDirection] = useState<ConnectionDirection>('unidireccional');
  const [connColor, setConnColor] = useState('#2D5A43');

  // Load all timeline data
  const loadData = useCallback(async () => {
    if (!activeBook) return;
    const cats = await dbService.getTimelineCategories(activeBook.id);
    setCategories(cats);
    const evs = await dbService.getTimelineEventsByBook(activeBook.id);
    setEvents(evs);
    const conns = await dbService.getTimelineConnectionsByBook(activeBook.id);
    setConnections(conns);
    const chars = await dbService.getCharactersByBook(activeBook.id);
    setCharacters(chars);
    const chaps = await dbService.getChaptersByBook(activeBook.id);
    setChapters(chaps);
    const dets = await dbService.getDetailsByBook(activeBook.id);
    setDetails(dets);
  }, [activeBook]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  // Resolve absolute positions and relative temporal anchors
  const { resolvedEvents, conflicts } = useMemo(() => {
    return resolveEventDates(events);
  }, [events]);

  const eventMap = useMemo(() => {
    const map = new Map<string, TimelineEvent>();
    resolvedEvents.forEach((ev) => map.set(ev.id, ev));
    return map;
  }, [resolvedEvents]);

  // Open Event Modal
  const openEventModal = (
    ev?: TimelineEvent,
    parent?: TimelineEvent,
    prefilledPosition?: number
  ) => {
    if (ev) {
      setEditingEvent(ev);
      setParentForSubEvent(null);
      setEventTitle(ev.title);
      setEventDesc(ev.description);
      setEventDateType(ev.dateType || 'exacta');
      setEventDateDisplay(ev.dateDisplay || '');
      setEventNumericValue(ev.numericValue ?? ev.numericSortValue ?? 1400);
      setEventRelativeToId(ev.relativeToEventId || '');
      setEventRelativeOffset(ev.relativeOffsetYears ?? ev.relativeOffsetDays ?? 15);
      setEventRelativeCondition(ev.relativeConditionText ?? ev.relativeCondition ?? '');
      setEventCategory(ev.category);
      setEventImportance(ev.importance || 'media');
      setEventColor(ev.color || '#2D5A43');
      setEventCharacterIds(ev.characterIds || []);
      setEventChapterIds(ev.chapterIds || []);
      setEventImages(ev.images || []);
    } else {
      setEditingEvent(null);
      setParentForSubEvent(parent || null);
      setEventTitle('');
      setEventDesc('');
      setEventDateType('exacta');
      const defNum = prefilledPosition !== undefined ? Math.round(prefilledPosition) : 1400;
      setEventNumericValue(defNum);
      setEventDateDisplay(prefilledPosition !== undefined ? `Año ${defNum}` : 'Año 1400');
      setEventRelativeToId('');
      setEventRelativeOffset(15);
      setEventRelativeCondition('');
      setEventCategory(categories[0]?.id || 'trama_principal');
      setEventImportance('media');
      setEventColor(categories[0]?.color || '#2D5A43');
      setEventCharacterIds([]);
      setEventChapterIds([]);
      setEventImages([]);
    }
    setIsEventModalOpen(true);
  };

  // Add images to event
  const handleAddEventImages = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    if (files.length === 0) return;

    files.forEach((file) => {
      const reader = new FileReader();
      reader.onload = (uploadEvent) => {
        const url = uploadEvent.target?.result as string;
        if (!url) return;
        setEventImages((prev) => [
          ...prev,
          {
            id: 'evimg_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
            url,
            caption: file.name.replace(/\.[^/.]+$/, ''),
            order: prev.length,
            createdAt: new Date().toISOString(),
          },
        ]);
      };
      reader.readAsDataURL(file);
    });
    e.target.value = '';
    toast(`${files.length} imagen(es) añadida(s) al hito`, 'info');
  };

  // Save Event
  const handleSaveEvent = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!eventTitle.trim() || !activeBook) return;

    setIsSaving(true);
    try {
      const eventId =
        editingEvent?.id ||
        'ev_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6);

      const mainImg = eventImages[0]?.url;

      const posX =
        editingEvent?.x ??
        editingEvent?.canvasPosition?.x ??
        Math.round(-pan.x + 350 + (Math.random() * 80 - 40));
      const posY =
        editingEvent?.y ??
        editingEvent?.canvasPosition?.y ??
        Math.round(-pan.y + 250 + (Math.random() * 80 - 40));

      const record: TimelineEvent = {
        id: eventId,
        bookId: activeBook.id,
        parentEventId: parentForSubEvent ? parentForSubEvent.id : editingEvent?.parentEventId,
        title: eventTitle.trim(),
        description: eventDesc.trim(),
        dateType: eventDateType,
        dateDisplay: eventDateDisplay.trim() || `Año ${eventNumericValue}`,
        numericSortValue: Number(eventNumericValue) || 0,
        numericValue: Number(eventNumericValue) || 0,
        relativeToEventId: eventDateType === 'relativa' ? eventRelativeToId : undefined,
        relativeOffsetYears: eventDateType === 'relativa' ? Number(eventRelativeOffset) : undefined,
        relativeOffsetDays: eventDateType === 'relativa' ? Number(eventRelativeOffset) : undefined,
        relativeConditionText: eventDateType === 'relativa' ? eventRelativeCondition.trim() : undefined,
        relativeCondition: eventDateType === 'relativa' ? eventRelativeCondition.trim() : undefined,
        category: eventCategory as any,
        color: eventColor,
        status: 'confirmado',
        importance: eventImportance,
        characterIds: eventCharacterIds,
        chapterIds: eventChapterIds,
        detailIds: editingEvent?.detailIds || [],
        notes: eventDesc.trim(),
        images: eventImages,
        imageUrl: mainImg,
        x: posX,
        y: posY,
        canvasPosition: { x: posX, y: posY },
        chronologicalPosition: Number(eventNumericValue) || 50,
        connectedEventIds: editingEvent?.connectedEventIds || [],
        createdAt: editingEvent?.createdAt || new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };

      await dbService.saveTimelineEvent(record);
      await loadData();
      setSelectedEventId(record.id);
      setIsEventModalOpen(false);
      toast(
        editingEvent ? 'Acontecimiento actualizado' : 'Acontecimiento creado con éxito',
        'success'
      );
    } finally {
      setIsSaving(false);
    }
  };

  // Direct Click on Linear Chronological Axis to Create Event
  const handleAxisClick = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const clickX = e.clientX - rect.left;
    const pct = Math.max(0, Math.min(1, clickX / rect.width));

    // Calculate approx year between min and max or default range 1300 - 1500
    const sorted = [...resolvedEvents].sort((a, b) => a.numericSortValue - b.numericSortValue);
    const minVal = sorted[0]?.numericSortValue ?? 1350;
    const maxVal = sorted[sorted.length - 1]?.numericSortValue ?? 1450;
    const span = Math.max(50, maxVal - minVal);
    const calculatedYear = Math.round(minVal + pct * span);

    openEventModal(undefined, undefined, calculatedYear);
  };

  // Category Manager Handlers
  const handleSaveCategory = async () => {
    if (!catNameInput.trim() || !activeBook) return;
    setIsSaving(true);
    try {
      const catId =
        editingCat?.id ||
        'tcat_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6);

      const catRecord: TimelineCategory = {
        id: catId,
        bookId: activeBook.id,
        name: catNameInput.trim(),
        color: catColorInput,
        order: editingCat?.order || categories.length,
      };

      await dbService.saveTimelineCategory(catRecord);
      const updated = await dbService.getTimelineCategories(activeBook.id);
      setCategories(updated);
      setEditingCat(null);
      setCatNameInput('');
      toast('Categoría de línea de tiempo guardada', 'success');
    } finally {
      setIsSaving(false);
    }
  };

  const handleDeleteCategory = async () => {
    if (!deletingCat || !activeBook) return;
    setIsSaving(true);
    try {
      await dbService.deleteTimelineCategoryAndReassign(
        deletingCat.id,
        reassignTargetCatId,
        activeBook.id
      );
      await loadData();
      setDeletingCat(null);
      toast('Categoría eliminada y acontecimientos reasignados', 'success');
    } finally {
      setIsSaving(false);
    }
  };

  const handleResetCategories = async () => {
    if (!activeBook) return;
    setIsSaving(true);
    try {
      const defaults = await dbService.resetTimelineCategoriesToDefault(activeBook.id);
      setCategories(defaults);
      await loadData();
      toast('Categorías de línea temporal restablecidas', 'info');
    } finally {
      setIsSaving(false);
    }
  };

  // Delete event confirmation
  const handleDeleteEvent = async () => {
    if (!deleteConfirmEvent) return;
    setIsSaving(true);
    try {
      await dbService.deleteTimelineEvent(deleteConfirmEvent.id);
      await loadData();
      if (selectedEventId === deleteConfirmEvent.id) {
        setSelectedEventId(null);
      }
      toast('Acontecimiento eliminado', 'info');
      setDeleteConfirmEvent(null);
    } finally {
      setIsSaving(false);
    }
  };

  // Open Connection Modal
  const openConnectionModal = (conn?: TimelineConnection, sourceId?: string) => {
    if (conn) {
      setEditingConnection(conn);
      setConnTitle(conn.title);
      setConnDesc(conn.description || '');
      setConnSourceId(conn.sourceEventId);
      setConnTargetId(conn.targetEventId);
      setConnRelationType(conn.relationType);
      setConnDirection(conn.direction);
      setConnColor(conn.color || '#2D5A43');
    } else {
      setEditingConnection(null);
      setConnTitle('');
      setConnDesc('');
      setConnSourceId(sourceId || events[0]?.id || '');
      setConnTargetId(events.find((e) => e.id !== sourceId)?.id || '');
      setConnRelationType('causa_consecuencia');
      setConnDirection('unidireccional');
      setConnColor('#2D5A43');
    }
    setIsConnModalOpen(true);
  };

  const handleSaveConnection = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!connSourceId || !connTargetId || connSourceId === connTargetId || !activeBook) {
      toast('Debes seleccionar dos acontecimientos distintos para conectar', 'error');
      return;
    }

    setIsSaving(true);
    try {
      const connId =
        editingConnection?.id ||
        'conn_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6);

      const record: TimelineConnection = {
        id: connId,
        bookId: activeBook.id,
        title: connTitle.trim() || 'Conexión narrativa',
        description: connDesc.trim(),
        sourceEventId: connSourceId,
        targetEventId: connTargetId,
        relationType: connRelationType,
        direction: connDirection,
        color: connColor,
        style: editingConnection?.style || 'solid',
        labelVisible: editingConnection?.labelVisible ?? true,
        createdAt: editingConnection?.createdAt || new Date().toISOString(),
      };

      await dbService.saveTimelineConnection(record);
      await loadData();
      setSelectedConnectionId(record.id);
      setIsConnModalOpen(false);
      toast('Conexión guardada con éxito', 'success');
    } finally {
      setIsSaving(false);
    }
  };

  const handleDeleteConnection = async () => {
    if (!deleteConfirmConn) return;
    setIsSaving(true);
    try {
      await dbService.deleteTimelineConnection(deleteConfirmConn.id);
      await loadData();
      if (selectedConnectionId === deleteConfirmConn.id) {
        setSelectedConnectionId(null);
      }
      toast('Conexión eliminada', 'info');
      setDeleteConfirmConn(null);
    } finally {
      setIsSaving(false);
    }
  };

  // Canvas Mouse Pan Handlers
  const handleMouseDown = (e: React.MouseEvent) => {
    if ((e.target as HTMLElement).closest('.timeline-node')) return;
    setIsPanning(true);
    startPanRef.current = { x: e.clientX - pan.x, y: e.clientY - pan.y };
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (isPanning) {
      setPan({
        x: e.clientX - startPanRef.current.x,
        y: e.clientY - startPanRef.current.y,
      });
    } else if (draggingEventId) {
      const ev = events.find((item) => item.id === draggingEventId);
      if (ev) {
        const newX = (e.clientX - pan.x - dragStartOffset.current.x) / zoom;
        const newY = (e.clientY - pan.y - dragStartOffset.current.y) / zoom;
        setEvents((prev) =>
          prev.map((item) =>
            item.id === draggingEventId
              ? { ...item, canvasPosition: { x: Math.round(newX), y: Math.round(newY) } }
              : item
          )
        );
      }
    }
  };

  const handleMouseUp = async () => {
    setIsPanning(false);
    if (draggingEventId) {
      const moved = events.find((item) => item.id === draggingEventId);
      if (moved) {
        await dbService.saveTimelineEvent(moved);
      }
      setDraggingEventId(null);
    }
  };

  const handleWheel = (e: React.WheelEvent) => {
    e.preventDefault();
    const zoomFactor = e.deltaY < 0 ? 1.08 : 0.92;
    setZoom((prev) => Math.min(2.5, Math.max(0.4, prev * zoomFactor)));
  };

  // Filtered Events based on search, category, character, importance
  const visibleEvents = useMemo(() => {
    return resolvedEvents.filter((ev) => {
      if (hiddenEventIds.includes(ev.id)) return false;
      if (ev.parentEventId && collapsedParentIds.includes(ev.parentEventId)) return false;
      if (filterCategory !== 'todas' && ev.category !== filterCategory) return false;
      if (filterCharacterId !== 'todos' && !(ev.characterIds || []).includes(filterCharacterId)) {
        return false;
      }
      if (importanceFilter !== 'todas' && ev.importance !== importanceFilter) return false;
      if (panelSearchQuery.trim()) {
        const q = panelSearchQuery.toLowerCase();
        return (
          ev.title.toLowerCase().includes(q) ||
          ev.description.toLowerCase().includes(q) ||
          ev.dateDisplay.toLowerCase().includes(q)
        );
      }
      return true;
    });
  }, [
    resolvedEvents,
    hiddenEventIds,
    collapsedParentIds,
    filterCategory,
    filterCharacterId,
    importanceFilter,
    panelSearchQuery,
  ]);

  const rootEvents = useMemo(() => {
    return visibleEvents.filter((e) => !e.parentEventId);
  }, [visibleEvents]);

  const activeEvent = selectedEventId ? eventMap.get(selectedEventId) : null;
  const activeConnection = selectedConnectionId
    ? connections.find((c) => c.id === selectedConnectionId)
    : null;

  return (
    <div
      className={`flex flex-col gap-3 min-h-[calc(100vh-10rem)] relative select-none ${
        isFullscreen ? 'fixed inset-0 z-50 p-4 bg-stone-900 overflow-hidden' : ''
      }`}
    >
      {/* Top Main Toolbar */}
      <div
        className={`p-3 md:p-4 rounded-2xl border shadow-xs flex flex-wrap items-center justify-between gap-3 ${theme.bgCard} ${theme.borderCard}`}
      >
        <div className="flex items-center gap-3">
          <div className={`p-2 rounded-xl ${theme.accentBadge} ${theme.accentText}`}>
            <Clock className="w-5 h-5" />
          </div>
          <div>
            <h3 className={`font-serif font-bold text-base ${theme.textPrimary}`}>
              Línea de Tiempo Interactiva
            </h3>
            <span className="text-[11px] text-stone-500 font-mono">
              {events.length} acontecimientos • {connections.length} conexiones • {conflicts.length} conflictos
            </span>
          </div>
        </div>

        {/* View mode switcher, Density level, Categories, Fullscreen */}
        <div className="flex flex-wrap items-center gap-2">
          {/* View Mode: 2D Canvas vs Linear Track */}
          <div
            className={`p-1 rounded-xl border flex items-center gap-1 text-xs font-medium ${theme.borderCard} ${theme.bgCard}`}
          >
            <button
              onClick={() => setTimelineViewMode('canvas')}
              className={`px-3 py-1.5 rounded-lg transition-all ${
                timelineViewMode === 'canvas'
                  ? `${theme.activeTab} font-semibold shadow-xs`
                  : 'text-stone-500 hover:text-stone-800 dark:hover:text-stone-200'
              }`}
            >
              Lienzo 2D
            </button>
            <button
              onClick={() => setTimelineViewMode('chronological')}
              className={`px-3 py-1.5 rounded-lg transition-all ${
                timelineViewMode === 'chronological'
                  ? `${theme.activeTab} font-semibold shadow-xs`
                  : 'text-stone-500 hover:text-stone-800 dark:hover:text-stone-200'
              }`}
            >
              Eje Lineal
            </button>
          </div>

          {/* Density Level: Puntos / Nombres / Detallada */}
          <div
            className={`p-1 rounded-xl border flex items-center gap-1 text-[11px] font-medium ${theme.borderCard} ${theme.bgCard}`}
          >
            <button
              onClick={() => setDisplayLevel('puntos')}
              className={`px-2 py-1 rounded-lg transition-all ${
                displayLevel === 'puntos'
                  ? `${theme.activeTab} font-semibold shadow-xs`
                  : 'text-stone-500 hover:text-stone-800 dark:hover:text-stone-200'
              }`}
              title="Solo puntos en el eje"
            >
              Puntos
            </button>
            <button
              onClick={() => setDisplayLevel('nombres')}
              className={`px-2 py-1 rounded-lg transition-all ${
                displayLevel === 'nombres'
                  ? `${theme.activeTab} font-semibold shadow-xs`
                  : 'text-stone-500 hover:text-stone-800 dark:hover:text-stone-200'
              }`}
              title="Puntos con nombres de acontecimientos"
            >
              Nombres
            </button>
            <button
              onClick={() => setDisplayLevel('detallada')}
              className={`px-2 py-1 rounded-lg transition-all ${
                displayLevel === 'detallada'
                  ? `${theme.activeTab} font-semibold shadow-xs`
                  : 'text-stone-500 hover:text-stone-800 dark:hover:text-stone-200'
              }`}
              title="Puntos con nombres, categorías e imágenes"
            >
              Detallada
            </button>
          </div>

          {/* Manage Categories Button */}
          <button
            onClick={() => setIsCatManagerOpen(true)}
            className="p-2 rounded-xl border border-stone-200 dark:border-stone-800 text-stone-600 dark:text-stone-300 hover:bg-black/5"
            title="Gestionar categorías de la línea temporal"
          >
            <Sliders className="w-4 h-4" />
          </button>

          {/* Floating mini-panel visibility toggle */}
          <button
            onClick={() => setIsFloatingFilterOpen(!isFloatingFilterOpen)}
            className={`p-2 rounded-xl border transition-all ${
              isFloatingFilterOpen
                ? `${theme.activeTab} shadow-xs`
                : 'border-stone-200 dark:border-stone-800 text-stone-600 dark:text-stone-300 hover:bg-black/5'
            }`}
            title="Minipanel de visibilidad selectiva"
          >
            <Filter className="w-4 h-4" />
          </button>

          {/* Inspector Panel Toggle Button */}
          <button
            onClick={() => setIsInspectorOpen(!isInspectorOpen)}
            className={`p-2 rounded-xl border transition-all ${
              isInspectorOpen
                ? 'border-stone-300 dark:border-stone-700 text-stone-700 dark:text-stone-200'
                : `${theme.activeTab} shadow-xs`
            }`}
            title={isInspectorOpen ? 'Ocultar panel lateral' : 'Mostrar panel lateral'}
          >
            {isInspectorOpen ? <PanelRightClose className="w-4 h-4" /> : <PanelRightOpen className="w-4 h-4" />}
          </button>

          {/* Fullscreen toggle button */}
          <button
            onClick={() => setIsFullscreen(!isFullscreen)}
            className="p-2 rounded-xl border border-stone-200 dark:border-stone-800 text-stone-600 dark:text-stone-300 hover:bg-black/5"
            title={isFullscreen ? 'Salir de pantalla completa' : 'Pantalla completa'}
          >
            {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
          </button>

          {/* New Event Button */}
          <button
            onClick={() => openEventModal()}
            className={`flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-semibold shadow-xs ${theme.primaryBtn}`}
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Crear Acontecimiento</span>
          </button>
        </div>
      </div>

      {/* Main Workspace: Canvas or Linear Track + Inspector */}
      <div className="flex-1 flex gap-3 h-[72vh] relative overflow-hidden rounded-3xl border border-stone-200 dark:border-stone-800 shadow-sm">
        {/* VIEW 1: INTERACTIVE 2D CANVAS */}
        {timelineViewMode === 'canvas' ? (
          <div
            ref={canvasRef}
            onMouseDown={handleMouseDown}
            onMouseMove={handleMouseMove}
            onMouseUp={handleMouseUp}
            onWheel={handleWheel}
            className="flex-1 h-full relative overflow-hidden cursor-crosshair select-none bg-stone-50 dark:bg-stone-950"
            style={{
              backgroundImage: `radial-gradient(${darkMode ? '#333' : '#ddd'} 1px, transparent 1px)`,
              backgroundSize: `${32 * zoom}px ${32 * zoom}px`,
            }}
          >
            {/* SVG Connections Layer (Smooth Bézier Curves) */}
            <svg
              className="absolute inset-0 pointer-events-none w-full h-full"
              style={{
                transform: `translate(${pan.x}px, ${pan.y}px) scale(${zoom})`,
                transformOrigin: '0 0',
              }}
            >
              <defs>
                <marker
                  id="arrow"
                  viewBox="0 0 10 10"
                  refX="10"
                  refY="5"
                  markerWidth="6"
                  markerHeight="6"
                  orient="auto-start-reverse"
                >
                  <path d="M 0 0 L 10 5 L 0 10 z" fill={theme.accentHex} />
                </marker>
              </defs>

              {connections.map((conn) => {
                const src = eventMap.get(conn.sourceEventId);
                const tgt = eventMap.get(conn.targetEventId);
                if (!src || !tgt) return null;

                const srcPos = src.canvasPosition || { x: src.x ?? 100, y: src.y ?? 100 };
                const tgtPos = tgt.canvasPosition || { x: tgt.x ?? 300, y: tgt.y ?? 100 };

                const startX = srcPos.x + 100;
                const startY = srcPos.y + 40;
                const endX = tgtPos.x + 100;
                const endY = tgtPos.y + 40;

                const dx = Math.abs(endX - startX) * 0.5;
                const bezierPath = `M ${startX} ${startY} C ${startX + dx} ${startY}, ${endX - dx} ${endY}, ${endX} ${endY}`;

                const isConnSelected = selectedConnectionId === conn.id;
                const isBidirectional = conn.direction === 'bidireccional' || conn.direction === 'bidirectional';

                return (
                  <g key={conn.id} className="pointer-events-auto cursor-pointer" onClick={() => setSelectedConnectionId(conn.id)}>
                    <path
                      d={bezierPath}
                      stroke={conn.color || theme.accentHex}
                      strokeWidth={isConnSelected ? 3.5 : 2}
                      strokeDasharray={conn.relationType === 'contradiccion' ? '4,4' : undefined}
                      fill="none"
                      markerEnd={!isBidirectional ? 'url(#arrow)' : undefined}
                      className="transition-all hover:stroke-width-4 opacity-75 hover:opacity-100"
                    />
                  </g>
                );
              })}
            </svg>

            {/* Nodes Layer */}
            <div
              className="absolute top-0 left-0 w-full h-full pointer-events-none"
              style={{
                transform: `translate(${pan.x}px, ${pan.y}px) scale(${zoom})`,
                transformOrigin: '0 0',
              }}
            >
              {visibleEvents.map((ev) => {
                const isSelected = selectedEventId === ev.id;
                const catObj = categories.find((c) => c.id === ev.category);
                const pos = ev.canvasPosition || { x: ev.x ?? 200, y: ev.y ?? 150 };

                return (
                  <div
                    key={ev.id}
                    onMouseDown={(e) => {
                      e.stopPropagation();
                      setDraggingEventId(ev.id);
                      dragStartOffset.current = {
                        x: e.clientX - pan.x - pos.x * zoom,
                        y: e.clientY - pan.y - pos.y * zoom,
                      };
                      setSelectedEventId(ev.id);
                    }}
                    style={{
                      transform: `translate(${pos.x}px, ${pos.y}px)`,
                      width: displayLevel === 'puntos' ? 'auto' : displayLevel === 'nombres' ? '180px' : '230px',
                    }}
                    className={`timeline-node pointer-events-auto absolute rounded-2xl border p-2.5 shadow-md transition-all cursor-grab active:cursor-grabbing backdrop-blur-xs select-none ${
                      theme.bgCard
                    } ${
                      isSelected
                        ? `${theme.activeBorder} ring-3 ${theme.activeRing} shadow-xl z-30 scale-105`
                        : `${theme.borderCard} hover:shadow-lg z-10`
                    }`}
                  >
                    {displayLevel === 'puntos' ? (
                      <div className="flex items-center gap-1.5 p-1">
                        <div
                          className="w-3.5 h-3.5 rounded-full shadow-xs shrink-0"
                          style={{ backgroundColor: ev.color || catObj?.color || theme.accentHex }}
                        />
                        <span className="text-[10px] font-mono font-bold">{ev.dateDisplay}</span>
                      </div>
                    ) : (
                      <>
                        <div className="flex items-center justify-between gap-1 mb-1">
                          <div className="flex items-center gap-1.5 min-w-0">
                            <div
                              className="w-2.5 h-2.5 rounded-full shrink-0"
                              style={{ backgroundColor: ev.color || catObj?.color || theme.accentHex }}
                            />
                            <span className="text-[10px] font-mono font-bold text-stone-500 truncate">
                              {ev.dateDisplay}
                            </span>
                          </div>
                          {ev.images && ev.images.length > 0 && (
                            <ImageIcon className="w-3 h-3 text-blue-500 shrink-0" />
                          )}
                        </div>

                        <h4 className={`font-serif font-bold text-xs truncate ${theme.textPrimary}`}>
                          {ev.title}
                        </h4>

                        {displayLevel === 'detallada' && (
                          <div className="space-y-1.5 mt-1.5 pt-1.5 border-t border-stone-200 dark:border-stone-800 text-[10px] text-stone-500">
                            {ev.images && ev.images[0] && (
                              <img
                                src={ev.images[0].url}
                                alt="Event preview"
                                className="w-full h-16 object-cover rounded-lg border border-stone-200 dark:border-stone-700"
                              />
                            )}
                            {ev.description && (
                              <p className="line-clamp-2 leading-relaxed">{ev.description}</p>
                            )}
                            <div className="flex items-center gap-2 text-stone-400">
                              {catObj && (
                                <span className="font-semibold text-purple-600 dark:text-purple-400 truncate">
                                  {catObj.name}
                                </span>
                              )}
                              {(ev.characterIds || []).length > 0 && (
                                <span>• {ev.characterIds?.length} pers.</span>
                              )}
                            </div>
                          </div>
                        )}
                      </>
                    )}
                  </div>
                );
              })}
            </div>

            {/* Bottom Floating Helper */}
            <div className="absolute bottom-4 left-4 z-10 pointer-events-none bg-black/40 backdrop-blur-md px-3 py-1.5 rounded-xl text-[11px] text-white/90 font-sans shadow-lg flex items-center gap-2">
              <Move className="w-3.5 h-3.5" />
              <span>Arrastra el lienzo • Rueda del ratón para Zoom</span>
            </div>
          </div>
        ) : (
          /* VIEW 2: HORIZONTAL CONTINUOUS CHRONOLOGICAL AXIS */
          <div className={`flex-1 h-full p-6 overflow-x-auto relative ${theme.bgWorkspace}`}>
            <div className="min-w-[1400px] h-full flex flex-col justify-between py-6">
              <div className="flex items-center justify-between pb-3 border-b border-stone-200 dark:border-stone-800">
                <div>
                  <h3 className={`font-serif font-bold text-lg ${theme.textPrimary}`}>
                    Eje Cronológico Continuo
                  </h3>
                  <p className="text-xs text-stone-500">
                    Haz clic directamente en cualquier punto de la línea para crear un acontecimiento en esa posición exacta.
                  </p>
                </div>
              </div>

              {/* Central Interactive Clickable Axis Line */}
              <div className="relative my-auto py-16">
                {/* Visual Axis Line with click trigger */}
                <div
                  onClick={handleAxisClick}
                  className="w-full h-3 rounded-full cursor-pointer relative group transition-all"
                  style={{
                    backgroundColor: theme.accentHex,
                  }}
                  title="Haz clic en cualquier punto de este eje para añadir un acontecimiento"
                >
                  <div className="absolute inset-0 bg-white/20 opacity-0 group-hover:opacity-100 rounded-full transition-opacity" />
                  <span className="absolute -top-7 left-4 text-[10px] font-mono text-stone-400 font-bold uppercase tracking-wider">
                    Eje Temporal Continuo (Clic para crear)
                  </span>
                </div>

                {/* Events along the Axis */}
                <div className="flex items-center gap-8 overflow-x-auto py-6">
                  {[...resolvedEvents]
                    .sort((a, b) => a.numericSortValue - b.numericSortValue)
                    .map((ev, idx) => {
                      const isSelected = selectedEventId === ev.id;
                      const isEven = idx % 2 === 0;
                      const catObj = categories.find((c) => c.id === ev.category);

                      return (
                        <div
                          key={ev.id}
                          onClick={() => setSelectedEventId(ev.id)}
                          className={`flex flex-col items-center shrink-0 w-60 cursor-pointer group transition-all ${
                            isEven ? '-translate-y-10' : 'translate-y-10'
                          }`}
                        >
                          {/* Event Card */}
                          <div
                            className={`w-full p-3.5 rounded-2xl border shadow-sm transition-all ${
                              theme.bgCard
                            } ${
                              isSelected
                                ? `${theme.activeBorder} ring-2 ${theme.activeRing} shadow-lg`
                                : `${theme.borderCard} hover:shadow-md`
                            }`}
                          >
                            <div className="flex items-center justify-between gap-1 mb-1">
                              <span
                                className="text-[10px] font-mono font-bold px-2 py-0.5 rounded-full text-white"
                                style={{ backgroundColor: ev.color || catObj?.color || theme.accentHex }}
                              >
                                {ev.dateDisplay}
                              </span>
                              <span className="text-[10px] text-stone-400 truncate">
                                {catObj?.name || ev.category}
                              </span>
                            </div>

                            <h4 className={`font-serif font-bold text-xs truncate ${theme.textPrimary}`}>
                              {ev.title}
                            </h4>

                            {displayLevel === 'detallada' && ev.images && ev.images[0] && (
                              <img
                                src={ev.images[0].url}
                                alt="Event thumb"
                                className="w-full h-16 object-cover rounded-lg mt-1 border"
                              />
                            )}

                            {displayLevel !== 'puntos' && ev.description && (
                              <p className="text-[11px] text-stone-500 line-clamp-2 mt-1">
                                {ev.description}
                              </p>
                            )}
                          </div>

                          {/* Node pin onto the axis line */}
                          <div
                            className={`w-4 h-4 rounded-full border-2 border-white shadow-md my-2 transition-transform ${
                              isSelected ? 'scale-125' : 'group-hover:scale-110'
                            }`}
                            style={{ backgroundColor: ev.color || catObj?.color || theme.accentHex }}
                          />
                        </div>
                      );
                    })}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* FLOATING MINI-PANEL FOR SELECTIVE VISIBILITY */}
        {isFloatingFilterOpen && (
          <div
            className={`absolute top-4 right-4 z-40 p-4 rounded-2xl border shadow-2xl backdrop-blur-md w-72 space-y-3 ${theme.bgCard} ${theme.borderCard}`}
          >
            <div className="flex items-center justify-between pb-2 border-b border-stone-200 dark:border-stone-800">
              <span className={`text-xs font-bold uppercase tracking-wider ${theme.textPrimary}`}>
                Visibilidad Selectiva
              </span>
              <button onClick={() => setIsFloatingFilterOpen(false)} className="text-stone-400 hover:text-stone-700">
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Importance Filter */}
            <div>
              <label className="text-[11px] text-stone-500 font-semibold block mb-1">
                Nivel de Importancia
              </label>
              <div className="grid grid-cols-4 gap-1 text-[10px]">
                {(['todas', 'alta', 'media', 'baja'] as const).map((lvl) => (
                  <button
                    key={lvl}
                    onClick={() => setImportanceFilter(lvl)}
                    className={`py-1 rounded-lg capitalize font-medium transition-all ${
                      importanceFilter === lvl
                        ? `${theme.activeTab} font-semibold shadow-xs`
                        : 'bg-stone-100 dark:bg-stone-800 text-stone-500'
                    }`}
                  >
                    {lvl}
                  </button>
                ))}
              </div>
            </div>

            {/* Category Filter */}
            <div>
              <label className="text-[11px] text-stone-500 font-semibold block mb-1">
                Filtrar Categoría
              </label>
              <select
                value={filterCategory}
                onChange={(e) => setFilterCategory(e.target.value)}
                className={`w-full p-1.5 rounded-xl border text-xs ${theme.borderCard} ${theme.bgCard} ${theme.textPrimary} focus:outline-none`}
              >
                <option value="todas">Todas las categorías</option>
                {categories.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name}
                  </option>
                ))}
              </select>
            </div>

            {/* Character Filter */}
            <div>
              <label className="text-[11px] text-stone-500 font-semibold block mb-1">
                Filtrar por Personaje
              </label>
              <select
                value={filterCharacterId}
                onChange={(e) => setFilterCharacterId(e.target.value)}
                className={`w-full p-1.5 rounded-xl border text-xs ${theme.borderCard} ${theme.bgCard} ${theme.textPrimary} focus:outline-none`}
              >
                <option value="todos">Todos los personajes</option>
                {characters.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name}
                  </option>
                ))}
              </select>
            </div>
          </div>
        )}

        {/* LATERAL INSPECTOR PANEL: Collapsible & Non-invasive */}
        {isInspectorOpen && (
          <div
            className={`w-80 md:w-96 shrink-0 border-l flex flex-col justify-between shadow-xl z-20 transition-all duration-300 ${theme.bgCard} ${theme.borderCard}`}
          >
            {/* Panel Tabs */}
            <div>
              <div className="p-3 border-b border-stone-200 dark:border-stone-800 flex items-center justify-between">
                <div className="flex rounded-xl p-0.5 bg-stone-100 dark:bg-stone-800 text-[11px] font-semibold w-full">
                  <button
                    onClick={() => setPanelTab('acontecimientos')}
                    className={`flex-1 py-1 rounded-lg text-center transition-all ${
                      panelTab === 'acontecimientos'
                        ? `${theme.activeTab} font-semibold shadow-xs`
                        : 'text-stone-600 dark:text-stone-400'
                    }`}
                  >
                    Puntos ({rootEvents.length})
                  </button>
                  <button
                    onClick={() => setPanelTab('conexiones')}
                    className={`flex-1 py-1 rounded-lg text-center transition-all ${
                      panelTab === 'conexiones'
                        ? `${theme.activeTab} font-semibold shadow-xs`
                        : 'text-stone-600 dark:text-stone-400'
                    }`}
                  >
                    Conexiones ({connections.length})
                  </button>
                </div>
              </div>

              {/* Items List inside Panel */}
              <div className="p-3 max-h-[45vh] overflow-y-auto space-y-1.5">
                {panelTab === 'acontecimientos' ? (
                  rootEvents.map((ev) => {
                    const isSelected = selectedEventId === ev.id;
                    const catObj = categories.find((c) => c.id === ev.category);

                    return (
                      <div
                        key={ev.id}
                        onClick={() => setSelectedEventId(ev.id)}
                        className={`p-2.5 rounded-xl border text-left cursor-pointer transition-all flex items-center justify-between ${
                          isSelected
                            ? `${theme.activeBorder} ${theme.accentBadge} shadow-xs`
                            : 'border-stone-200 dark:border-stone-800 hover:bg-black/5 dark:hover:bg-white/5'
                        }`}
                      >
                        <div className="min-w-0 pr-2">
                          <span
                            className="text-[9px] font-mono font-bold px-1.5 py-0.2 rounded-full text-white inline-block mb-0.5"
                            style={{ backgroundColor: ev.color || catObj?.color || theme.accentHex }}
                          >
                            {ev.dateDisplay}
                          </span>
                          <h5 className={`text-xs font-bold truncate ${theme.textPrimary}`}>
                            {ev.title}
                          </h5>
                        </div>
                        <div className="flex items-center gap-1">
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              openEventModal(ev);
                            }}
                            className="p-1 text-stone-400 hover:text-stone-700"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              setDeleteConfirmEvent(ev);
                            }}
                            className="p-1 text-stone-400 hover:text-rose-600"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    );
                  })
                ) : (
                  connections.map((c) => {
                    const src = eventMap.get(c.sourceEventId);
                    const tgt = eventMap.get(c.targetEventId);
                    const isSel = selectedConnectionId === c.id;

                    return (
                      <div
                        key={c.id}
                        onClick={() => setSelectedConnectionId(c.id)}
                        className={`p-2.5 rounded-xl border text-left cursor-pointer transition-all ${
                          isSel
                            ? `${theme.activeBorder} ${theme.accentBadge}`
                            : 'border-stone-200 dark:border-stone-800 hover:bg-black/5'
                        }`}
                      >
                        <div className="flex items-center justify-between mb-1">
                          <span className={`text-[10px] font-bold ${theme.accentText}`}>
                            {c.title || 'Conexión'}
                          </span>
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              setDeleteConfirmConn(c);
                            }}
                            className="p-0.5 text-stone-400 hover:text-rose-600"
                          >
                            <Trash2 className="w-3 h-3" />
                          </button>
                        </div>
                        <div className="text-[11px] text-stone-500 truncate">
                          {src?.title || '...'} → {tgt?.title || '...'}
                        </div>
                      </div>
                    );
                  })
                )}
              </div>
            </div>

            {/* Selected Node Properties & Actions */}
            <div className="p-4 border-t border-stone-200 dark:border-stone-800 bg-stone-50/50 dark:bg-stone-900/50 space-y-3">
              {activeEvent ? (
                <div>
                  <div className="flex items-start justify-between gap-2 mb-2">
                    <div>
                      <span className="text-[10px] font-mono text-stone-400 font-bold block">
                        {activeEvent.dateDisplay}
                      </span>
                      <h4 className={`font-serif font-bold text-sm ${theme.textPrimary}`}>
                        {activeEvent.title}
                      </h4>
                    </div>
                    <button
                      onClick={() => openConnectionModal(undefined, activeEvent.id)}
                      className={`px-2.5 py-1 rounded-lg text-xs font-semibold shadow-xs ${theme.primaryBtn}`}
                      title="Conectar con otro hito"
                    >
                      <LinkIcon className="w-3 h-3" />
                    </button>
                  </div>

                  {activeEvent.images && activeEvent.images.length > 0 && (
                    <img
                      src={activeEvent.images[0].url}
                      alt="Event"
                      className="w-full h-24 object-cover rounded-xl border mb-2"
                    />
                  )}

                  <p className="text-xs text-stone-600 dark:text-stone-300 font-serif leading-relaxed line-clamp-3">
                    {activeEvent.description || 'Sin descripción detallada.'}
                  </p>
                </div>
              ) : (
                <div className="text-center py-6 text-stone-400 text-xs">
                  Selecciona un acontecimiento o haz clic en el eje continuo para añadir un hito.
                </div>
              )}
            </div>
          </div>
        )}
      </div>

      {/* CATEGORY MANAGER MODAL */}
      {isCatManagerOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-150">
          <div
            className={`w-full max-w-xl rounded-3xl border shadow-2xl p-6 ${theme.bgCard} ${theme.borderCard}`}
          >
            <div className="flex items-center justify-between pb-4 border-b border-stone-200 dark:border-stone-800">
              <div className="flex items-center gap-2.5">
                <div className={`p-2 rounded-xl ${theme.accentBadge} ${theme.accentText}`}>
                  <Sliders className="w-5 h-5" />
                </div>
                <div>
                  <h3 className={`font-serif font-bold text-lg ${theme.textPrimary}`}>
                    Categorías de la Línea de Tiempo
                  </h3>
                  <p className="text-xs text-stone-500">
                    Personaliza colores y temas para los acontecimientos de tu universo
                  </p>
                </div>
              </div>
              <button onClick={() => setIsCatManagerOpen(false)} className="p-1.5 text-stone-400 hover:bg-black/5">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="py-4 space-y-3">
              <div className="flex flex-col sm:flex-row gap-2">
                <input
                  type="text"
                  value={catNameInput}
                  onChange={(e) => setCatNameInput(e.target.value)}
                  placeholder="Nombre de categoría (ej: Batallas, Coronaciones)..."
                  className={`flex-1 px-3 py-2 rounded-xl border text-xs ${theme.borderCard} ${theme.bgCard} ${theme.textPrimary} focus:outline-none`}
                />
                <input
                  type="color"
                  value={catColorInput}
                  onChange={(e) => setCatColorInput(e.target.value)}
                  className="w-10 h-9 rounded-xl border p-0.5 cursor-pointer"
                />
                <button
                  type="button"
                  onClick={handleSaveCategory}
                  disabled={!catNameInput.trim()}
                  className={`px-4 py-2 rounded-xl text-xs font-semibold disabled:opacity-40 shadow-xs ${theme.primaryBtn}`}
                >
                  {editingCat ? 'Guardar' : 'Añadir'}
                </button>
              </div>

              <div className="space-y-1.5 max-h-56 overflow-y-auto pr-1 pt-2">
                {categories.map((c) => (
                  <div
                    key={c.id}
                    className="flex items-center justify-between p-2.5 rounded-xl border border-stone-200 dark:border-stone-800 bg-stone-50/50 dark:bg-stone-900/50 text-xs"
                  >
                    <div className="flex items-center gap-2">
                      <span
                        className="w-3.5 h-3.5 rounded-full inline-block shrink-0"
                        style={{ backgroundColor: c.color || '#2D5A43' }}
                      />
                      <span className={`font-medium ${theme.textPrimary}`}>{c.name}</span>
                    </div>

                    <div className="flex items-center gap-1">
                      <button
                        onClick={() => {
                          setEditingCat(c);
                          setCatNameInput(c.name);
                          setCatColorInput(c.color || '#2D5A43');
                        }}
                        className="p-1 text-stone-400 hover:text-stone-700"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => {
                          setDeletingCat(c);
                          const remaining = categories.filter((other) => other.id !== c.id);
                          setReassignTargetCatId(remaining[0]?.id || 'sin_categoria');
                        }}
                        className="p-1 text-stone-400 hover:text-rose-600"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="pt-4 border-t border-stone-200 dark:border-stone-800 flex items-center justify-between">
              <button
                type="button"
                onClick={handleResetCategories}
                className="text-xs text-stone-500 hover:text-stone-800 dark:hover:text-stone-200 flex items-center gap-1.5 underline"
              >
                <RotateCcw className="w-3 h-3" />
                <span>Restablecer categorías predeterminadas</span>
              </button>
              <button
                type="button"
                onClick={() => setIsCatManagerOpen(false)}
                className={`px-4 py-2 rounded-xl text-xs font-semibold shadow-xs ${theme.primaryBtn}`}
              >
                Cerrar
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Delete Category Reassignment Modal */}
      {deletingCat && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
          <div
            className={`w-full max-w-md rounded-2xl border shadow-2xl p-6 ${theme.bgCard} ${theme.borderCard}`}
          >
            <h3 className="font-serif font-bold text-lg text-rose-600 mb-2">
              Eliminar categoría "{deletingCat.name}"
            </h3>
            <p className="text-xs text-stone-600 dark:text-stone-400 mb-4 leading-relaxed">
              Para no perder los acontecimientos asociados, selecciona a qué categoría reasignarlos:
            </p>

            <select
              value={reassignTargetCatId}
              onChange={(e) => setReassignTargetCatId(e.target.value)}
              className={`w-full p-2.5 rounded-xl border text-xs mb-5 ${theme.borderCard} ${theme.bgCard} ${theme.textPrimary} focus:outline-none`}
            >
              <option value="sin_categoria">Dejar sin categoría ("sin_categoria")</option>
              {categories
                .filter((c) => c.id !== deletingCat.id)
                .map((c) => (
                  <option key={c.id} value={c.id}>
                    Reasignar a: {c.name}
                  </option>
                ))}
            </select>

            <div className="flex justify-end gap-3">
              <button
                type="button"
                onClick={() => setDeletingCat(null)}
                className="px-4 py-2 rounded-xl text-xs font-semibold border border-stone-300 dark:border-stone-700"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={handleDeleteCategory}
                className="px-4 py-2 rounded-xl text-xs font-semibold bg-rose-600 text-white shadow-md hover:bg-rose-700"
              >
                Confirmar y Reasignar
              </button>
            </div>
          </div>
        </div>
      )}

      {/* CREATE / EDIT EVENT MODAL */}
      {isEventModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm overflow-y-auto animate-in fade-in duration-150">
          <div
            className={`w-full max-w-2xl rounded-3xl border shadow-2xl overflow-hidden my-8 ${theme.bgCard} ${theme.borderCard}`}
          >
            <div className="p-5 border-b border-stone-200 dark:border-stone-800 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className={`p-2 rounded-xl ${theme.accentBadge} ${theme.accentText}`}>
                  <Clock className="w-5 h-5" />
                </div>
                <div>
                  <h3 className={`font-serif font-bold text-lg ${theme.textPrimary}`}>
                    {editingEvent ? 'Editar Acontecimiento' : 'Nuevo Acontecimiento Temporal'}
                  </h3>
                  <p className="text-xs text-stone-500">Hito histórico, giro o escena clave</p>
                </div>
              </div>
              <button onClick={() => setIsEventModalOpen(false)} className="p-1.5 text-stone-400 hover:bg-black/5">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveEvent} className="p-6 space-y-4 max-h-[75vh] overflow-y-auto">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="sm:col-span-2">
                  <label className="block text-xs font-semibold text-stone-700 dark:text-stone-300 mb-1">
                    Título del acontecimiento *
                  </label>
                  <input
                    type="text"
                    required
                    value={eventTitle}
                    onChange={(e) => setEventTitle(e.target.value)}
                    placeholder="Ej: El Asedio a las Torres de Cristal"
                    className={`w-full px-3.5 py-2 rounded-xl border text-sm font-medium ${theme.borderCard} bg-stone-50/50 dark:bg-stone-900/50 ${theme.textPrimary} focus:outline-none`}
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-stone-700 dark:text-stone-300 mb-1">
                    Categoría
                  </label>
                  <select
                    value={eventCategory}
                    onChange={(e) => {
                      const cat = e.target.value;
                      setEventCategory(cat);
                      const catObj = categories.find((c) => c.id === cat);
                      if (catObj?.color) setEventColor(catObj.color);
                    }}
                    className={`w-full px-3 py-2 rounded-xl border text-xs font-medium ${theme.borderCard} bg-stone-50/50 dark:bg-stone-900/50 ${theme.textPrimary} focus:outline-none`}
                  >
                    {categories.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.name}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Date & Importance */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-stone-700 dark:text-stone-300 mb-1">
                    Texto de la fecha / Era
                  </label>
                  <input
                    type="text"
                    value={eventDateDisplay}
                    onChange={(e) => setEventDateDisplay(e.target.value)}
                    placeholder="Ej: Año 1412, Otoño"
                    className={`w-full px-3 py-2 rounded-xl border text-xs ${theme.borderCard} bg-stone-50/50 dark:bg-stone-900/50 ${theme.textPrimary} focus:outline-none`}
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-stone-700 dark:text-stone-300 mb-1">
                    Valor numérico para orden
                  </label>
                  <input
                    type="number"
                    value={eventNumericValue}
                    onChange={(e) => setEventNumericValue(Number(e.target.value))}
                    className={`w-full px-3 py-2 rounded-xl border text-xs ${theme.borderCard} bg-stone-50/50 dark:bg-stone-900/50 ${theme.textPrimary} focus:outline-none`}
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-stone-700 dark:text-stone-300 mb-1">
                    Importancia
                  </label>
                  <select
                    value={eventImportance}
                    onChange={(e) => setEventImportance(e.target.value as any)}
                    className={`w-full px-3 py-2 rounded-xl border text-xs font-medium ${theme.borderCard} bg-stone-50/50 dark:bg-stone-900/50 ${theme.textPrimary} focus:outline-none capitalize`}
                  >
                    <option value="alta">Alta</option>
                    <option value="media">Media</option>
                    <option value="baja">Baja</option>
                  </select>
                </div>
              </div>

              {/* IMAGE ATTACHMENT SECTION */}
              <div className="p-3.5 rounded-2xl border border-stone-200 dark:border-stone-800 bg-stone-50/50 dark:bg-stone-900/40 space-y-2">
                <div className="flex items-center justify-between">
                  <div>
                    <span className={`text-xs font-bold uppercase tracking-wider ${theme.textPrimary}`}>
                      Imágenes del Acontecimiento
                    </span>
                    <p className="text-[11px] text-stone-500">Ilustraciones, mapas o momentos clave</p>
                  </div>
                  <label className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold cursor-pointer shadow-xs ${theme.primaryBtn}`}>
                    <Upload className="w-3.5 h-3.5" />
                    <span>Cargar Imagen</span>
                    <input type="file" accept="image/*" multiple className="hidden" onChange={handleAddEventImages} />
                  </label>
                </div>

                {eventImages.length > 0 && (
                  <div className="flex gap-2 overflow-x-auto pt-1">
                    {eventImages.map((img) => (
                      <div key={img.id} className="relative w-16 h-16 rounded-xl overflow-hidden border shrink-0">
                        <img src={img.url} alt="Hito" className="w-full h-full object-cover" />
                        <button
                          type="button"
                          onClick={() => setEventImages(eventImages.filter((i) => i.id !== img.id))}
                          className="absolute top-1 right-1 p-0.5 rounded-full bg-black/60 text-white"
                        >
                          <X className="w-3 h-3" />
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Description */}
              <div>
                <label className="block text-xs font-semibold text-stone-700 dark:text-stone-300 mb-1">
                  Descripción del acontecimiento
                </label>
                <textarea
                  rows={4}
                  value={eventDesc}
                  onChange={(e) => setEventDesc(e.target.value)}
                  placeholder="Detalles de lo que sucede, protagonistas involucrados y consecuencias..."
                  className={`w-full p-3 rounded-xl border text-xs font-serif ${theme.borderCard} bg-stone-50/50 dark:bg-stone-900/50 ${theme.textPrimary} focus:outline-none`}
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-4 border-t border-stone-200 dark:border-stone-800">
                <button
                  type="button"
                  onClick={() => setIsEventModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-xs font-semibold border border-stone-300 dark:border-stone-700"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className={`px-5 py-2 rounded-xl text-xs font-semibold shadow-md ${theme.primaryBtn}`}
                >
                  {editingEvent ? 'Guardar Cambios' : 'Crear Acontecimiento'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* CREATE / EDIT CONNECTION MODAL */}
      {isConnModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-150">
          <div
            className={`w-full max-w-lg rounded-3xl border shadow-2xl p-6 ${theme.bgCard} ${theme.borderCard}`}
          >
            <div className="flex items-center justify-between pb-3 border-b border-stone-200 dark:border-stone-800">
              <div className="flex items-center gap-2">
                <div className={`p-2 rounded-xl ${theme.accentBadge} ${theme.accentText}`}>
                  <LinkIcon className="w-5 h-5" />
                </div>
                <div>
                  <h3 className={`font-serif font-bold text-base ${theme.textPrimary}`}>
                    Conectar Acontecimientos
                  </h3>
                  <p className="text-xs text-stone-500">Líneas de causalidad o influencia narrativa</p>
                </div>
              </div>
              <button onClick={() => setIsConnModalOpen(false)} className="p-1.5 text-stone-400 hover:bg-black/5">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveConnection} className="space-y-4 py-4">
              <div>
                <label className="block text-xs font-semibold text-stone-700 dark:text-stone-300 mb-1">
                  Nombre o motivo de la conexión
                </label>
                <input
                  type="text"
                  value={connTitle}
                  onChange={(e) => setConnTitle(e.target.value)}
                  placeholder="Ej: Causa directa de la rebelión"
                  className={`w-full px-3 py-2 rounded-xl border text-xs ${theme.borderCard} bg-stone-50/50 dark:bg-stone-900/50 ${theme.textPrimary} focus:outline-none`}
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-stone-700 dark:text-stone-300 mb-1">
                    Acontecimiento Origen
                  </label>
                  <select
                    value={connSourceId}
                    onChange={(e) => setConnSourceId(e.target.value)}
                    className={`w-full px-3 py-2 rounded-xl border text-xs ${theme.borderCard} bg-stone-50/50 dark:bg-stone-900/50 ${theme.textPrimary} focus:outline-none`}
                  >
                    {events.map((e) => (
                      <option key={e.id} value={e.id}>
                        {e.title}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-stone-700 dark:text-stone-300 mb-1">
                    Acontecimiento Destino
                  </label>
                  <select
                    value={connTargetId}
                    onChange={(e) => setConnTargetId(e.target.value)}
                    className={`w-full px-3 py-2 rounded-xl border text-xs ${theme.borderCard} bg-stone-50/50 dark:bg-stone-900/50 ${theme.textPrimary} focus:outline-none`}
                  >
                    {events.map((e) => (
                      <option key={e.id} value={e.id}>
                        {e.title}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-stone-700 dark:text-stone-300 mb-1">
                    Tipo de relación
                  </label>
                  <select
                    value={connRelationType}
                    onChange={(e) => setConnRelationType(e.target.value as any)}
                    className={`w-full px-3 py-2 rounded-xl border text-xs ${theme.borderCard} bg-stone-50/50 dark:bg-stone-900/50 ${theme.textPrimary} focus:outline-none`}
                  >
                    {RELATION_TYPES.map((t) => (
                      <option key={t.id} value={t.id}>
                        {t.label}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-stone-700 dark:text-stone-300 mb-1">
                    Dirección
                  </label>
                  <select
                    value={connDirection}
                    onChange={(e) => setConnDirection(e.target.value as any)}
                    className={`w-full px-3 py-2 rounded-xl border text-xs ${theme.borderCard} bg-stone-50/50 dark:bg-stone-900/50 ${theme.textPrimary} focus:outline-none`}
                  >
                    <option value="unidireccional">Flecha (Origen → Destino)</option>
                    <option value="bidireccional">Recíproca (↔)</option>
                    <option value="no_dirigida">Línea continua sin flecha</option>
                  </select>
                </div>
              </div>

              <div className="flex justify-end gap-3 pt-3 border-t border-stone-200 dark:border-stone-800">
                <button
                  type="button"
                  onClick={() => setIsConnModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-xs font-semibold border border-stone-300 dark:border-stone-700"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className={`px-5 py-2 rounded-xl text-xs font-semibold shadow-md ${theme.primaryBtn}`}
                >
                  Guardar Conexión
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Event Confirmation Modal */}
      {deleteConfirmEvent && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
          <div
            className={`w-full max-w-md rounded-2xl border shadow-2xl p-6 ${theme.bgCard} ${theme.borderCard}`}
          >
            <h3 className="font-serif font-bold text-lg text-rose-600 mb-2">
              ¿Eliminar "{deleteConfirmEvent.title}"?
            </h3>
            <p className="text-xs text-stone-600 dark:text-stone-400 mb-6 leading-relaxed">
              Se eliminará este acontecimiento y todas sus conexiones.
            </p>
            <div className="flex justify-end gap-3">
              <button
                onClick={() => setDeleteConfirmEvent(null)}
                className="px-4 py-2 rounded-xl text-xs font-semibold border border-stone-300 dark:border-stone-700"
              >
                Cancelar
              </button>
              <button
                onClick={handleDeleteEvent}
                className="px-4 py-2 rounded-xl text-xs font-semibold bg-rose-600 text-white hover:bg-rose-700 shadow-md"
              >
                Eliminar
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Delete Connection Confirmation Modal */}
      {deleteConfirmConn && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
          <div
            className={`w-full max-w-md rounded-2xl border shadow-2xl p-6 ${theme.bgCard} ${theme.borderCard}`}
          >
            <h3 className="font-serif font-bold text-lg text-rose-600 mb-2">
              ¿Eliminar conexión?
            </h3>
            <p className="text-xs text-stone-600 dark:text-stone-400 mb-6 leading-relaxed">
              Se romperá el vínculo entre los dos acontecimientos.
            </p>
            <div className="flex justify-end gap-3">
              <button
                onClick={() => setDeleteConfirmConn(null)}
                className="px-4 py-2 rounded-xl text-xs font-semibold border border-stone-300 dark:border-stone-700"
              >
                Cancelar
              </button>
              <button
                onClick={handleDeleteConnection}
                className="px-4 py-2 rounded-xl text-xs font-semibold bg-rose-600 text-white hover:bg-rose-700 shadow-md"
              >
                Eliminar Conexión
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
