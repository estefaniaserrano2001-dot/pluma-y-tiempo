import React, { useState } from 'react';
import {
  BarChart3,
  BookOpen,
  Users,
  Compass,
  Lightbulb,
  Clock,
  Settings,
  ArrowLeft,
  PanelLeftClose,
  PanelLeftOpen,
} from 'lucide-react';
import { useApp, WorkspaceSection } from '../../context/AppContext';
import { getTheme } from '../../utils/theme';
import { BookSummary } from './BookSummary';
import { ChaptersModule } from './ChaptersModule';
import { CharactersModule } from './CharactersModule';
import { DetailsModule } from './DetailsModule';
import { IdeasModule } from './IdeasModule';
import { TimelineModule } from './TimelineModule';
import { SettingsModule } from './SettingsModule';

interface NavItem {
  id: WorkspaceSection;
  label: string;
  icon: React.FC<any>;
}

// 7 Clean workspace sections (Writing Assistant is integrated directly inside each chapter)
const NAV_ITEMS: NavItem[] = [
  { id: 'resumen', label: '1. Resumen', icon: BarChart3 },
  { id: 'capitulos', label: '2. Capítulos', icon: BookOpen },
  { id: 'personajes', label: '3. Personajes', icon: Users },
  { id: 'detalles', label: '4. Detalles', icon: Compass },
  { id: 'ideas', label: '5. Ideas al Aire', icon: Lightbulb },
  { id: 'timeline', label: '6. Línea de Tiempo', icon: Clock },
  { id: 'configuracion', label: '7. Archivos y Configuración', icon: Settings },
];

export const BookWorkspace: React.FC = () => {
  const {
    activeBook,
    setActiveBook,
    activeSection,
    setActiveSection,
    currentPalette,
    darkMode,
  } = useApp();

  const theme = getTheme(currentPalette, darkMode);
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);

  if (!activeBook) return null;

  return (
    <div className={`min-h-[calc(100vh-4rem)] flex flex-col md:flex-row relative ${theme.bgWorkspace}`}>
      {/* Floating Expand Sidebar Button when sidebar is collapsed */}
      {!isSidebarOpen && (
        <button
          onClick={() => setIsSidebarOpen(true)}
          className={`hidden md:flex fixed left-3 top-20 z-40 p-2.5 rounded-2xl border shadow-xl items-center gap-2 text-xs font-semibold backdrop-blur-md transition-all ${theme.bgCard} ${theme.borderCard} ${theme.textPrimary}`}
          title="Mostrar menú del libro"
        >
          <PanelLeftOpen className="w-4 h-4" />
          <span>Menú de Navegación</span>
        </button>
      )}

      {/* Workspace Sidebar Navigation */}
      {isSidebarOpen && (
        <aside
          className={`w-full md:w-64 shrink-0 border-b md:border-b-0 md:border-r p-3 md:p-4 flex md:flex-col justify-between transition-all duration-300 select-none overflow-x-auto md:overflow-x-visible ${theme.bgSidebar} ${theme.borderSidebar}`}
        >
          <div className="flex md:flex-col gap-1 w-full">
            {/* Top Back & Collapse Toolbar */}
            <div className="hidden md:flex items-center justify-between mb-2">
              <button
                onClick={() => setActiveBook(null)}
                className="flex items-center gap-2 px-2.5 py-1.5 rounded-xl text-xs font-semibold transition-all text-stone-500 hover:text-stone-900 dark:hover:text-stone-100 hover:bg-black/5 dark:hover:bg-white/5"
                title="Volver a la biblioteca"
              >
                <ArrowLeft className="w-3.5 h-3.5" />
                <span>Biblioteca</span>
              </button>

              <button
                onClick={() => setIsSidebarOpen(false)}
                className="p-1.5 rounded-lg text-stone-400 hover:text-stone-700 dark:hover:text-stone-200 hover:bg-black/5"
                title="Plegar menú para máxima concentración"
              >
                <PanelLeftClose className="w-4 h-4" />
              </button>
            </div>

            {/* Section Navigation Items */}
            {NAV_ITEMS.map((item) => {
              const Icon = item.icon;
              const isActive = activeSection === item.id;

              return (
                <button
                  key={item.id}
                  onClick={() => setActiveSection(item.id)}
                  className={`flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-xs md:text-sm font-medium transition-all text-left whitespace-nowrap md:whitespace-normal ${
                    isActive
                      ? `${theme.activeTab} font-semibold shadow-xs`
                      : `${theme.textPrimary} hover:bg-black/5 dark:hover:bg-white/5 opacity-80 hover:opacity-100`
                  }`}
                >
                  <Icon className="w-4 h-4 shrink-0 stroke-[2]" />
                  <span className="truncate">{item.label}</span>
                </button>
              );
            })}
          </div>

          {/* Bottom Current Book Badge in Sidebar */}
          <div className="hidden md:block pt-4 border-t border-stone-200 dark:border-stone-800 text-xs">
            <span className="text-[10px] text-stone-400 uppercase font-semibold tracking-wider block">
              Obra Activa:
            </span>
            <span className={`font-serif font-bold truncate block ${theme.textPrimary}`}>
              {activeBook.title}
            </span>
            <span className="text-[11px] text-stone-500 font-mono">
              {activeBook.genre}
            </span>
          </div>
        </aside>
      )}

      {/* Main Workspace Canvas Area */}
      <main className="flex-1 p-4 md:p-8 overflow-y-auto">
        {activeSection === 'resumen' && <BookSummary />}
        {activeSection === 'capitulos' && <ChaptersModule />}
        {activeSection === 'personajes' && <CharactersModule />}
        {activeSection === 'detalles' && <DetailsModule />}
        {activeSection === 'ideas' && <IdeasModule />}
        {activeSection === 'timeline' && <TimelineModule />}
        {activeSection === 'configuracion' && <SettingsModule />}
        {activeSection === 'asistente' && <ChaptersModule />}
      </main>
    </div>
  );
};
