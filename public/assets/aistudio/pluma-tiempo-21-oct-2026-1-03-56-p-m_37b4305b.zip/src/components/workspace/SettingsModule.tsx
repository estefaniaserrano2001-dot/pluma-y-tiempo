import React, { useState, useEffect } from 'react';
import {
  Settings,
  Palette,
  Download,
  Upload,
  HardDrive,
  FileText,
  Sun,
  Moon,
  Check,
  AlertCircle,
  HelpCircle,
  Info,
  ShieldCheck,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { dbService } from '../../services/db';
import { PALETTES, getTheme } from '../../utils/theme';
import { PaletteTheme, Book, Chapter } from '../../types';
import { formatBytes } from '../../utils/timelineEngine';

export const SettingsModule: React.FC = () => {
  const {
    activeBook,
    refreshBooks,
    currentPalette,
    darkMode,
    toggleDarkMode,
    setPalette,
    settings,
    updateSettings,
    toast,
    setIsSaving,
  } = useApp();

  const theme = getTheme(currentPalette, darkMode);

  const [storageEstimate, setStorageEstimate] = useState<{ usage: number; quota: number }>({
    usage: 0,
    quota: 0,
  });
  const [chapters, setChapters] = useState<Chapter[]>([]);

  useEffect(() => {
    async function loadStats() {
      const est = await dbService.getStorageEstimate();
      setStorageEstimate(est);
      if (activeBook) {
        const chs = await dbService.getChaptersByBook(activeBook.id);
        setChapters(chs);
      }
    }
    loadStats();
  }, [activeBook]);

  // Export full book project as JSON
  const handleExportJson = async () => {
    if (!activeBook) return;
    try {
      const json = await dbService.exportBookToJson(activeBook.id);
      const blob = new Blob([json], { type: 'application/json;charset=utf-8' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `backup_${activeBook.title.replace(/\s+/g, '_')}_${new Date().toISOString().slice(0, 10)}.json`;
      a.click();
      URL.revokeObjectURL(url);
      toast('Copia de seguridad JSON descargada', 'success');
    } catch (err: any) {
      toast('Error al exportar: ' + err.message, 'error');
    }
  };

  // Export Full Manuscript (All chapters ordered) to TXT
  const handleExportFullManuscript = () => {
    if (!activeBook) return;
    if (chapters.length === 0) {
      toast('No hay capítulos para exportar', 'info');
      return;
    }

    let manuscript = `${activeBook.title.toUpperCase()}\n`;
    if (activeBook.subtitle) manuscript += `${activeBook.subtitle}\n`;
    manuscript += `Género: ${activeBook.genre}\n`;
    manuscript += `Exportado el: ${new Date().toLocaleDateString()}\n`;
    manuscript += `${'='.repeat(60)}\n\n`;

    chapters.forEach((chap) => {
      manuscript += `\n\n${'#'.repeat(40)}\n`;
      manuscript += `CAPÍTULO ${chap.number}: ${chap.title.toUpperCase()}\n`;
      if (chap.synopsis) manuscript += `Sinopsis: ${chap.synopsis}\n`;
      manuscript += `${'#'.repeat(40)}\n\n`;
      manuscript += `${chap.content || '(Capítulo sin texto)'}\n\n`;
    });

    const blob = new Blob([manuscript], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `manuscrito_${activeBook.title.replace(/\s+/g, '_')}.txt`;
    a.click();
    URL.revokeObjectURL(url);
    toast('Manuscrito completo exportado en TXT', 'success');
  };

  return (
    <div className="space-y-8 max-w-5xl mx-auto animate-in fade-in duration-150">
      {/* Header */}
      <div
        className={`p-6 md:p-8 rounded-3xl border shadow-sm ${theme.bgCard} ${theme.borderCard}`}
      >
        <div className="flex items-center gap-2 mb-2">
          <span
            className={`text-xs px-2.5 py-1 rounded-full font-bold uppercase tracking-wider ${theme.accentBadge} ${theme.accentBadgeText}`}
          >
            Ajustes del Proyecto
          </span>
        </div>
        <h2 className={`font-serif text-2xl md:text-3xl font-bold ${theme.textPrimary}`}>
          Archivos, Exportación y Configuración
        </h2>
        <p className="text-xs md:text-sm text-stone-500 max-w-2xl mt-1">
          Gestiona las copias de seguridad de "{activeBook?.title}", exporta el manuscrito
          completo y configura las preferencias de diseño.
        </p>
      </div>

      {/* 5-Palette System Selector */}
      <div className={`p-6 md:p-8 rounded-3xl border shadow-xs space-y-4 ${theme.bgCard} ${theme.borderCard}`}>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-amber-500/10 text-amber-700 dark:text-amber-400">
              <Palette className="w-5 h-5" />
            </div>
            <div>
              <h3 className={`font-serif font-bold text-base ${theme.textPrimary}`}>
                Sistema de Cinco Paletas de Colores
              </h3>
              <p className="text-xs text-stone-500">
                Selecciona la paleta para este libro o para toda la aplicación
              </p>
            </div>
          </div>

          <button
            onClick={toggleDarkMode}
            className="flex items-center gap-2 px-3 py-1.5 rounded-xl border border-stone-300 dark:border-stone-700 text-xs font-semibold hover:bg-black/5"
          >
            {darkMode ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4 text-stone-600" />}
            <span>{darkMode ? 'Modo Claro' : 'Modo Oscuro'}</span>
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-5 gap-3 pt-2">
          {(Object.keys(PALETTES) as PaletteTheme[]).map((pKey) => {
            const p = PALETTES[pKey];
            const isSelected = currentPalette === pKey;
            return (
              <div
                key={pKey}
                onClick={() => setPalette(pKey, true)}
                className={`p-4 rounded-2xl border cursor-pointer transition-all flex flex-col justify-between ${
                  isSelected
                    ? 'border-amber-600 bg-amber-500/10 shadow-md ring-2 ring-amber-500/20'
                    : `${theme.borderCard} hover:bg-black/5 dark:hover:bg-white/5`
                }`}
              >
                <div>
                  <div className="flex -space-x-1 mb-2">
                    {p.preview.map((hex, i) => (
                      <div
                        key={i}
                        className="w-5 h-5 rounded-full border border-white dark:border-stone-800 shadow-xs"
                        style={{ backgroundColor: hex }}
                      />
                    ))}
                  </div>
                  <h4 className="font-serif font-bold text-sm text-stone-800 dark:text-stone-200">
                    {p.name}
                  </h4>
                  <p className="text-[11px] text-stone-500 mt-1 leading-tight">
                    {p.description}
                  </p>
                </div>

                <div className="pt-3 mt-3 border-t border-stone-200 dark:border-stone-800 flex justify-between items-center text-[10px]">
                  <span className="font-semibold text-stone-400">
                    {isSelected ? '✓ Activa' : 'Aplicar'}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Export & Backups */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Full Manuscript Export */}
        <div className={`p-6 rounded-3xl border shadow-xs space-y-4 ${theme.bgCard} ${theme.borderCard}`}>
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-emerald-500/10 text-emerald-700">
              <FileText className="w-5 h-5" />
            </div>
            <div>
              <h3 className={`font-serif font-bold text-base ${theme.textPrimary}`}>
                Exportar Manuscrito Completo
              </h3>
              <p className="text-xs text-stone-500">
                Une todos los capítulos ({chapters.length}) en un único archivo de texto
              </p>
            </div>
          </div>

          <p className="text-xs text-stone-600 dark:text-stone-400 leading-relaxed font-serif">
            Genera un archivo .txt formateado con títulos, números de capítulo y sinopsis,
            preparado para ser impreso o importado en procesadores de texto como Word o LibreOffice.
          </p>

          <button
            onClick={handleExportFullManuscript}
            className={`w-full py-2.5 px-4 rounded-xl text-xs font-semibold flex items-center justify-center gap-2 shadow-sm ${theme.primaryBtn}`}
          >
            <Download className="w-4 h-4" />
            <span>Descargar Manuscrito en TXT</span>
          </button>
        </div>

        {/* JSON Backup & Security */}
        <div className={`p-6 rounded-3xl border shadow-xs space-y-4 ${theme.bgCard} ${theme.borderCard}`}>
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-blue-500/10 text-blue-700">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h3 className={`font-serif font-bold text-base ${theme.textPrimary}`}>
                Copia de Seguridad Integral (JSON)
              </h3>
              <p className="text-xs text-stone-500">
                Exporta toda la base de datos de este libro
              </p>
            </div>
          </div>

          <p className="text-xs text-stone-600 dark:text-stone-400 leading-relaxed font-serif">
            Incluye capítulos, personajes, relaciones, lore, ideas y toda la línea de tiempo
            con sus coordenadas y flechas de conexión. Puedes restaurarlo en cualquier momento.
          </p>

          <button
            onClick={handleExportJson}
            className="w-full py-2.5 px-4 rounded-xl text-xs font-semibold border border-stone-300 dark:border-stone-700 hover:bg-black/5 flex items-center justify-center gap-2 shadow-xs"
          >
            <Download className="w-4 h-4 text-blue-600" />
            <span>Descargar Copia de Seguridad JSON</span>
          </button>
        </div>
      </div>

      {/* Storage & Persistence Diagnostics */}
      <div className={`p-6 md:p-8 rounded-3xl border shadow-xs space-y-4 ${theme.bgCard} ${theme.borderCard}`}>
        <div className="flex items-center gap-2.5">
          <div className="p-2 rounded-xl bg-amber-500/10 text-amber-700 dark:text-amber-400">
            <HardDrive className="w-5 h-5" />
          </div>
          <div>
            <h3 className={`font-serif font-bold text-base ${theme.textPrimary}`}>
              Almacenamiento Local Persistente (IndexedDB)
            </h3>
            <p className="text-xs text-stone-500">
              Tus datos y archivos de audio están guardados en tu navegador de forma offline
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs pt-2">
          <div className="p-4 rounded-2xl bg-stone-50 dark:bg-stone-900/60 border border-stone-200 dark:border-stone-800">
            <span className="text-stone-500 font-semibold block mb-1">Espacio Ocupado:</span>
            <strong className="text-base font-mono text-stone-800 dark:text-stone-200">
              {formatBytes(storageEstimate.usage)}
            </strong>
          </div>

          <div className="p-4 rounded-2xl bg-stone-50 dark:bg-stone-900/60 border border-stone-200 dark:border-stone-800">
            <span className="text-stone-500 font-semibold block mb-1">Cuota Estimada del Navegador:</span>
            <strong className="text-base font-mono text-stone-800 dark:text-stone-200">
              {formatBytes(storageEstimate.quota)}
            </strong>
          </div>

          <div className="p-4 rounded-2xl bg-stone-50 dark:bg-stone-900/60 border border-stone-200 dark:border-stone-800">
            <span className="text-stone-500 font-semibold block mb-1">Capítulos en este Libro:</span>
            <strong className="text-base font-mono text-stone-800 dark:text-stone-200">
              {chapters.length} partes
            </strong>
          </div>
        </div>

        {/* Browser storage note required by prompt */}
        <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-500/20 text-xs text-amber-900 dark:text-amber-200 leading-relaxed flex items-start gap-3">
          <Info className="w-4 h-4 shrink-0 mt-0.5" />
          <div>
            <strong>Aviso de seguridad y almacenamiento:</strong> La aplicación utiliza el motor
            IndexedDB de tu navegador para almacenar tus manuscritos, relaciones y archivos de audio sin
            necesidad de enviar tus borradores a servidores externos no autorizados. Sin embargo,
            si borras los datos de navegación o el historial de caché del navegador, podrías perder
            información local. Se recomienda descargar periódicamente una copia de seguridad en JSON con el botón superior.
          </div>
        </div>
      </div>
    </div>
  );
};
