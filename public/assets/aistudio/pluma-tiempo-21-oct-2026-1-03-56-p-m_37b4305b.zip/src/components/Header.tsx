import React, { useState } from 'react';
import {
  Feather,
  Search,
  Palette,
  Sun,
  Moon,
  ArrowLeft,
  CheckCircle2,
  Loader2,
  HardDrive,
  ChevronDown,
  BookOpen,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { PALETTES, getTheme } from '../utils/theme';
import { PaletteTheme } from '../types';

export const Header: React.FC = () => {
  const {
    activeBook,
    setActiveBook,
    currentPalette,
    darkMode,
    toggleDarkMode,
    setPalette,
    setOpenGlobalSearch,
    isSaving,
    settings,
  } = useApp();

  const theme = getTheme(currentPalette, darkMode);
  const [showPaletteMenu, setShowPaletteMenu] = useState(false);

  return (
    <header
      className={`h-16 px-4 md:px-6 border-b flex items-center justify-between transition-colors duration-200 select-none ${theme.bgSidebar} ${theme.borderSidebar} sticky top-0 z-30`}
    >
      {/* Left: Brand or Back to Library */}
      <div className="flex items-center gap-3">
        {activeBook ? (
          <button
            onClick={() => setActiveBook(null)}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-sm font-medium transition-all ${theme.textPrimary} hover:bg-black/5 dark:hover:bg-white/10`}
            title="Volver a la Biblioteca de Libros"
          >
            <ArrowLeft className="w-4 h-4" />
            <span className="hidden sm:inline">Biblioteca</span>
          </button>
        ) : (
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-amber-700/10 dark:bg-amber-400/10 text-amber-800 dark:text-amber-300 flex items-center justify-center shadow-inner">
              <Feather className="w-5 h-5 stroke-[2.2]" />
            </div>
            <div>
              <span className={`font-serif text-lg font-bold tracking-tight ${theme.textPrimary}`}>
                Pluma &amp; Tiempo
              </span>
              <span className={`block text-[11px] font-sans -mt-1 ${theme.textMuted}`}>
                Espacio de Creación Narrativa
              </span>
            </div>
          </div>
        )}

        {/* Current Book title pill if in workspace */}
        {activeBook && (
          <div className="flex items-center gap-2 pl-2 border-l border-stone-300 dark:border-stone-700">
            <BookOpen className="w-4 h-4 text-amber-700 dark:text-amber-400 hidden md:block" />
            <span className={`font-serif font-semibold text-sm md:text-base max-w-[200px] md:max-w-[340px] truncate ${theme.textPrimary}`}>
              {activeBook.title}
            </span>
            <span
              className={`text-[11px] px-2 py-0.5 rounded-full capitalize font-medium hidden lg:inline-block ${theme.accentBadge} ${theme.accentBadgeText}`}
            >
              {activeBook.status}
            </span>
          </div>
        )}
      </div>

      {/* Middle: Save Status indicator */}
      <div className="flex items-center gap-2 text-xs">
        {isSaving ? (
          <span className="flex items-center gap-1.5 text-amber-600 dark:text-amber-400">
            <Loader2 className="w-3.5 h-3.5 animate-spin" />
            <span className="hidden sm:inline">Guardando cambios...</span>
          </span>
        ) : (
          <span className={`flex items-center gap-1.5 ${theme.textMuted}`}>
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
            <span className="hidden md:inline">Sincronizado</span>
          </span>
        )}
      </div>

      {/* Right Controls: Search, Palettes, Dark Mode, Info */}
      <div className="flex items-center gap-2">
        {/* Global Search trigger */}
        <button
          onClick={() => setOpenGlobalSearch(true)}
          className={`flex items-center gap-2 px-3 py-1.5 rounded-lg border text-xs md:text-sm transition-all ${theme.borderCard} ${theme.bgCard} ${theme.textSecondary} hover:border-amber-600/50 shadow-sm`}
          title="Buscar en todo el universo (Ctrl + K)"
        >
          <Search className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400" />
          <span className="hidden md:inline">Buscar...</span>
          <kbd className="hidden lg:inline-block text-[10px] px-1.5 py-0.5 rounded bg-black/5 dark:bg-white/10 font-mono text-stone-500">
            ⌘K
          </kbd>
        </button>

        {/* 5-Palette selector dropdown */}
        <div className="relative">
          <button
            onClick={() => setShowPaletteMenu(!showPaletteMenu)}
            className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-medium border transition-all ${theme.borderCard} ${theme.bgCard} ${theme.textPrimary} shadow-sm hover:ring-2 hover:ring-amber-500/20`}
            title="Cambiar paleta de colores"
          >
            <div className="flex -space-x-1">
              {PALETTES[currentPalette].preview.map((hex, i) => (
                <div
                  key={i}
                  className="w-3.5 h-3.5 rounded-full border border-white dark:border-stone-900 shadow-sm"
                  style={{ backgroundColor: hex }}
                />
              ))}
            </div>
            <span className="hidden sm:inline font-sans capitalize">{PALETTES[currentPalette].name}</span>
            <ChevronDown className="w-3 h-3 text-stone-400" />
          </button>

          {showPaletteMenu && (
            <div
              className={`absolute right-0 mt-2 w-72 rounded-xl border shadow-2xl p-2 z-50 ${theme.bgCard} ${theme.borderCard} animate-in fade-in slide-in-from-top-2 duration-150`}
            >
              <div className="px-3 py-2 border-b border-stone-200 dark:border-stone-800">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-semibold text-stone-700 dark:text-stone-300">
                    Paletas de Colores (5)
                  </span>
                  <Palette className="w-3.5 h-3.5 text-stone-400" />
                </div>
                <p className="text-[11px] text-stone-500 mt-0.5">
                  Personalización visual inspirada en la literatura
                </p>
              </div>

              <div className="py-1 space-y-1">
                {(Object.keys(PALETTES) as PaletteTheme[]).map((pKey) => {
                  const p = PALETTES[pKey];
                  const isSelected = currentPalette === pKey;
                  return (
                    <div
                      key={pKey}
                      className={`w-full text-left p-2 rounded-lg transition-all flex items-center justify-between cursor-pointer ${
                        isSelected
                          ? 'bg-amber-500/10 border border-amber-500/30'
                          : 'hover:bg-black/5 dark:hover:bg-white/5'
                      }`}
                      onClick={async () => {
                        await setPalette(pKey, Boolean(activeBook));
                        setShowPaletteMenu(false);
                      }}
                    >
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-medium text-stone-800 dark:text-stone-200">
                            {p.name}
                          </span>
                          {isSelected && (
                            <span className="text-[10px] text-amber-700 dark:text-amber-400 font-semibold">
                              ✓ Activa
                            </span>
                          )}
                        </div>
                        <span className="text-[10px] text-stone-500 block leading-tight mt-0.5">
                          {p.description}
                        </span>
                      </div>
                      <div className="flex -space-x-1 pl-2">
                        {p.preview.map((hex, i) => (
                          <div
                            key={i}
                            className="w-4 h-4 rounded-full border border-white dark:border-stone-800 shadow-sm"
                            style={{ backgroundColor: hex }}
                          />
                        ))}
                      </div>
                    </div>
                  );
                })}
              </div>

              {activeBook && (
                <div className="pt-2 mt-1 border-t border-stone-200 dark:border-stone-800 text-[11px] text-stone-500 px-2 flex justify-between items-center">
                  <span>Aplica a:</span>
                  <span className="font-semibold text-amber-700 dark:text-amber-400">
                    "{activeBook.title}"
                  </span>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Light / Dark Mode Toggle */}
        <button
          onClick={toggleDarkMode}
          className={`p-2 rounded-lg border transition-all ${theme.borderCard} ${theme.bgCard} ${theme.textPrimary} hover:ring-2 hover:ring-amber-500/20`}
          title={darkMode ? 'Cambiar a Modo Claro' : 'Cambiar a Modo Oscuro'}
        >
          {darkMode ? (
            <Sun className="w-4 h-4 text-amber-400" />
          ) : (
            <Moon className="w-4 h-4 text-stone-600" />
          )}
        </button>
      </div>
    </header>
  );
};
