import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { Book, AppSettings, PaletteTheme, CustomPaletteConfig, CustomFontItem } from '../types';
import { dbService } from '../services/db';

export type WorkspaceSection =
  | 'resumen'
  | 'capitulos'
  | 'personajes'
  | 'detalles'
  | 'ideas'
  | 'timeline'
  | 'asistente'
  | 'configuracion';

export interface ToastMessage {
  id: string;
  message: string;
  type: 'success' | 'error' | 'info';
}

interface AppContextType {
  books: Book[];
  activeBook: Book | null;
  setActiveBook: (book: Book | null) => void;
  refreshBooks: () => Promise<void>;
  settings: AppSettings;
  updateSettings: (updates: Partial<AppSettings>) => Promise<void>;
  currentPalette: string;
  darkMode: boolean;
  toggleDarkMode: () => void;
  setPalette: (palette: string, forCurrentBookOnly?: boolean) => Promise<void>;
  customPalettes: CustomPaletteConfig[];
  refreshCustomPalettes: () => Promise<void>;
  customFonts: CustomFontItem[];
  refreshCustomFonts: () => Promise<void>;
  activeSection: WorkspaceSection;
  setActiveSection: (section: WorkspaceSection) => void;
  activeChapterId: string | null;
  setActiveChapterId: (id: string | null) => void;
  toasts: ToastMessage[];
  toast: (message: string, type?: 'success' | 'error' | 'info') => void;
  openGlobalSearch: boolean;
  setOpenGlobalSearch: (open: boolean) => void;
  navigateToEntity: (type: 'chapter' | 'character' | 'detail' | 'idea' | 'timeline', id: string) => void;
  isSaving: boolean;
  setIsSaving: (saving: boolean) => void;
}

const AppContext = createContext<AppContextType | null>(null);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [books, setBooks] = useState<Book[]>([]);
  const [activeBook, setActiveBookState] = useState<Book | null>(null);
  const [settings, setSettings] = useState<AppSettings>({
    globalPalette: 'bosque',
    darkMode: false,
    editorFontSize: 18,
    editorFontFamily: 'lora',
    autoSaveDelay: 1000,
  });
  const [customPalettes, setCustomPalettes] = useState<CustomPaletteConfig[]>([]);
  const [customFonts, setCustomFonts] = useState<CustomFontItem[]>([]);
  const [activeSection, setActiveSection] = useState<WorkspaceSection>('resumen');
  const [activeChapterId, setActiveChapterId] = useState<string | null>(null);
  const [toasts, setToasts] = useState<ToastMessage[]>([]);
  const [openGlobalSearch, setOpenGlobalSearch] = useState(false);
  const [isSaving, setIsSaving] = useState(false);

  // Initialize DB and Seed
  useEffect(() => {
    async function init() {
      try {
        await dbService.seedIfEmpty();
        const loadedBooks = await dbService.getBooks();
        setBooks(loadedBooks);
        const savedSettings = await dbService.getSettings();
        setSettings(savedSettings);
        const palettes = await dbService.getCustomPalettes();
        setCustomPalettes(palettes);
        const fonts = await dbService.getCustomFonts();
        setCustomFonts(fonts);
      } catch (err) {
        console.error('Error al inicializar la base de datos:', err);
      }
    }
    init();
  }, []);

  // Register loaded custom fonts in document.fonts
  useEffect(() => {
    customFonts.forEach((f) => {
      try {
        const fontFace = new FontFace(f.name, `url(${f.dataUrl})`);
        fontFace.load().then((loaded) => {
          document.fonts.add(loaded);
        }).catch((err) => {
          console.warn('Error loading custom font:', f.name, err);
        });
      } catch (err) {
        console.warn('FontFace API not supported or error:', err);
      }
    });
  }, [customFonts]);

  // Apply UI font family
  useEffect(() => {
    if (settings.uiFontFamily && settings.uiFontFamily !== 'default') {
      document.body.style.fontFamily = `"${settings.uiFontFamily}", system-ui, -apple-system, sans-serif`;
    } else {
      document.body.style.fontFamily = '';
    }
  }, [settings.uiFontFamily]);

  const refreshCustomPalettes = useCallback(async () => {
    try {
      const pals = await dbService.getCustomPalettes();
      setCustomPalettes(pals);
    } catch (err) {
      console.error('Error refreshing palettes:', err);
    }
  }, []);

  const refreshCustomFonts = useCallback(async () => {
    try {
      const fonts = await dbService.getCustomFonts();
      setCustomFonts(fonts);
    } catch (err) {
      console.error('Error refreshing custom fonts:', err);
    }
  }, []);

  const toast = useCallback((message: string, type: 'success' | 'error' | 'info' = 'info') => {
    const id = 'toast_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6);
    setToasts((prev) => [...prev, { id, message, type }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 4000);
  }, []);

  const refreshBooks = useCallback(async () => {
    try {
      const list = await dbService.getBooks();
      setBooks(list);
      if (activeBook) {
        const updated = list.find((b) => b.id === activeBook.id) || null;
        setActiveBookState(updated);
      }
    } catch (err) {
      console.error('Error al refrescar libros:', err);
    }
  }, [activeBook]);

  const setActiveBook = useCallback((book: Book | null) => {
    setActiveBookState(book);
    if (book) {
      setActiveSection('resumen');
      setActiveChapterId(null);
    }
  }, []);

  const updateSettings = useCallback(
    async (updates: Partial<AppSettings>) => {
      const newSettings = { ...settings, ...updates };
      setSettings(newSettings);
      await dbService.saveSettings(newSettings);
    },
    [settings]
  );

  const toggleDarkMode = useCallback(() => {
    updateSettings({ darkMode: !settings.darkMode });
  }, [settings.darkMode, updateSettings]);

  const setPalette = useCallback(
    async (palette: string, forCurrentBookOnly: boolean = false) => {
      if (forCurrentBookOnly && activeBook) {
        const updatedBook: Book = {
          ...activeBook,
          colorPalette: palette as any,
          updatedAt: new Date().toISOString(),
        };
        await dbService.saveBook(updatedBook);
        setActiveBookState(updatedBook);
        await refreshBooks();
        toast(`Paleta aplicada a este libro`, 'success');
      } else {
        await updateSettings({ globalPalette: palette as any });
        toast(`Paleta global actualizada`, 'success');
      }
    },
    [activeBook, refreshBooks, toast, updateSettings]
  );

  // Compute active palette: book-specific palette takes precedence over global palette
  const currentPalette = (activeBook?.colorPalette || settings.globalPalette) as string;
  const darkMode = settings.darkMode;

  const navigateToEntity = useCallback(
    (type: 'chapter' | 'character' | 'detail' | 'idea' | 'timeline', id: string) => {
      if (type === 'chapter') {
        setActiveSection('capitulos');
        setActiveChapterId(id);
      } else if (type === 'character') {
        setActiveSection('personajes');
      } else if (type === 'detail') {
        setActiveSection('detalles');
      } else if (type === 'idea') {
        setActiveSection('ideas');
      } else if (type === 'timeline') {
        setActiveSection('timeline');
      }
      setOpenGlobalSearch(false);
    },
    []
  );

  return (
    <AppContext.Provider
      value={{
        books,
        activeBook,
        setActiveBook,
        refreshBooks,
        settings,
        updateSettings,
        currentPalette,
        darkMode,
        toggleDarkMode,
        setPalette,
        customPalettes,
        refreshCustomPalettes,
        customFonts,
        refreshCustomFonts,
        activeSection,
        setActiveSection,
        activeChapterId,
        setActiveChapterId,
        toasts,
        toast,
        openGlobalSearch,
        setOpenGlobalSearch,
        navigateToEntity,
        isSaving,
        setIsSaving,
      }}
    >
      <div className={darkMode ? 'dark' : ''}>
        {children}

        {/* Global Toast Notification Container */}
        <div className="fixed bottom-5 right-5 z-50 flex flex-col gap-2 max-w-sm pointer-events-none">
          {toasts.map((t) => (
            <div
              key={t.id}
              className={`pointer-events-auto px-4 py-3 rounded-lg shadow-xl text-sm font-medium transition-all duration-300 flex items-center justify-between border ${
                t.type === 'success'
                  ? 'bg-emerald-900 text-emerald-100 border-emerald-700'
                  : t.type === 'error'
                  ? 'bg-rose-950 text-rose-100 border-rose-800'
                  : 'bg-stone-900 text-stone-100 border-stone-700'
              }`}
            >
              <span>{t.message}</span>
            </div>
          ))}
        </div>
      </div>
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) throw new Error('useApp debe usarse dentro de un AppProvider');
  return context;
};
